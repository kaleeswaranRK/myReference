package com.amex.util;



public class config 
{
	public   static String 				APP_PATH 					= null;
	public   static String 				FILE_PATH 					= null;
	public   static String 				FILE_PATH_log4j				= null;
	
	public static String				IP_ADDRESS					= null;
	public static String				DB_USERNAME					= null;
	public static String				DB_PASSWORD					= null;
	public static String				SERVICE_NAME				= null;
	public static String				DB_PORT						= null;
	public static String				XML_KEY						= null;
		
}

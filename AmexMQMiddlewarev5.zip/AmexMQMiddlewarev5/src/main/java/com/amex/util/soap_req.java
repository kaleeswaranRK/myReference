package com.amex.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.security.cert.X509Certificate;
import java.util.Base64;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;



public class soap_req 
{
	
	public String send_request ( String httpsURL,String api_username,String api_pwd,String key) 
	{	
		BufferedReader br=null;
		try
		 {
			/* Start of Fix */
	        TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
	            public void checkClientTrusted(X509Certificate[] certs, String authType) { }
	            public void checkServerTrusted(X509Certificate[] certs, String authType) { }

	        } };

	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) { return true; }
	        };
	        // Install the all-trusting host verifier
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	        /* End of the fix*/

			URL url = new URL(httpsURL);
	        URLConnection con = url.openConnection();
	        String userpass = api_username + ":" + api_pwd;
		    String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
		    con.setRequestProperty ("Authorization", basicAuth);
	        
		    InputStream is = con.getInputStream();
	        InputStreamReader isr = new InputStreamReader(is);
		    br = new BufferedReader(isr);
	        String inputLine;
	        String resp = null;
	        while ((inputLine = br.readLine()) != null) 
	        {    
	            resp =inputLine;
	        }  
	        return check_response(resp,key);
		 }
		 catch (Exception e) 
		 {
			 System.out.println(e);
			 return null;
		 }
		finally 
		{
			if (br != null) 
			{
				try
				{
					br.close();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				} 
			}
		}     			
	}
	

	public String check_response ( String ch,String tag_name) throws ParserConfigurationException, SAXException, IOException
	{
		String response = null;
		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		InputSource src = new InputSource();
		src.setCharacterStream(new StringReader(ch));
		Document doc = builder.parse(src);
		response = doc.getElementsByTagName(tag_name).item(0).getTextContent();	 
		
		System.out.println("response ****** "+response);
		return response;
	}
		
}
	
	

package com.amex.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Logger;

import com.amex.mq.util.Get_agent_menuaccess_util;
import com.amex.mq.util.Get_callnotes_util;
import com.amex.mq.util.Get_department_util;
import com.amex.mq.util.Get_dispositioncode;

public class db_operations 
{
	Connection con = null;
	int result = 0;
	String result1 = "";
	Statement stmt = null;
	ResultSet rs = null;
	
	org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(db_operations.class);

	private static Logger  log = Logger.getLogger("cc_ws_req");
	
	private boolean check_connection() throws Exception 
	{ 
		try 
		{
			if (con == null || con.isClosed() == true)
				open_db_connection();
		}
		catch (SQLException e)
		{
			logger.error("SQL EXCEPTION OCCURED");

			log.severe("SQL EXCEPTION OCCURED");
			return false;
		}

		return true;
	}
	
	
	public void open_db_connection() throws Exception 
	{
		try 
		{
//			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
//			String URL = "jdbc:oracle:thin:@"+config.IP_ADDRESS+":"+config.DB_PORT+"/"+config.SERVICE_NAME+"";
//			//String URL="jdbc:oracle:thin:@10.7.1.25:1521:AICDB";
//			con = DriverManager.getConnection(URL,config.DB_USERNAME,config.DB_PASSWORD);
//			//con = DriverManager.getConnection(URL,"testivr","testivr");
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
			String URL = "jdbc:sqlserver://"+config.IP_ADDRESS+":"+config.DB_PORT+";"+config.SERVICE_NAME+"";
			con = DriverManager.getConnection(URL,config.DB_USERNAME,config.DB_PASSWORD);
			
			logger.info("db success");

			log.info("db success");
			
		} 
		catch (Exception e) 
		{
			logger.error("database connection failed "+e);
			log.severe("database connection failed "+e);
			throw new Exception("Open DB Connection failed !!");  
		}

	}
	
	public ArrayList<Get_dispositioncode>get_dispositioncode_details()  
	{
		ArrayList<Get_dispositioncode>  dispositioncode_list= new ArrayList<Get_dispositioncode>();
		
		try
		{	
			if(check_connection() == false)
			{
				return null;	
			}

			stmt=con.createStatement();  
			String sql="select refid,group_type,direction,disp_number,disp_desc from disposition order by disp_desc asc";
			logger.info("sql query of disposition is :"+sql);

			log.info("sql query of disposition is :"+sql);
			rs=stmt.executeQuery(sql); 
			
			 while(rs.next())
			 {
				 Get_dispositioncode o_dispositioncode = new Get_dispositioncode();

				 o_dispositioncode.refid				=	rs.getString("refid");				 
				 o_dispositioncode.group_type			=	rs.getString("group_type");
				 o_dispositioncode.direction			=	rs.getString("direction");
				 o_dispositioncode.disp_number			= 	rs.getString("disp_number");
				 o_dispositioncode.disp_desc			=	rs.getString("disp_desc");
				 o_dispositioncode.code					=   "Sucess";
				 dispositioncode_list.add(o_dispositioncode);
			 }
			
		return dispositioncode_list;
		
		}
		catch (Exception e) 
		{
			logger.error("SQL Exception at get_dispositioncode_details " + e);

			log.severe("SQL Exception at get_dispositioncode_details " + e);
		}
		finally 
		{
			db_close();
			
		}
		
		return null;
	
	}
	
	
	public ArrayList<Get_department_util>get_transfer_num_details()
	{		
		ArrayList<Get_department_util>  department_list = new ArrayList<Get_department_util>();
		try
		{	
			if(check_connection() == false)
			{
				return null;	
			}
			String sql="select refid,action_type,ivr_number,description from transfer_num_details";
			logger.info("sql query of transfer_num_details is :"+sql);

			log.info("sql query of transfer_num_details is :"+sql);
			stmt=con.createStatement();  
			rs=stmt.executeQuery(sql); 
			
			 while(rs.next())
			 {
				 Get_department_util o_department_util = new Get_department_util();

				 o_department_util.refid				=	rs.getString("refid");				 
				 
				 o_department_util.action_type			=	rs.getString("action_type");
				 o_department_util.number				= 	rs.getString("ivr_number");
				 o_department_util.description			=	rs.getString("description");
				 o_department_util.code					=	"success";
				 
				 department_list.add(o_department_util);
			 }
			
		return department_list;
		
		}
		catch (Exception e) 
		{
			logger.error("SQL Exception at the get_transfer_num_details " + e);

			log.severe("SQL Exception at the get_transfer_num_details " + e);
			
		}
		finally 
		{
			db_close();
		}
		return null;
	}
	
	
	public ArrayList<Get_callnotes_util>getcallnotes(String client_code) 
	{	
		
		ArrayList<Get_callnotes_util>  callnotes_list= new ArrayList<Get_callnotes_util>();
		try
		{	
			if(check_connection() == false)
			{
				return null;	
			}
			
			stmt=con.createStatement(); 
			//String sql="select agent_id,call_notes,created_time from screen_pop_details where account_number='"+account_no+"' ORDER BY created_time DESC FETCH NEXT 5 ROWS ONLY;";
			String sql = "select * from( select ROW_NUMBER() OVER (ORDER BY created_time desc) row_num,agent_id,call_notes,created_time,disposition_code,disposition_desc,department from agent_disposition_details where client_code = '"+client_code+"' ) x where row_num < 6";
			logger.info("select query of call notes is  : "+sql);

			log.info("select query of call notes is  : "+sql);
			rs=stmt.executeQuery(sql); 
			
			 while(rs.next())
			 {
				 Get_callnotes_util o_callnotes_util = new Get_callnotes_util();

				 o_callnotes_util.agent_id				=	rs.getString("agent_id");				 
				 
				 o_callnotes_util.call_notes			=	rs.getString("call_notes");
				 Timestamp created_time					=	rs.getTimestamp("created_time");
				 o_callnotes_util.created_time			=	date_format(created_time.toString());
				 
				 
				 if( o_callnotes_util.call_notes == null ||  o_callnotes_util.call_notes == "")
				 {
					 o_callnotes_util.call_notes = "";
				 }
				 
				 o_callnotes_util.dispositionCode		=	rs.getString("disposition_code");
				 o_callnotes_util.dispositionDesc       =   rs.getString("disposition_desc");
				 o_callnotes_util.department			=	rs.getString("department");
				 o_callnotes_util.code					=	"sucess";

				 
				 callnotes_list.add(o_callnotes_util);
			 }
				
		return callnotes_list;
		
		}
		catch (Exception e) 
		{
			logger.error("SQL Exception at the get call notes " + e);

			log.severe("SQL Exception at the get call notes " + e);
			
		}
		
		finally 
		{
			db_close();
		}
		return null;
	
	}
	
	
	
	public boolean set_agent_to_ivr(String work_request_id,String agent_id,String card_number,String agent_action,String action_type,String language,String transfer_number,String status,Timestamp created_time) throws SQLException
	{
		PreparedStatement cs_stmt=null;
		try
		{
			if(check_connection() == false)
				return false;
			
			String sql="INSERT INTO agent_to_ivr(work_request_id,agent_id,card_number,agent_action,action_type,language,transfer_number,status,created_time) VALUES (?,?,?,?,?,?,?,?,?)";
			logger.info("sql query of agent_to_ivr is :"+sql);
			log.info("sql query of agent_to_ivr is :"+sql);
			
			cs_stmt=con.prepareStatement(sql);  
			cs_stmt.setString(1,work_request_id);
			cs_stmt.setString(2,agent_id);
			cs_stmt.setString(3,card_number);
			cs_stmt.setString(4,agent_action);
			cs_stmt.setString(5,action_type);
			cs_stmt.setString(6,language);
			cs_stmt.setString(7,transfer_number);
			cs_stmt.setString(8,status);
			cs_stmt.setTimestamp(9,created_time);
			
			int i=cs_stmt.executeUpdate();
			
			if(i > 0)
			{
				logger.info("adding service data to set_agent_to_ivr table" + i);

				log.info("adding service data to set_agent_to_ivr table" + i);
				return true;
			}
			
		}
		catch (Exception e) 
		{	
			logger.error("SQL Exception at the set agent to ivr " + e);

			log.severe("SQL Exception at the set agent to ivr " + e);
			return false;
		}
		finally
		{
			if (cs_stmt != null) 
			{
		        try 
		        {
		        	cs_stmt.close();
		        	con.close();
		        } 
		        catch (SQLException e) { }
		    }
		}
		return false;
		
	}
	
	
	public boolean set_offer_mkt_messages(String work_request_id,String agent_id,String campaign,String campaign_details,String status,Timestamp created_time) throws SQLException
	{
		PreparedStatement cs_stmt=null;
		
		try
		{
			if(check_connection() == false)
				return false;
			
			String sql="INSERT INTO offer_mkt_messages(work_request_id,agent_id,campaign,campaign_details,status,created_time) VALUES (?,?,?,?,?,?)";
			logger.info("sql query of offer_mkt_messages is :"+sql);

			log.info("sql query of offer_mkt_messages is :"+sql);
			cs_stmt=con.prepareStatement(sql);
			cs_stmt.setString(1,work_request_id);
			cs_stmt.setString(2,agent_id);
			cs_stmt.setString(3,campaign);
			cs_stmt.setString(4,campaign_details);
			cs_stmt.setString(5,status);
			cs_stmt.setTimestamp(6,created_time);
			
			int i=cs_stmt.executeUpdate();
			if(i > 0)
			{
				logger.info("adding service data to set_offer_mkt_messages table" + i);

				log.info("adding service data to set_offer_mkt_messages table" + i);
				return true;
			}
			
		}
		catch (Exception e) 
		{	
			logger.error("SQL Exception at set_offer_mkt_messages " + e);

			log.severe("SQL Exception at set_offer_mkt_messages " + e);
			return false;
		}
		finally
		{
			if (cs_stmt != null) 
			{
		        try 
		        {
		        	cs_stmt.close();
		        	con.close();
		        } 
		        catch (SQLException e) { }
		    }
		}
		
		return false;
	}
	
	
	public boolean set_card_related_action(String work_request_id,String agent_id,String account_number,String card_number,String action_type,String status,Timestamp created_time)
	{
		PreparedStatement cs_stmt=null;
		
		try
		{
			if(check_connection() == false)
				return false;
			
			String sql="INSERT INTO card_related_action(work_request_id,agent_id,account_number,card_number,action_type,"
					+ "status,created_time) VALUES (?,?,?,?,?,?,?)";
			logger.info("sql query of card_related_action is :"+sql);

			log.info("sql query of card_related_action is :"+sql);
			cs_stmt=con.prepareStatement(sql);
			cs_stmt.setString(1,work_request_id);
			cs_stmt.setString(2,agent_id);
			cs_stmt.setString(3,account_number);
			cs_stmt.setString(4,card_number);
			cs_stmt.setString(5,action_type);
			cs_stmt.setString(6,status);
			cs_stmt.setTimestamp(7, created_time);
			
			int i=cs_stmt.executeUpdate();
			if(i > 0)
			{
				logger.info("adding service data to set_card_related_action table" + i);

				log.info("adding service data to set_card_related_action table" + i);
				return true;
			}
			
		}
		catch (Exception e) 
		{	
			logger.error("SQL Exception to set_card_related_action " + e );

			log.severe("SQL Exception to set_card_related_action " + e );
			return false;
		}
		finally
		{
			if (cs_stmt != null) 
			{
		        try 
		        {
		        	cs_stmt.close();
		        	con.close();
		        } 
		        catch (SQLException e) { }
		    }
		}
		
		return false;
	}
	
	public boolean set_screen_pop_details(String work_request_id,String agent_id,String agent_extension,String cm_mobile, String account_number,String card_number,String customer_name,String client_code,String calling_no,String ucid,String direction,Timestamp created_time)
	{
		PreparedStatement cs_stmt=null;
		
		try
		{
			if(check_connection() == false)
				return false;
			
			String sql="INSERT INTO screen_pop_details(work_request_id,agent_id,agent_extension,cm_mobile,account_number,"
					+ "card_number,customer_name,client_code,calling_no,ucid,direction,created_time) "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
			logger.info("sql query of screen_pop_details is :"+sql);

			log.info("sql query of screen_pop_details is :"+sql);
			cs_stmt=con.prepareStatement(sql);
			cs_stmt.setString(1,work_request_id);
			cs_stmt.setString(2,agent_id);
			cs_stmt.setString(3,agent_extension);
			cs_stmt.setString(4,cm_mobile);
			cs_stmt.setString(5,account_number);
			cs_stmt.setString(6,card_number);
			cs_stmt.setString(7,customer_name);
			cs_stmt.setString(8,client_code);
			cs_stmt.setString(9,calling_no);
			cs_stmt.setString(10,ucid);
			cs_stmt.setString(11,direction);
			cs_stmt.setTimestamp(12,created_time);
			
			int i=cs_stmt.executeUpdate();
			if(i > 0)
			{
				logger.info("adding service data to set_screen_pop_details table" + i);

				log.info("adding service data to set_screen_pop_details table" + i);
				return true;
			}
			
		}
		catch (Exception e) 
		{	
			logger.error("SQL Exception to set screen pop details " + e );

			log.severe("SQL Exception to set screen pop details " + e );
		}
		finally
		{
			if (cs_stmt != null) 
			{
		        try 
		        {
		        	cs_stmt.close();
		        	con.close();
		        } 
		        catch (SQLException e) { }
		    }
		}
		
		return false;
	}
	
	
	
	public boolean set_agent_disposition_details(String work_request_id, String  agent_id, String client_code, String card_number, String call_notes, String disposition_group, String disposition_code, String disposition_desc, Timestamp created_time,String department, String agentname)
	{
		PreparedStatement cs_stmt = null;
		
		try
		{
			if(check_connection() == false)
				return false;
			
			String sql="INSERT INTO agent_disposition_details(work_request_id,agent_id,client_code,card_number,call_notes,disposition_group,disposition_code,disposition_desc,created_time,department,agent_name) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
			logger.info("sql query of agent_disposition_details is :"+sql);

			log.info("sql query of agent_disposition_details is :"+sql);
			cs_stmt=con.prepareStatement(sql);
			cs_stmt.setString(1,work_request_id);
			cs_stmt.setString(2,agent_id);
			cs_stmt.setString(3, client_code);
			cs_stmt.setString(4,card_number);
			cs_stmt.setString(5,call_notes);
			cs_stmt.setString(6,disposition_group);
			cs_stmt.setString(7,disposition_code);
			cs_stmt.setString(8, disposition_desc);
			cs_stmt.setTimestamp(9, created_time);
			cs_stmt.setString(10, department);
			cs_stmt.setString(11, agentname);
			
			
			int i=cs_stmt.executeUpdate();
			if(i > 0)
			{
				logger.info("adding service data to set_agent_disposition_details table" + i);

				log.info("adding service data to set_agent_disposition_details table" + i);
				return true;
			}
			
		}
		catch (Exception e) 
		{	
			logger.error("SQL Exception to set_agent_disposition_details " + e );

			log.severe("SQL Exception to set_agent_disposition_details " + e );
			return false;
		}
		finally
		{
			if (cs_stmt != null) 
			{
		        try 
		        {
		        	cs_stmt.close();
		        	con.close();
		        } 
		        catch (SQLException e) { }
		    }
		}
		
		return false;
	}
	
	public ArrayList<Get_agent_menuaccess_util>get_agent_menu_access(String agentid) 
	{	
		
		ArrayList<Get_agent_menuaccess_util>  agentmenu_list= new ArrayList<Get_agent_menuaccess_util>();
		try
		{	
			if(check_connection() == false)
			{
				return null;	
			}
			
			stmt=con.createStatement(); 
			String sql = "select a.first_name_en,a.last_name_en, b.department_short_des,b.department_name,b.permission from agent_info a join department_permission b on a.DEPARTMENT=B.department_name where a.agent_id='"+agentid+"'";
			logger.info("select query of get_agent_menu_access  is  : "+sql);

			log.info("select query of get_agent_menu_access  is  : "+sql);
			rs=stmt.executeQuery(sql); 
			
			 while(rs.next())
			 {
				 Get_agent_menuaccess_util o_agentmenu_util = new Get_agent_menuaccess_util();
				 o_agentmenu_util.first_name_en			= 	  rs.getString("FIRST_NAME_EN");	
				 o_agentmenu_util.last_name_en 		 	= 	  rs.getString("LAST_NAME_EN");
				 //o_agentmenu_util.department_id		= 	  rs.getString("department_id");
				 o_agentmenu_util.department_name	 	= 	  rs.getString("department_name");
				 o_agentmenu_util.department_short_des	=	  rs.getString("department_short_des");
				 o_agentmenu_util.permission 		 	= 	  rs.getString("permission");
				 o_agentmenu_util.code 		 		 	= 	  "Sucess";
				
				 agentmenu_list.add(o_agentmenu_util);
			 }
				
		return agentmenu_list;
		
		}
		catch (Exception e) 
		{
			logger.error("SQL Exception at the get_agent_menu_access " + e);

			log.severe("SQL Exception at the get_agent_menu_access " + e);
			
		}
		
		finally 
		{
			db_close();
		}
		return null;
	
	}
	
	

	public boolean set_acr_fail_request(String work_request_id, String client_code, String agent_id, String udfname, String udfvalue, String callid, Timestamp created_time)
	{
		PreparedStatement cs_stmt=null;
		
		try
		{
			if(check_connection() == false)
				return false;
			
			String sql="INSERT INTO acr_fail_request(work_request_id,client_code,agent_id,udfname,udfvalue,call_id,created_time) VALUES (?,?,?,?,?,?,?)";
			logger.info("sql query of acr_fail_request is :"+sql);

			log.info("sql query of acr_fail_request is :"+sql);
			cs_stmt=con.prepareStatement(sql);
			cs_stmt.setString(1,work_request_id);
			cs_stmt.setString(2,client_code);
			cs_stmt.setString(3,agent_id);
			cs_stmt.setString(4,udfname);
			cs_stmt.setString(5,udfvalue);
			cs_stmt.setString(6,callid);
			cs_stmt.setTimestamp(7,created_time);
			
			int i=cs_stmt.executeUpdate();
			if(i > 0)
			{
				logger.info("adding service data to set_acr_fail_request table" + i);

				log.info("adding service data to set_acr_fail_request table" + i);
				return true;
			}
			
		}
		catch (Exception e) 
		{	
			logger.error("SQL Exception to set acr fail request " + e );

			log.severe("SQL Exception to set acr fail request " + e );
		}
		finally
		{
			if (cs_stmt != null) 
			{
		        try 
		        {
		        	cs_stmt.close();
		        	con.close();
		        } 
		        catch (SQLException e) { }
		    }
		}
		
		return false;
	}
	
	
		
	public String date_format(String dateString)
	{
		try{
		//String dateString4 = "2019-09-17 12:28:16.922"; 
		
		SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		
		java.util.Date date4 = sdf3.parse(dateString);
		SimpleDateFormat sdf4 = new SimpleDateFormat("dd-MMM-yyyy hh:mm aa");
		
		String date = sdf4.format(date4);
		
		//System.out.println("date : "+date);
		
		return date;
		}
		catch (Exception e)
		{
			logger.error("date format error : " + e);

			log.severe("date format error : " + e);
			return null;
		}
	}
	
	
	public boolean db_close() 
	  {		  
			try 
			{
				if(con != null)
				{
					rs.close();
					stmt.close();
					con.close();	
					logger.info("DB connection closed successfully!");

					log.info("DB connection closed successfully!");
					con=null;
				}
			} 
			catch (SQLException e) 
			{
				logger.error("Close DB connection failed : " + e);

				log.severe("Close DB connection failed : " + e);
			}
		  
		return true;
	}
}

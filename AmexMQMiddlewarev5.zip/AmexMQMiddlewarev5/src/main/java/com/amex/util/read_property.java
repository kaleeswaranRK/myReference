package com.amex.util;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;


public class read_property 
{

	public read_property()
	{

	}
	
	public boolean read_config(String location) throws Exception
	{
		try 
		{
			File 	 			_xmlfile;
			Document 			_doc;	
			DocumentBuilder 	_builder;
			NodeList 			_config_node; 
			NodeList 			_widgetnode;
			
			DocumentBuilderFactory 		_obj_factory	= 	DocumentBuilderFactory.newInstance();
			_obj_factory.setIgnoringElementContentWhitespace(true);
		
			_xmlfile 		= 	new File(location);
			_builder 	 	=	_obj_factory.newDocumentBuilder();
			_doc 		 	= 	_builder.parse(_xmlfile);
			_config_node	= 	_doc.getElementsByTagName("*");
			_widgetnode		= 	_doc.getElementsByTagName("widget_name");
			
			
			get_configurations ( _config_node );
			return true;
			
		}
		catch (Exception e)
		{
			throw new Exception("Excep while reading property file : " + e.getMessage());
			
		}
	}
	
	
	private void get_configurations(NodeList _data_list ) throws Exception
	{
		config.FILE_PATH					=	get_prop_value ( _data_list , "file_path" , "" );
		config.IP_ADDRESS  					=	get_prop_value ( _data_list , "database_ip" , "" ) ;
		config.DB_USERNAME  				=	get_prop_value ( _data_list , "db_username" , "/" ) ;
		config.DB_PASSWORD  				=	get_prop_value ( _data_list , "db_password" , "/" ) ;
		config.SERVICE_NAME  				=	get_prop_value ( _data_list , "service_name" , "/" ) ;
		config.DB_PORT  					=	get_prop_value ( _data_list , "database_port" , "/" ) ;
		config.FILE_PATH_log4j				=	get_prop_value ( _data_list , "file_path_log4j" , "" );
		config.XML_KEY						=	get_prop_value ( _data_list , "xml_key" , "result" );
			
	}
	

	private String get_prop_value(NodeList _data_list, String property_name , String def_value ) throws Exception
	{	
		for ( int i=0 ; i<_data_list.getLength() ; i++)  
		{
			if (_data_list.item(i).getNodeName().equalsIgnoreCase(property_name))
			{
				return _data_list.item(i).getTextContent().toString();	
			}
		}
		return def_value ;
	}
	
		
}

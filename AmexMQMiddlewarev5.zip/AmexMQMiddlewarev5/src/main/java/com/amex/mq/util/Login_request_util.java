package com.amex.mq.util;

public class Login_request_util
{
	private String ssostr;

	public String getSsostr() {
		return ssostr;
	}
	public void setSsostr(String ssostr) {
		this.ssostr = ssostr;
	}

}

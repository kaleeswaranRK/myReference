package com.amex.mq;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.amex.util.config;
import com.amex.util.read_property;

@WebListener
public class initilize implements ServletContextListener {
	org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(initilize.class);

	static {
		try (InputStream is = initilize.class.getClassLoader().getResourceAsStream("logging.properties")) {
			LogManager.getLogManager().readConfiguration(is);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private static Logger log = Logger.getLogger("cc_ws_req");

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		on_start(sce.getServletContext().getRealPath("/"));
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {

	}

	private void on_start(String app_path) {

		read_property(app_path);

	}

	void read_property(String app_path) {

		String prop_file_path = app_path + "/WEB-INF/properties.xml";

		read_property prop = new read_property();

		try {
			prop.read_config(prop_file_path);

		} catch (Exception e) {
			log.severe("Exception in read_property  :: " + e);
			logger.info("Exception in read_property  :: " + e);

		}

		config.APP_PATH = app_path;
		logger.info("**************************");
		logger.info("Application path : " + config.APP_PATH);
		logger.info("db IP address : " + config.IP_ADDRESS);
		logger.info("db port : " + config.DB_PORT);
		logger.info("Db username : " + config.DB_USERNAME);
		logger.info("Db service name : " + config.SERVICE_NAME);
		logger.info("File path of jar : " + config.FILE_PATH);
		logger.info("File path of xml : " + config.FILE_PATH_log4j);
		logger.info("URl response xml Tag : " + config.XML_KEY);
		logger.info("**************************");

		log.info("**************************");
		log.info("Application path : " + config.APP_PATH);
		log.info("db IP address : " + config.IP_ADDRESS);
		log.info("db port : " + config.DB_PORT);
		log.info("Db username : " + config.DB_USERNAME);
		log.info("Db service name : " + config.SERVICE_NAME);
		log.info("File path of jar : " + config.FILE_PATH);
		log.info("File path of xml : " + config.FILE_PATH_log4j);
		log.info("URl response xml Tag : " + config.XML_KEY);
		log.info("**************************");
	}

}

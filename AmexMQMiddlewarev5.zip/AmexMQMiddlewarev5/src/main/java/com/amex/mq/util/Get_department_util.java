package com.amex.mq.util;

public class Get_department_util 
{
	public String refid="";
	public String action_type="";
	public String number="";
	public String description="";
	public String code="fail";

}

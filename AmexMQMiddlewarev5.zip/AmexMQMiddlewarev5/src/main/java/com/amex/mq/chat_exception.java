package com.amex.mq;

	public class chat_exception extends Exception
	{
		private static final long serialVersionUID = 1L;
		public chat_exception(String err)
		{
			//throw new jtapi_exception ( " Invalid iso pack "  );
			super(err);
		}
	}



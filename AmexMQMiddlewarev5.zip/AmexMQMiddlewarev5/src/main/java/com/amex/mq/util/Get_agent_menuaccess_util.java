package com.amex.mq.util;
public class Get_agent_menuaccess_util 
{
	public String first_name_en = "";
	public String last_name_en="";
	//public String department_id="";
	public String department_name="";
	public String department_short_des="";
	public String permission="";
	public String code="fail";
}

package com.amex.mq;

import java.io.File;
import java.util.logging.Logger;

import jakarta.ws.rs.POST;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;

import org.json.JSONObject;

import com.amex.mq.util.Login_request_util;
import com.amex.util.config;
import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.functions.AccountBalance;
import com.realsoftinc.amex.mq.functions.AccountDetail;
import com.realsoftinc.amex.mq.functions.AccountOffers;
import com.realsoftinc.amex.mq.functions.CardActivation;
import com.realsoftinc.amex.mq.functions.CardDetails;
import com.realsoftinc.amex.mq.functions.CardList;
import com.realsoftinc.amex.mq.functions.CardNoValidation;
import com.realsoftinc.amex.mq.functions.ChargeCardAccountBalance;
import com.realsoftinc.amex.mq.functions.ChargeCardDueDate;
import com.realsoftinc.amex.mq.functions.ChargeCardNoValidation;
import com.realsoftinc.amex.mq.functions.CheckCSIEnrolled;
import com.realsoftinc.amex.mq.functions.ConfirmCSIEnrollment;
import com.realsoftinc.amex.mq.functions.ContactDetails;
import com.realsoftinc.amex.mq.functions.CurrencyCode;
import com.realsoftinc.amex.mq.functions.DoBValidation;
import com.realsoftinc.amex.mq.functions.EmbosserDetail;
import com.realsoftinc.amex.mq.functions.GeneratePinMailer;
import com.realsoftinc.amex.mq.functions.LoginRequest;
import com.realsoftinc.amex.mq.functions.MRPointsReward;
import com.realsoftinc.amex.mq.functions.PaymentHistory;
import com.realsoftinc.amex.mq.functions.PinSetup;
import com.realsoftinc.amex.mq.functions.ScreePopUP;
import com.realsoftinc.amex.mq.functions.SendMREnrollment;
import com.realsoftinc.amex.mq.functions.SendMail;
import com.realsoftinc.amex.mq.functions.UnBlockPin;
import com.realsoftinc.amex.mq.functions.UniqueId;
import com.realsoftinc.amex.mq.functions.UpdateContDetails;
import com.realsoftinc.amex.mq.returnObjs.AccountBalanceReturn;
import com.realsoftinc.amex.mq.returnObjs.AccountDetailReturn;
import com.realsoftinc.amex.mq.returnObjs.AccountOffersReturn;
import com.realsoftinc.amex.mq.returnObjs.CardActivationReturn;
import com.realsoftinc.amex.mq.returnObjs.CardDetailsReturn;
import com.realsoftinc.amex.mq.returnObjs.CardListReturn;
import com.realsoftinc.amex.mq.returnObjs.CardNoValidationReturn;
import com.realsoftinc.amex.mq.returnObjs.ChargeCardAccountBalanceReturn;
import com.realsoftinc.amex.mq.returnObjs.ChargeCardDueDateReturn;
import com.realsoftinc.amex.mq.returnObjs.ChargeCardNoValidationReturn;
import com.realsoftinc.amex.mq.returnObjs.CheckCSIEnrolledReturn;
import com.realsoftinc.amex.mq.returnObjs.ConfirmCSIEnrollmentReturn;
import com.realsoftinc.amex.mq.returnObjs.ContactDetailsReturn;
import com.realsoftinc.amex.mq.returnObjs.CurrencyReturn;
import com.realsoftinc.amex.mq.returnObjs.DoBValidationReturn;
import com.realsoftinc.amex.mq.returnObjs.EmbosserDetailReturn;
import com.realsoftinc.amex.mq.returnObjs.GeneratePinMailerReturn;
import com.realsoftinc.amex.mq.returnObjs.MREnrollmentReturn;
import com.realsoftinc.amex.mq.returnObjs.MRPointsReturn;
import com.realsoftinc.amex.mq.returnObjs.PaymentHistoryReturn;
import com.realsoftinc.amex.mq.returnObjs.PinSetupReturn;
import com.realsoftinc.amex.mq.returnObjs.ScreenPopDetailsReturn;
import com.realsoftinc.amex.mq.returnObjs.SendMailReturn;
import com.realsoftinc.amex.mq.returnObjs.UnBlockPinReturn;
import com.realsoftinc.amex.mq.returnObjs.UniqueIdReturn;
import com.realsoftinc.amex.mq.returnObjs.UpdateContDetailsReturn;

@Path("mq_ws")
public class ws_request {
	private static Logger request_log = null;
	static Json_Operation o_json = null;
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager
			.getLogger(Rest_ws_request.class);

	static {
		request_log = Logger.getLogger("mq_ws_req");

		request_log = Logger.getLogger("mq_ws_req");
		o_json = new Json_Operation();
		File file = new File(config.FILE_PATH);
		String absolutePath = file.getAbsolutePath();
		if (file.exists()) {
			MQCommon.setConfigFilePath(absolutePath);
		} else {
			logger.error("Error reading AmexJMSConfig.properties file from filepath folder :" + config.FILE_PATH);

			request_log.info("Error reading AmexJMSConfig.properties file from filepath folder :" + config.FILE_PATH);
		}
	}

	@POST
	@Path("/CardActivation")
	@Produces("application/json")
	@Consumes("application/json")
	public CardActivationReturn CardActivation(String req_param) {
		logger.info("CardActivation(); Enter");

		request_log.info("CardActivation(); Enter");
		// request_log.info("CardActivation request with data :: "+req_param);
		CardActivationReturn o_CardActivationReturn = new CardActivationReturn();

		String Account_number = "";
		String Card_number = "";
		String Case_number = "";
		try {
			JSONObject json_obj = new JSONObject(req_param);
			Account_number = o_json.get_json_value(json_obj, "accountNo");
			Card_number = o_json.get_json_value(json_obj, "cardNo");
			Case_number = o_json.get_json_value(json_obj, "caseNo");
			CardActivation o_CardActivation = new CardActivation();
			logger.info("CardActivation(); Calling cardActivate function ..");

			request_log.info("CardActivation(); Calling cardActivate function ..");
			o_CardActivationReturn = o_CardActivation.cardActivate(Card_number, Account_number);
			logger.info("Response from MQ cardActivate method   :: " + o_CardActivationReturn);
			logger.info("CardActivation(); Exit");

			request_log.info("Response from MQ cardActivate method   :: " + o_CardActivationReturn);
			request_log.info("CardActivation(); Exit");

			return o_CardActivationReturn;
		} catch (Exception e) {
			logger.error("Exception in process_CardActivation_request  :: " + e);
			logger.info("CardActivation(); Exit");

			request_log.severe("Exception in process_CardActivation_request  :: " + e);
			request_log.info("CardActivation(); Exit");
			return o_CardActivationReturn;
		}

	}

	@POST
	@Path("/CardNoValidation")
	@Produces("application/json")
	@Consumes("application/json")
	public CardNoValidationReturn CardNoValidation(String req_param) {
		logger.info("CardNoValidation(); Enter");

		request_log.info("CardNoValidation(); Enter");
		// request_log.info("CardNoValidation request with data :: "+req_param);
		CardNoValidationReturn o_cnvr = new CardNoValidationReturn();
		CardNoValidation o_card_no_val = new CardNoValidation();
		String Card_number = "";
		try {
			JSONObject json_obj = new JSONObject(req_param);
			Card_number = o_json.get_json_value(json_obj, "cardNo");
			logger.info("CardNoValidation(); Calling cardValidation function ..");

			request_log.info("CardNoValidation(); Calling cardValidation function ..");
			o_cnvr = o_card_no_val.cardValidation(Card_number);
			logger.info("Response from MQ cardValidation method   :: " + o_cnvr);
			logger.info("CardNoValidation(); Exit");

			request_log.info("Response from MQ cardValidation method   :: " + o_cnvr);
			request_log.info("CardNoValidation(); Exit");
			return o_cnvr;
		} catch (Exception e) {
			logger.error("Exception in process_CardNoValidation_request  :: " + e);
			logger.info("Exception in process_CardNoValidation_request  :: " + e);

			request_log.severe("Exception in process_CardNoValidation_request  :: " + e);
			request_log.info("Exception in process_CardNoValidation_request  :: " + e);
			return o_cnvr;
		}
	}

	@POST
	@Path("/PinSetup")
	@Produces("application/json")
	@Consumes("application/json")
	public PinSetupReturn PinSetup(String req_param) {
		logger.info("PinSetup(); Enter");

		request_log.info("PinSetup(); Enter");
		// request_log.info("PinSetup request with data :: "+req_param);
		PinSetup o_pinsetup = new PinSetup();
		PinSetupReturn o_PinSetupReturn = new PinSetupReturn();
		String Card_number = "";
		String Account_number = "";
		String Pin_number = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			Card_number = o_json.get_json_value(json_obj, "cardNo");
			Account_number = o_json.get_json_value(json_obj, "accountNo");
			Pin_number = o_json.get_json_value(json_obj, "pinNo");
			logger.info("PinSetup(); Calling pinSetUp function ..");

			request_log.info("PinSetup(); Calling pinSetUp function ..");
			o_PinSetupReturn = o_pinsetup.pinSetUp(Account_number, Card_number, Pin_number);
			logger.info("Response from MQ PinSetup method   :: " + o_PinSetupReturn);
			logger.info("PinSetup(); Exit");

			request_log.info("Response from MQ PinSetup method   :: " + o_PinSetupReturn);
			request_log.info("PinSetup(); Exit");
			return o_PinSetupReturn;
		} catch (Exception e) {
			logger.error("Exception in process_Pinsetup_request  :: " + e);
			logger.info("PinSetup(); Exit");

			request_log.severe("Exception in process_Pinsetup_request  :: " + e);
			request_log.info("PinSetup(); Exit");
			return o_PinSetupReturn;
		}
	}

	@POST
	@Path("/PinUnblock")
	@Produces("application/json")
	@Consumes("application/json")
	public UnBlockPinReturn PinUnblock(String req_param) {
		logger.info("PinUnblock(); Enter");

		request_log.info("PinUnblock(); Enter");
		// request_log.info("PinUnblock request with data :: "+req_param);
		UnBlockPinReturn o_pin_util = new UnBlockPinReturn();
		UnBlockPin o_UnBlockPin = new UnBlockPin();
		String Card_number = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			Card_number = o_json.get_json_value(json_obj, "cardNo");
			logger.info("CardActivation(); Calling unBlockPin function ..");

			request_log.info("CardActivation(); Calling unBlockPin function ..");
			o_pin_util = o_UnBlockPin.unBlockPin(Card_number);
			logger.info("Response from unBlockPin method   :: " + o_pin_util);
			logger.info("PinUnblock(); Exit");

			request_log.info("Response from unBlockPin method   :: " + o_pin_util);
			request_log.info("PinUnblock(); Exit");
			return o_pin_util;
		} catch (Exception e) {
			logger.error("Exception in process_PinUnblock_request  :: " + e);

			logger.info("PinUnblock(); Exit");

			request_log.severe("Exception in process_PinUnblock_request  :: " + e);
			request_log.info("PinUnblock(); Exit");
			return o_pin_util;
		}
	}

	@POST
	@Path("/chargeCardAccountBal")
	@Produces("application/json")
	@Consumes("application/json")
	public ChargeCardAccountBalanceReturn chargeCardAccountBal(String req_param) {
		logger.info("chargeCardAccountBal(); Enter");

		request_log.info("chargeCardAccountBal(); Enter");
		// request_log.info("chargeCardAccountBal() request with data :: "+req_param);
		ChargeCardAccountBalanceReturn o_accunt_bal_return = new ChargeCardAccountBalanceReturn();
		ChargeCardAccountBalance o_acc_balnce = new ChargeCardAccountBalance();
		String acc_Num = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			acc_Num = o_json.get_json_value(json_obj, "accNumber");
			logger.info("CardActivation(); Calling chargeCardAccountBal function ..");

			request_log.info("CardActivation(); Calling chargeCardAccountBal function ..");
			o_accunt_bal_return = o_acc_balnce.chargeCardAccountBal(acc_Num);
			logger.info("Response from MQ chargeCardAccountBal method   :: " + o_accunt_bal_return);
			logger.info("chargeCardAccountBal(); Exit");

			request_log.info("Response from MQ chargeCardAccountBal method   :: " + o_accunt_bal_return);
			request_log.info("chargeCardAccountBal(); Exit");
			return o_accunt_bal_return;
		} catch (Exception e) {
			logger.error("Exception in process_chargeCardAccountBal_request  :: " + e);
			logger.info("chargeCardAccountBal(); Exit");

			request_log.severe("Exception in process_chargeCardAccountBal_request  :: " + e);
			request_log.info("CardActivation(); Exit");
			return o_accunt_bal_return;
		}
	}

	@POST
	@Path("/ChargeCardDueDate")
	@Produces("application/json")
	@Consumes("application/json")
	public ChargeCardDueDateReturn ChargeCardDueDate(String req_param) {
		logger.info("ChargeCardDueDate(); Enter");

		request_log.info("ChargeCardDueDate(); Enter");
		// request_log.info("ChargeCardDueDate request with data :: "+req_param);
		ChargeCardDueDate o_ChargeCardDueDate = new ChargeCardDueDate();
		ChargeCardDueDateReturn o_ChargeCardDueDateReturn = new ChargeCardDueDateReturn();
		String Card_number = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			Card_number = o_json.get_json_value(json_obj, "cardNo");
			logger.info("ChargeCardDueDate(); Calling chargeCardDueDate function ..");

			request_log.info("ChargeCardDueDate(); Calling chargeCardDueDate function ..");
			o_ChargeCardDueDateReturn = o_ChargeCardDueDate.chargeCardDueDate(Card_number);
			logger.info("Response from ChargeCardDueDate method   :: " + o_ChargeCardDueDateReturn);
			logger.info("ChargeCardDueDate(); Exit");

			request_log.info("Response from ChargeCardDueDate method   :: " + o_ChargeCardDueDateReturn);
			request_log.info("ChargeCardDueDate(); Exit");
			return o_ChargeCardDueDateReturn;
		} catch (Exception e) {
			logger.error("Exception in process_ChargeCardDueDate_request  :: " + e);
			logger.info("ChargeCardDueDate(); Exit");

			request_log.severe("Exception in process_ChargeCardDueDate_request  :: " + e);
			request_log.info("ChargeCardDueDate(); Exit");
			return o_ChargeCardDueDateReturn;
		}
	}

	@POST
	@Path("/ChargeCardNoValidation")
	@Produces("application/json")
	@Consumes("application/json")
	public ChargeCardNoValidationReturn ChargeCardNoValidation(String req_param) {
		logger.info("ChargeCardNoValidation(); Enter");

		request_log.info("ChargeCardNoValidation(); Enter");
		// request_log.info("ChargeCardNoValidation request with data :: "+req_param);
		ChargeCardNoValidation o_ChargeCardNoValidation = new ChargeCardNoValidation();
		ChargeCardNoValidationReturn o_ChargeCardNoValidationReturn = new ChargeCardNoValidationReturn();
		String Card_number = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			Card_number = o_json.get_json_value(json_obj, "cardNo");
			logger.info("ChargeCardNoValidation(); Calling chargeCardValidation function ..");

			request_log.info("ChargeCardNoValidation(); Calling chargeCardValidation function ..");
			o_ChargeCardNoValidationReturn = o_ChargeCardNoValidation.chargeCardValidation(Card_number);

			logger.info("Response from chargeCardValidation method   :: " + o_ChargeCardNoValidationReturn);
			logger.info("ChargeCardNoValidation(); Exit");

			request_log.info("Response from chargeCardValidation method   :: " + o_ChargeCardNoValidationReturn);
			request_log.info("ChargeCardNoValidation(); Exit");
			return o_ChargeCardNoValidationReturn;
		} catch (Exception e) {
			logger.error("Exception in process_ChargeCardNoValidation_request  :: " + e);
			logger.info("ChargeCardNoValidation(); Exit");

			request_log.severe("Exception in process_ChargeCardNoValidation_request  :: " + e);
			request_log.info("ChargeCardNoValidation(); Exit");
			return o_ChargeCardNoValidationReturn;
		}
	}

	@POST
	@Path("/CheckCSIEnrolled")
	@Produces("application/json")
	@Consumes("application/json")
	public CheckCSIEnrolledReturn CheckCSIEnrolled(String req_param) {
		logger.info("CheckCSIEnrolled(); Enter");

		request_log.info("CheckCSIEnrolled(); Enter");
		// request_log.info("CheckCSIEnrolled request with data :: "+req_param);
		CheckCSIEnrolledReturn o_CheckCSIEnrolledReturn = new CheckCSIEnrolledReturn();
		CheckCSIEnrolled o_CheckCSIEnrolled = new CheckCSIEnrolled();
		String Card_number = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			Card_number = o_json.get_json_value(json_obj, "cardNo");
			logger.info("CheckCSIEnrolled(); Calling CheckEnrolledStatus function ..");

			request_log.info("CheckCSIEnrolled(); Calling CheckEnrolledStatus function ..");
			o_CheckCSIEnrolledReturn = o_CheckCSIEnrolled.CheckEnrolledStatus(Card_number);
			logger.info("Response from CheckEnrolledStatus method   :: " + o_CheckCSIEnrolledReturn);
			logger.info("CheckCSIEnrolled(); Exit");

			request_log.info("Response from CheckEnrolledStatus method   :: " + o_CheckCSIEnrolledReturn);
			request_log.info("CheckCSIEnrolled(); Exit");
			return o_CheckCSIEnrolledReturn;
		} catch (Exception e) {
			logger.error("Exception in process_CheckEnrolledStatus_request  :: " + e);
			logger.info("CheckCSIEnrolled(); Exit");

			request_log.severe("Exception in process_CheckEnrolledStatus_request  :: " + e);
			request_log.info("CheckCSIEnrolled(); Exit");
			return o_CheckCSIEnrolledReturn;
		}
	}

	@POST
	@Path("/ConfirmCSIEnrollment")
	@Produces("application/json")
	@Consumes("application/json")
	public ConfirmCSIEnrollmentReturn ConfirmCSIEnrollment(String req_param) {
		logger.info("ConfirmCSIEnrollment(); Enter");

		request_log.info("ConfirmCSIEnrollment(); Enter");
		// request_log.info("ConfirmCSIEnrollment request with data :: "+req_param);
		ConfirmCSIEnrollment o_ConfirmCSIEnrollment = new ConfirmCSIEnrollment();
		ConfirmCSIEnrollmentReturn o_ConfirmCSIEnrollmentReturn = new ConfirmCSIEnrollmentReturn();
		String acc_Num = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			acc_Num = o_json.get_json_value(json_obj, "accountNo");
			logger.info("ConfirmCSIEnrollment(); Calling ConfirmEnrollement function ..");

			request_log.info("ConfirmCSIEnrollment(); Calling ConfirmEnrollement function ..");
			o_ConfirmCSIEnrollmentReturn = o_ConfirmCSIEnrollment.ConfirmEnrollement(acc_Num);
			logger.info("Response from ConfirmEnrollement method   :: " + o_ConfirmCSIEnrollmentReturn);
			logger.info("ConfirmCSIEnrollment(); Exit");

			request_log.info("Response from ConfirmEnrollement method   :: " + o_ConfirmCSIEnrollmentReturn);
			request_log.info("ConfirmCSIEnrollment(); Exit");
			return o_ConfirmCSIEnrollmentReturn;
		} catch (Exception e) {
			logger.error("Exception in process_ConfirmEnrollement_request  :: " + e);
			logger.info("ConfirmCSIEnrollment(); Exit");

			request_log.severe("Exception in process_ConfirmEnrollement_request  :: " + e);
			request_log.info("ConfirmCSIEnrollment(); Exit");
			return o_ConfirmCSIEnrollmentReturn;
		}
	}

	@POST
	@Path("/ContactDetails")
	@Produces("application/json")
	@Consumes("application/json")
	public ContactDetailsReturn ContactDetails(String req_param) {
		logger.info("ContactDetails(); Enter");

		request_log.info("ContactDetails(); Enter");
		// request_log.info("ContactDetails request with data :: "+req_param);
		ContactDetails o_ContactDetails = new ContactDetails();
		ContactDetailsReturn o_ContactDetailsReturn = new ContactDetailsReturn();
		String acc_Num = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			acc_Num = o_json.get_json_value(json_obj, "accountNo");
			logger.info("ContactDetails(); Calling cardActivate function ..");

			request_log.info("ContactDetails(); Calling cardActivate function ..");
			o_ContactDetailsReturn = o_ContactDetails.getContactDetails(acc_Num);
			logger.info("Response from getContactDetails method   :: " + o_ContactDetailsReturn);
			logger.info("ContactDetails(); Exit");

			request_log.info("Response from getContactDetails method   :: " + o_ContactDetailsReturn);
			request_log.info("ContactDetails(); Exit");
			return o_ContactDetailsReturn;
		} catch (Exception e) {
			logger.info("Exception in process_ContactDetails_request  :: " + e);
			logger.info("ContactDetails(); Exit");

			request_log.severe("Exception in process_ContactDetails_request  :: " + e);
			request_log.info("ContactDetails(); Exit");
			return o_ContactDetailsReturn;
		}
	}

	@POST
	@Path("/CurrencyCode")
	@Produces("application/json")
	@Consumes("application/json")
	public CurrencyReturn CurrencyCode(String req_param) {
		logger.info("CurrencyCode(); Enter");

		request_log.info("CurrencyCode(); Enter");
		// request_log.info("CurrencyCode request with data :: "+req_param);
		CurrencyCode o_CurrencyCode = new CurrencyCode();
		CurrencyReturn o_CurrencyReturn = new CurrencyReturn();
		String card_num = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			card_num = o_json.get_json_value(json_obj, "cardNo");
			logger.info("CurrencyCode(); Calling getCurrenyCode function ..");

			request_log.info("CurrencyCode(); Calling getCurrenyCode function ..");
			o_CurrencyReturn = o_CurrencyCode.getCurrenyCode(card_num);
			logger.info("Response from getCurrenyCode method   :: " + o_CurrencyReturn);
			logger.info("CurrencyCode(); Exit");

			request_log.info("Response from getCurrenyCode method   :: " + o_CurrencyReturn);
			request_log.info("CurrencyCode(); Exit");
			return o_CurrencyReturn;
		} catch (Exception e) {
			logger.error("Exception in process_getCurrenyCode_request  :: " + e);
			logger.info("CurrencyCode(); Exit");

			request_log.severe("Exception in process_getCurrenyCode_request  :: " + e);
			request_log.info("CurrencyCode(); Exit");
			return o_CurrencyReturn;
		}
	}

	@POST
	@Path("/DoBValidation")
	@Produces("application/json")
	@Consumes("application/json")
	public DoBValidationReturn DoBValidation(String req_param) {
		logger.info("DoBValidation(); Enter");
		request_log.info("DoBValidation(); Enter");
		// request_log.info("DoBValidation request with data :: "+req_param);
		DoBValidation o_DoBValidation = new DoBValidation();
		DoBValidationReturn o_DoBValidationReturn = new DoBValidationReturn();
		String accountNo = "";
		String Dob = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			accountNo = o_json.get_json_value(json_obj, "accountNo");
			Dob = o_json.get_json_value(json_obj, "Dob");
			logger.info("DoBValidation(); Calling dateOfBirthValidation function ..");

			request_log.info("DoBValidation(); Calling dateOfBirthValidation function ..");
			o_DoBValidationReturn = o_DoBValidation.dateOfBirthValidation(accountNo, Dob);
			logger.info("Response from dateOfBirthValidation method   :: " + o_DoBValidationReturn);
			logger.info("DoBValidation(); Exit");

			request_log.info("Response from dateOfBirthValidation method   :: " + o_DoBValidationReturn);
			request_log.info("DoBValidation(); Exit");
			return o_DoBValidationReturn;
		} catch (Exception e) {
			logger.info("Exception in process_DoBValidation_request  :: " + e);
			logger.info("DoBValidation(); Exit");

			request_log.severe("Exception in process_DoBValidation_request  :: " + e);
			request_log.info("DoBValidation(); Exit");
			return o_DoBValidationReturn;
		}
	}

	@POST
	@Path("/AccountBalance")
	@Produces("application/json")
	@Consumes("application/json")
	public AccountBalanceReturn AccountBalance(String req_param) {
		logger.info("AccountBalance(); Enter");

		request_log.info("AccountBalance(); Enter");
		// request_log.info("AccountBalance request with data :: "+req_param);
		AccountBalance o_acc_balnce = new AccountBalance();
		AccountBalanceReturn o_acc_bal_return = new AccountBalanceReturn();
		String acc_Num = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			acc_Num = o_json.get_json_value(json_obj, "accNumber");
			logger.info("AccountBalance(); Calling accountBal function ..");

			request_log.info("AccountBalance(); Calling accountBal function ..");
			o_acc_bal_return = o_acc_balnce.accountBal(acc_Num);
			logger.info("Response from accountBal method   :: " + o_acc_bal_return);
			logger.info("AccountBalance(); Exit");

			request_log.info("Response from accountBal method   :: " + o_acc_bal_return);
			request_log.info("AccountBalance(); Exit");
			return o_acc_bal_return;
		} catch (Exception e) {
			logger.error("Exception in process_AccountBalance_request  :: " + e);
			logger.info("AccountBalance(); Exit");

			request_log.severe("Exception in process_AccountBalance_request  :: " + e);
			request_log.info("AccountBalance(); Exit");
			return o_acc_bal_return;
		}
	}

	@POST
	@Path("/EmbosserDetail")
	@Produces("application/json")
	@Consumes("application/json")
	public EmbosserDetailReturn EmbosserDetail(String req_param) {
		logger.info("EmbosserDetail(); Enter");

		request_log.info("EmbosserDetail(); Enter");
		// request_log.info("EmbosserDetail request with data :: "+req_param);
		EmbosserDetail o_EmbosserDetail = new EmbosserDetail();
		EmbosserDetailReturn o_EmbosserDetailReturn = new EmbosserDetailReturn();
		String card_num = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			card_num = o_json.get_json_value(json_obj, "cardNo");
			logger.info("EmbosserDetail(); Calling getEmbosserDetail function ..");

			request_log.info("EmbosserDetail(); Calling getEmbosserDetail function ..");
			o_EmbosserDetailReturn = o_EmbosserDetail.getEmbosserDetail(card_num);
			logger.info("Response from getEmbosserDetail method   :: " + o_EmbosserDetailReturn);
			logger.info("EmbosserDetail(); Exit");

			request_log.info("Response from getEmbosserDetail method   :: " + o_EmbosserDetailReturn);
			request_log.info("EmbosserDetail(); Exit");
			return o_EmbosserDetailReturn;
		} catch (Exception e) {
			logger.error("Exception in process_EmbosserDetail_request  :: " + e);
			logger.info("EmbosserDetail(); Exit");

			request_log.severe("Exception in process_EmbosserDetail_request  :: " + e);
			request_log.info("EmbosserDetail(); Exit");
			return o_EmbosserDetailReturn;
		}
	}

	@POST
	@Path("/LoginRequest")
	@Produces("application/json")
	public Login_request_util LoginRequest() {
		logger.info("LoginRequest(); Enter");

		request_log.info("LoginRequest(); Enter");
		LoginRequest o_loginRequest = new LoginRequest();
		Login_request_util o_login_util = new Login_request_util();
		String ssoStr = null;
		try {
			logger.info("LoginRequest(); Calling loginReq function ..");

			request_log.info("LoginRequest(); Calling loginReq function ..");
			ssoStr = o_loginRequest.loginReq();
			if (ssoStr != null) {
				o_login_util.setSsostr(ssoStr);
			}
			logger.info("Response from loginReq method   :: " + ssoStr);
			logger.info("LoginRequest(); Exit");

			request_log.info("Response from loginReq method   :: " + ssoStr);
			request_log.info("LoginRequest(); Exit");
			return o_login_util;
		} catch (Exception e) {
			logger.error("Exception in process_LoginRequest_request  :: " + e);
			logger.info("LoginRequest(); Exit");

			request_log.severe("Exception in process_LoginRequest_request  :: " + e);
			request_log.info("LoginRequest(); Exit");
			return o_login_util;
		}
	}

	@POST
	@Path("/MRPointsReward")
	@Produces("application/json")
	@Consumes("application/json")
	public MRPointsReturn MRPointsReward(String req_param) {
		logger.info("MRPointsReward(); Enter");

		request_log.info("MRPointsReward(); Enter");
		// request_log.info("MRPointsReward request with data :: "+req_param);
		MRPointsReward o_MRPointsReward = new MRPointsReward();
		MRPointsReturn o_MRPointsReturn = new MRPointsReturn();
		String acc_Num = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			acc_Num = o_json.get_json_value(json_obj, "accNumber");
			logger.info("MRPointsReward(); Calling getMRPoints function ..");

			request_log.info("MRPointsReward(); Calling getMRPoints function ..");
			o_MRPointsReturn = o_MRPointsReward.getMRPoints(acc_Num);
			logger.info("Response from getMRPoints method   :: " + o_MRPointsReturn);
			logger.info("MRPointsReward(); Exit");

			request_log.info("Response from getMRPoints method   :: " + o_MRPointsReturn);
			request_log.info("MRPointsReward(); Exit");
			return o_MRPointsReturn;
		} catch (Exception e) {
			logger.error("Exception in process_MRPointsReward_request  :: " + e);
			logger.info("MRPointsReward(); Exit");

			request_log.severe("Exception in process_MRPointsReward_request  :: " + e);
			request_log.info("MRPointsReward(); Exit");
			return o_MRPointsReturn;
		}
	}

	@POST
	@Path("/PaymentHistory")
	@Produces("application/json")
	@Consumes("application/json")
	public PaymentHistoryReturn PaymentHistory(String req_param) {
		logger.info("PaymentHistory(); Enter");

		request_log.info("PaymentHistory(); Enter");
		// request_log.info("PaymentHistory request with data :: "+req_param);
		PaymentHistory o_PaymentHistory = new PaymentHistory();
		PaymentHistoryReturn o_PaymentHistoryReturn = new PaymentHistoryReturn();
		String acc_Num = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			acc_Num = o_json.get_json_value(json_obj, "accNumber");
			logger.info("PaymentHistory(); Calling getPaymentHistory function ..");

			request_log.info("PaymentHistory(); Calling getPaymentHistory function ..");
			o_PaymentHistoryReturn = o_PaymentHistory.getPaymentHistory(acc_Num);
			logger.info("Response from getPaymentHistory method   :: " + o_PaymentHistoryReturn);
			logger.info("PaymentHistory(); Exit");

			request_log.info("Response from getPaymentHistory method   :: " + o_PaymentHistoryReturn);
			request_log.info("PaymentHistory(); Exit");
			return o_PaymentHistoryReturn;
		} catch (Exception e) {
			logger.error("Exception in process_PaymentHistory_request  :: " + e);
			logger.info("PaymentHistory(); Exit");

			request_log.severe("Exception in process_PaymentHistory_request  :: " + e);
			request_log.info("PaymentHistory(); Exit");
			return o_PaymentHistoryReturn;
		}
	}

	@POST
	@Path("/screenPop")
	@Produces("application/json")
	@Consumes("application/json")
	public ScreenPopDetailsReturn screenPop(String req_param) {
		logger.info("screenPop(); Enter");

		request_log.info("screenPop(); Enter");
		// request_log.info("screenPop request with data :: "+req_param);
		ScreenPopDetailsReturn o_ScreenPopDetailsReturn = new ScreenPopDetailsReturn();
		ScreePopUP o_scrrenpop = new ScreePopUP();
		String acc_Num = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			acc_Num = o_json.get_json_value(json_obj, "accNumber");
			logger.info("screenPop(); Calling screenPop function ..");

			request_log.info("screenPop(); Calling screenPop function ..");
			o_ScreenPopDetailsReturn = o_scrrenpop.screenPop(acc_Num);
			logger.info("Response from screenPop method   :: " + o_ScreenPopDetailsReturn);
			logger.info("screenPop(); Exit");

			request_log.info("Response from screenPop method   :: " + o_ScreenPopDetailsReturn);
			request_log.info("screenPop(); Exit");
			return o_ScreenPopDetailsReturn;
		} catch (Exception e) {
			logger.error("Exception in process_screenPop_request  :: " + e);
			logger.info("screenPop(); Exit");

			request_log.severe("Exception in process_screenPop_request  :: " + e);
			request_log.info("screenPop(); Exit");
			return o_ScreenPopDetailsReturn;
		}
	}

	@POST
	@Path("/SendMail")
	@Produces("application/json")
	@Consumes("application/json")
	public SendMailReturn SendMail(String req_param) {
		logger.info("SendMail(); Enter");

		request_log.info("SendMail(); Enter");
		// request_log.info("SendMail request with data :: "+req_param);
		SendMailReturn o_SendMailReturn = new SendMailReturn();
		SendMail o_sendmail = new SendMail();
		String language = "";
		String emailAddress = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			language = o_json.get_json_value(json_obj, "language");
			emailAddress = o_json.get_json_value(json_obj, "emailAddress");
			logger.info("SendMail(); Calling sendMailAttachment function ..");

			request_log.info("SendMail(); Calling sendMailAttachment function ..");
			o_SendMailReturn = o_sendmail.sendMailAttachment(language, emailAddress);
			logger.info("Response from sendMailAttachment method   :: " + o_SendMailReturn);
			logger.info("SendMail(); Exit");

			request_log.info("Response from sendMailAttachment method   :: " + o_SendMailReturn);
			request_log.info("SendMail(); Exit");
			return o_SendMailReturn;
		} catch (Exception e) {
			logger.error("Exception in process_SendMail_request  :: " + e);
			logger.info("SendMail(); Exit");

			request_log.severe("Exception in process_SendMail_request  :: " + e);
			request_log.info("SendMail(); Exit");
			return o_SendMailReturn;
		}
	}

	@POST
	@Path("/SendMREnrollment")
	@Produces("application/json")
	@Consumes("application/json")
	public MREnrollmentReturn SendMREnrollment(String req_param) {
		logger.info("SendMREnrollment(); Enter");

		request_log.info("SendMREnrollment(); Enter");
		// request_log.info("SendMREnrollment request with data :: "+req_param);
		MREnrollmentReturn o_MREnrollmentReturn = new MREnrollmentReturn();
		SendMREnrollment o_SendMREnrollment = new SendMREnrollment();
		String card_Num = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			card_Num = o_json.get_json_value(json_obj, "cardNo");
			logger.info("SendMREnrollment(); Calling sendMREnrollment function ..");

			request_log.info("SendMREnrollment(); Calling sendMREnrollment function ..");
			o_MREnrollmentReturn = o_SendMREnrollment.sendMREnrollment(card_Num);
			logger.info("Response from sendMREnrollment method   :: " + o_MREnrollmentReturn);
			logger.info("SendMREnrollment(); Exit");

			request_log.info("Response from sendMREnrollment method   :: " + o_MREnrollmentReturn);
			request_log.info("SendMREnrollment(); Exit");
			return o_MREnrollmentReturn;
		} catch (Exception e) {
			logger.error("Exception in process_SendMREnrollment_request  :: " + e);
			logger.info("SendMREnrollment(); Exit");

			request_log.severe("Exception in process_SendMREnrollment_request  :: " + e);
			request_log.info("SendMREnrollment(); Exit");
			return o_MREnrollmentReturn;
		}
	}

	@POST
	@Path("/UnBlockPin")
	@Produces("application/json")
	@Consumes("application/json")
	public UnBlockPinReturn UnBlockPin(String req_param) {
		logger.info("UnBlockPin(); Enter");

		request_log.info("UnBlockPin(); Enter");
		// request_log.info("UnBlockPin request with data :: "+req_param);
		UnBlockPin o_UnBlockPin = new UnBlockPin();
		UnBlockPinReturn o_UnBlockPinReturn = new UnBlockPinReturn();
		String card_Num = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);
			card_Num = o_json.get_json_value(json_obj, "cardNo");
			logger.info("UnBlockPin(); Calling unBlockPin function ..");

			request_log.info("UnBlockPin(); Calling unBlockPin function ..");
			o_UnBlockPinReturn = o_UnBlockPin.unBlockPin(card_Num);
			logger.info("Response from UnBlockPin method   :: " + o_UnBlockPinReturn);
			logger.info("UnBlockPin(); Exit");

			request_log.info("Response from UnBlockPin method   :: " + o_UnBlockPinReturn);
			request_log.info("UnBlockPin(); Exit");
			return o_UnBlockPinReturn;
		} catch (Exception e) {
			logger.error("Exception in process_UnBlockPin_request  :: " + e);
			logger.info("UnBlockPin(); Exit");

			request_log.severe("Exception in process_UnBlockPin_request  :: " + e);
			request_log.info("UnBlockPin(); Exit");
			return o_UnBlockPinReturn;
		}
	}

	@POST
	@Path("/UniqueId")
	@Produces("application/json")
	@Consumes("application/json")
	public UniqueIdReturn UniqueId(String req_param) {
		logger.info("UniqueId(); Enter");

		request_log.info("UniqueId(); Enter");
		// request_log.info("UniqueId request with data :: "+req_param);
		UniqueId o_UniqueId = new UniqueId();
		UniqueIdReturn o_UniqueIdReturn = new UniqueIdReturn();
		String uniqueId = "";
		try {
			JSONObject json_obj = new JSONObject(req_param);
			uniqueId = o_json.get_json_value(json_obj, "uniqueId");
			logger.info("UniqueId(); Calling validateUniqueId function ..");

			request_log.info("UniqueId(); Calling validateUniqueId function ..");
			o_UniqueIdReturn = o_UniqueId.validateUniqueId(uniqueId);
			logger.info("Response from validateUniqueId method   :: " + o_UniqueIdReturn);
			logger.info("UniqueId(); Exit");

			request_log.info("Response from validateUniqueId method   :: " + o_UniqueIdReturn);
			request_log.info("UniqueId(); Exit");
			return o_UniqueIdReturn;
		} catch (Exception e) {
			logger.error("Exception in process_UniqueId_request  :: " + e);
			logger.info("UniqueId(); Exit");

			request_log.severe("Exception in process_UniqueId_request  :: " + e);
			request_log.info("UniqueId(); Exit");
			return o_UniqueIdReturn;
		}
	}

	@POST
	@Path("/UpdateContDetails")
	@Produces("application/json")
	@Consumes("application/json")
	public UpdateContDetailsReturn UpdateContDetails(String req_param) {
		logger.info("UpdateContDetails(); Enter");

		request_log.info("UpdateContDetails(); Enter");
		// request_log.info("UpdateContDetails request with data :: "+req_param);
		UpdateContDetailsReturn o_UpdateContDetailsReturn = new UpdateContDetailsReturn();
		UpdateContDetails o_UpdateContDetails = new UpdateContDetails();
		String Card_Num = "";
		String WorkNoCC = "";
		String WorkNo = "";
		String HomeNoCC = "";
		String HomeNo = "";
		String MobNoCC = "";
		String MobNo = "";
		try {
			JSONObject json_obj = new JSONObject(req_param);
			Card_Num = o_json.get_json_value(json_obj, "cardNo");
			WorkNoCC = o_json.get_json_value(json_obj, "WorkNoCC");
			WorkNo = o_json.get_json_value(json_obj, "WorkNo");
			HomeNoCC = o_json.get_json_value(json_obj, "HomeNoCC");
			HomeNo = o_json.get_json_value(json_obj, "HomeNo");
			MobNoCC = o_json.get_json_value(json_obj, "MobNoCC");
			MobNo = o_json.get_json_value(json_obj, "MobNo");
			logger.info("UpdateContDetails(); Calling updateDetails function ..");

			request_log.info("UpdateContDetails(); Calling updateDetails function ..");
			o_UpdateContDetailsReturn = o_UpdateContDetails.updateDetails(Card_Num, WorkNoCC, WorkNo, HomeNoCC, HomeNo,
					MobNoCC, MobNo);
			logger.info("Response from updateDetails method   :: " + o_UpdateContDetailsReturn);
			logger.info("UpdateContDetails(); Exit");

			request_log.info("Response from updateDetails method   :: " + o_UpdateContDetailsReturn);
			request_log.info("UpdateContDetails(); Exit");
			return o_UpdateContDetailsReturn;
		} catch (Exception e) {
			logger.info("Exception in process_UpdateContDetails_request  :: " + e);
			logger.info("UpdateContDetails(); Exit");

			request_log.severe("Exception in process_UpdateContDetails_request  :: " + e);
			request_log.info("UpdateContDetails(); Exit");
			return o_UpdateContDetailsReturn;
		}
	}

	@POST
	@Path("/GetCardList")
	@Produces("application/json")
	@Consumes("application/json")
	public CardListReturn cardList(String req_param) {
		logger.info("cardList(); Enter");

		request_log.info("cardList(); Enter");
		// request_log.info("cardList request with data :: "+req_param);
		CardList o_card_list = new CardList();
		CardListReturn o_CardListReturn = new CardListReturn();
		String Mobile_number = "";
		String CardNo = "";
		String Firstname = "";
		String Familyname = "";
		String ClientCode = "";
		String legalId = "";
		try {
			JSONObject json_obj = new JSONObject(req_param);
			Mobile_number = o_json.get_json_value(json_obj, "mobileNo");
			CardNo = o_json.get_json_value(json_obj, "cardNo");
			Firstname = o_json.get_json_value(json_obj, "firstName");
			Familyname = o_json.get_json_value(json_obj, "familyName");
			ClientCode = o_json.get_json_value(json_obj, "clientCode");
			legalId = o_json.get_json_value(json_obj, "LegalId");
			logger.info("cardList(); Calling cardList function ..");

			request_log.info("cardList(); Calling cardList function ..");
			o_CardListReturn = o_card_list.cardList(Mobile_number, CardNo, Firstname, Familyname, ClientCode, legalId);
			logger.info("Response from cardList method   :: " + o_CardListReturn);
			logger.info("cardList(); Exit");

			request_log.info("Response from cardList method   :: " + o_CardListReturn);
			request_log.info("cardList(); Exit");
			return o_CardListReturn;
		} catch (Exception e) {
			logger.info("Exception in process_cardList_request  :: " + e);
			logger.info("cardList(); Exit");

			request_log.severe("Exception in process_cardList_request  :: " + e);
			request_log.info("cardList(); Exit");
			return o_CardListReturn;
		}
	}

	@POST
	@Path("/CardDetail")
	@Produces("application/json")
	@Consumes("application/json")
	public CardDetailsReturn cardDetail(String req_param) {
		logger.info("cardDetail(); Enter");

		request_log.info("cardDetail(); Enter");
		// request_log.info("cardDetail request with data :: "+req_param);
		CardDetails o_carddetails = new CardDetails();
		CardDetailsReturn o_carddetails_return = new CardDetailsReturn();
		String Card_number = "";
		try {
			JSONObject json_obj = new JSONObject(req_param);
			Card_number = o_json.get_json_value(json_obj, "cardNo");
			logger.info("cardDetail(); Calling cardDetail function ..");

			request_log.info("cardDetail(); Calling cardDetail function ..");
			o_carddetails_return = o_carddetails.cardDetail(Card_number);
			logger.info("Response from cardDetail method   :: " + o_carddetails_return);
			logger.info("cardDetail(); Exit");

			request_log.info("Response from cardDetail method   :: " + o_carddetails_return);
			request_log.info("cardDetail(); Exit");
			return o_carddetails_return;
		} catch (Exception e) {
			logger.info("Exception in process_cardDetail_request  :: " + e);
			logger.info("cardDetail(); Exit");

			request_log.severe("Exception in process_cardDetail_request  :: " + e);
			request_log.info("cardDetail(); Exit");
			return o_carddetails_return;
		}
	}

	@POST
	@Path("/AccountDetail")
	@Produces("application/json")
	@Consumes("application/json")
	public AccountDetailReturn accountDetail(String req_param) {
		logger.info("accountDetail(); Enter");

		request_log.info("accountDetail(); Enter");
		// request_log.info("accountDetail request with data :: "+req_param);
		AccountDetail o_accountdetails = new AccountDetail();
		AccountDetailReturn o_accountdetails_return = new AccountDetailReturn();
		String Account_number = "";
		try {
			JSONObject json_obj = new JSONObject(req_param);
			Account_number = o_json.get_json_value(json_obj, "accountNo");
			logger.info("accountDetail(); Calling accountDetail function ..");

			request_log.info("accountDetail(); Calling accountDetail function ..");
			o_accountdetails_return = o_accountdetails.accountDetail(Account_number);
			logger.info("Response from accountDetail method   :: " + o_accountdetails);
			logger.info("accountDetail(); Exit");

			request_log.info("Response from accountDetail method   :: " + o_accountdetails);
			request_log.info("accountDetail(); Exit");
			return o_accountdetails_return;
		} catch (Exception e) {
			logger.error("Exception in process_accountDetail_request  :: " + e);
			logger.info("accountDetail(); Exit");

			request_log.severe("Exception in process_accountDetail_request  :: " + e);
			request_log.info("accountDetail(); Exit");
			return o_accountdetails_return;
		}
	}

	@POST
	@Path("/AccountOffers")
	@Produces("application/json")
	@Consumes("application/json")
	public AccountOffersReturn accountOffers(String req_param) {
		logger.info("accountOffers(); Enter");

		request_log.info("accountOffers(); Enter");
		// request_log.info("accountOffers request with data :: "+req_param);
		AccountOffers o_accountoffer = new AccountOffers();
		AccountOffersReturn o_accountoffer_return = new AccountOffersReturn();
		String account_number = "";
		String campaign_Name = "";
		String start_Date = "";
		String end_Date = "";
		String campaign_Detail = "";
		String campaign_Status = "";
		String origine_Flag = "";
		try {
			JSONObject json_obj = new JSONObject(req_param);
			account_number = o_json.get_json_value(json_obj, "accountNo");
			campaign_Name = o_json.get_json_value(json_obj, "campaignName");
			start_Date = o_json.get_json_value(json_obj, "startDate");
			end_Date = o_json.get_json_value(json_obj, "endDate");
			campaign_Detail = o_json.get_json_value(json_obj, "campaignDetail");
			campaign_Status = o_json.get_json_value(json_obj, "campaignStatus");
			origine_Flag = o_json.get_json_value(json_obj, "OrigineFlag");
			logger.info("accountOffers(); Calling accountOffers function ..");

			request_log.info("accountOffers(); Calling accountOffers function ..");
			o_accountoffer_return = o_accountoffer.accountOffers(account_number, campaign_Name, start_Date, end_Date,
					campaign_Detail, campaign_Status, origine_Flag);
			logger.info("Response from accountOffers method   :: " + o_accountoffer_return);
			logger.info("accountOffers(); Exit");

			request_log.info("Response from accountOffers method   :: " + o_accountoffer_return);
			request_log.info("accountOffers(); Exit");
			return o_accountoffer_return;
		} catch (Exception e) {
			logger.error("Exception in process_accountOffers_request  :: " + e);
			logger.info("accountOffers(); Exit");

			request_log.severe("Exception in process_accountOffers_request  :: " + e);
			request_log.info("accountOffers(); Exit");
			return o_accountoffer_return;
		}
	}

	@POST
	@Path("/GeneratePinMailer")
	@Produces("application/json")
	@Consumes("application/json")
	public GeneratePinMailerReturn GeneratePinMailer(String req_param) {
		logger.info("GeneratePinMailer(); Enter");

		request_log.info("GeneratePinMailer(); Enter");
		// request_log.info("GeneratePinMailer request with data :: "+req_param);
		GeneratePinMailer o_generate_pin_mailer = new GeneratePinMailer();
		GeneratePinMailerReturn o_generatepin_return = new GeneratePinMailerReturn();
		String Account_number = "";
		String card_num = "";
		try {
			JSONObject json_obj = new JSONObject(req_param);
			Account_number = o_json.get_json_value(json_obj, "accountNo");
			card_num = o_json.get_json_value(json_obj, "cardNo");
			logger.info("GeneratePinMailer(); Calling generatePinMailer function ..");

			request_log.info("GeneratePinMailer(); Calling generatePinMailer function ..");
			o_generatepin_return = o_generate_pin_mailer.generatePinMailer(Account_number, card_num);
			logger.info("Response from GeneratePinMailer method   :: " + o_generatepin_return);
			logger.info("GeneratePinMailer(); Exit");

			request_log.info("Response from GeneratePinMailer method   :: " + o_generatepin_return);
			request_log.info("GeneratePinMailer(); Exit");
			return o_generatepin_return;
		} catch (Exception e) {
			logger.error("Exception in process_GeneratePinMailer_request  :: " + e);
			logger.info("GeneratePinMailer(); Exit");

			request_log.severe("Exception in process_GeneratePinMailer_request  :: " + e);
			request_log.info("GeneratePinMailer(); Exit");
			return o_generatepin_return;
		}
	}

}

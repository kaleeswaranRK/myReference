package com.amex.mq.util;

public class Get_callnotes_util 
{
	public String agent_id="";
	public String call_notes="";
	public String created_time="";
	public String code="fail";
	public String dispositionCode="";
	public String dispositionDesc="";
	public String department ="";

}

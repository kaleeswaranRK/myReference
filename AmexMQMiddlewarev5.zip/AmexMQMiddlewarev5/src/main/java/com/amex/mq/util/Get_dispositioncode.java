package com.amex.mq.util;

public class Get_dispositioncode 
{	
	public String refid = "";
	public String group_type = "";
	public String direction="";
	public String disp_number ="";
	public String disp_desc = "";
	public String code="fail";

}

package com.amex.mq;

import java.io.File;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.amex.mq.util.Get_agent_menuaccess_util;
import com.amex.mq.util.Get_callnotes_util;
import com.amex.mq.util.Get_department_util;
import com.amex.mq.util.Get_dispositioncode;
import com.amex.mq.util.resp_util;
import com.amex.util.config;
import com.amex.util.db_operations;
import com.amex.util.soap_req;
import com.realsoftinc.amex.mq.common.MQCommon;

import jakarta.ws.rs.POST;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;

@Path("/cc_ws")
public class Rest_ws_request {

	private static Logger request_log = null;
	static Json_Operation o_json = null;

	org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(Rest_ws_request.class);

	static {
		File file = new File(config.FILE_PATH);
		String absolutePath = file.getAbsolutePath();
		request_log = Logger.getLogger("cc_ws_req");
		if (file.exists()) {
			MQCommon.setConfigFilePath(absolutePath);
		} else {
			request_log.info("Error reading AmexJMSConfig.properties file from filepath folder :" + config.FILE_PATH);

		}

		o_json = new Json_Operation();
	}

	@POST
	@Path("/getdispotion")
	@Produces("application/json")
	public ArrayList<Get_dispositioncode> getdispotion() {
		request_log.info("getdispotion(); Enter");
		logger.info("getdispotion(); Enter");
		ArrayList<Get_dispositioncode> dispotion_code = new ArrayList<Get_dispositioncode>();
		db_operations o_db_operation = new db_operations();
		Get_dispositioncode o_callnotes_util = null;

		try {
			request_log.info("getdispotion(); Calling db get_dispositioncode_details function ..");
			logger.info("getdispotion(); Calling db get_dispositioncode_details function ..");
			dispotion_code = o_db_operation.get_dispositioncode_details();

			/*
			 * if(dispotion_code != null) {
			 * request_log.info("disposition details are fetched from db  "); return
			 * dispotion_code; }
			 */
			if (dispotion_code == null || dispotion_code.isEmpty()) {
				logger.info("no data available in disposition table ");
				request_log.info("no data available in disposition table ");
				o_callnotes_util = new Get_dispositioncode();
				/*
				 * if (dispotion_code ==null) dispotion_code.add(o_callnotes_util) will throw
				 * null pointer Exception;
				 */
				dispotion_code.add(o_callnotes_util);
				return dispotion_code;
			}
			logger.info("disposition(); data fetched from db  ");
			logger.info("getdispotion(); Exit");
			request_log.info("disposition(); data fetched from db  ");
			request_log.info("getdispotion(); Exit");
		} catch (Exception e) {
			dispotion_code.add(o_callnotes_util);
			logger.error("Exception in process_getdispotion_request  :: " + e);
			logger.info("getdispotion(); Exit");
			request_log.severe("Exception in process_getdispotion_request  :: " + e);
			request_log.info("getdispotion(); Exit");
			return dispotion_code;
		}
		return dispotion_code;
	}

	@POST
	@Path("/gettransfernumDetails")
	@Produces("application/json")
	public ArrayList<Get_department_util> get_transfer_num_details() {
		request_log.info("get_transfer_num_details(); Enter");
		logger.info("get_transfer_num_details(); Enter");
		ArrayList<Get_department_util> department_list = new ArrayList<Get_department_util>();
		db_operations o_db_operation = new db_operations();
		Get_department_util o_callnotes_util = null;

		try {
			request_log.info("get_transfer_num_details(); Calling db get_transfer_num_details function ..");
			logger.info("get_transfer_num_details(); Calling db get_transfer_num_details function ..");
			department_list = o_db_operation.get_transfer_num_details();

			if (department_list == null || department_list.isEmpty()) {
				logger.info("no data available in transfer_num_details table ");
				request_log.info("no data available in transfer_num_details table ");
				o_callnotes_util = new Get_department_util();
				/*
				 * if (department_list ==null) department_list.add(o_callnotes_util) will throw
				 * null pointer Exception;
				 */
				department_list.add(o_callnotes_util);
				return department_list;
			}
			logger.info("get_transfer_num_details(); data fetched from db  ");
			logger.info("get_transfer_num_details(); Exit");
			request_log.info("get_transfer_num_details(); data fetched from db  ");
			request_log.info("get_transfer_num_details(); Exit");

		} catch (Exception e) {
			department_list.add(o_callnotes_util);
			logger.error("Exception in process_get_transfer_num_details_request  :: " + e);
			logger.info("get_transfer_num_details(); Exit");
			request_log.severe("Exception in process_get_transfer_num_details_request  :: " + e);
			request_log.info("get_transfer_num_details(); Exit");
			return department_list;
		}
		return department_list;
	}

	@POST
	@Path("/getcallnotes")
	@Consumes("application/json")
	@Produces("application/json")
	public ArrayList<Get_callnotes_util> get_callnotes(String req_param) {
		request_log.info("get_callnotes(); Enter");
		logger.info("get_callnotes(); Enter");
		// request_log.info("get_callnotes request with data :: "+req_param);
		ArrayList<Get_callnotes_util> callnotes_list = new ArrayList<Get_callnotes_util>();
		db_operations o_db_operation = new db_operations();
		Get_callnotes_util o_callnotes_util = null;
		String client_code;

		try {
			JSONObject json_obj = new JSONObject(req_param);
			client_code = o_json.get_json_value(json_obj, "clientCode");

			if (client_code.equals("") || client_code.equalsIgnoreCase("NA")) {
				o_callnotes_util = new Get_callnotes_util();
				o_callnotes_util.code = "Client code is empty or NA";
				callnotes_list.add(o_callnotes_util);
				return callnotes_list;
			}
			logger.info("get_callnotes(); data fetched from db  ");
			logger.info("Request to db getcallnotes method : " + client_code);
			request_log.info("get_callnotes(); data fetched from db  ");
			request_log.info("Request to db getcallnotes method : " + client_code);
			callnotes_list = o_db_operation.getcallnotes(client_code);

			if (callnotes_list == null || callnotes_list.isEmpty()) {
				logger.info("invalid Client Code or table is empty : " + client_code);
				logger.info("get_callnotes(); Exit");
				request_log.info("invalid Client Code or table is empty : " + client_code);
				request_log.info("get_callnotes(); Exit");
				o_callnotes_util = new Get_callnotes_util();
				/*
				 * if (callnotes_list ==null) callnotes_list.add(o_callnotes_util) will throw
				 * null pointer Exception;
				 */
				callnotes_list.add(o_callnotes_util);
				return callnotes_list;
			}
			logger.info("get_callnotes details are fetched from db  ");
			logger.info("get_callnotes(); Exit");
			request_log.info("get_callnotes details are fetched from db  ");
			request_log.info("get_callnotes(); Exit");

		} catch (Exception e) {
			callnotes_list.add(o_callnotes_util);
			logger.error("Exception in process_get_callnotes_request  :: " + e);
			logger.info("get_callnotes(); Exit");
			request_log.severe("Exception in process_get_callnotes_request  :: " + e);
			request_log.info("get_callnotes(); Exit");
			return callnotes_list;
		}
		return callnotes_list;
	}

	@POST
	@Path("/agenttoivr")
	@Consumes("application/json")
	@Produces("application/json")
	public resp_util set_agent_to_ivr(String req_param) {
		logger.info("set_agent_to_ivr(); Enter");
		request_log.info("set_agent_to_ivr(); Enter");
		// request_log.info("agent_to_ivr request with data :: "+req_param);
		db_operations o_db_operation = new db_operations();
		resp_util resp_obj = new resp_util();
		String work_request_id;
		String agent_action;
		String action_type;
		String language;
		String card_number;
		String transfer_number;
		String agent_id;
		String status;

		try {
			JSONObject json_obj = new JSONObject(req_param);
			work_request_id = o_json.get_json_value(json_obj, "workrequestId");
			agent_id = o_json.get_json_value(json_obj, "agentId");
			card_number = o_json.get_json_value(json_obj, "cardNo");
			agent_action = o_json.get_json_value(json_obj, "AgentAction");
			action_type = o_json.get_json_value(json_obj, "ActionType");
			language = o_json.get_json_value(json_obj, "language");
			transfer_number = o_json.get_json_value(json_obj, "TransferNumber");
			status = o_json.get_json_value(json_obj, "status");
			Timestamp created_time = new Timestamp(System.currentTimeMillis());
			logger.info("set_agent_to_ivr(); json data insert to the db  ");
			request_log.info("set_agent_to_ivr(); json data insert to the db  ");
			boolean status_db = o_db_operation.set_agent_to_ivr(work_request_id, agent_id, card_number, agent_action,
					action_type, language, transfer_number, status, created_time);
			if (status_db != false) {
				logger.info("agent_to_ivr database response  :: " + status_db);
				request_log.info("agent_to_ivr database response  :: " + status_db);
				resp_obj.setError_code("0");
				resp_obj.setError_message("sucess");
			}
			logger.info("set_agent_to_ivr(); Exit");
			request_log.info("set_agent_to_ivr(); Exit");

		} catch (Exception e) {
			logger.error("Exception in process_get_callnotes_request  :: " + e);
			logger.info("set_agent_to_ivr(); Exit");
			request_log.severe("Exception in process_get_callnotes_request  :: " + e);
			request_log.info("set_agent_to_ivr(); Exit");
			resp_obj.setError_code("-1");
			resp_obj.setError_message(e.getMessage());
			return resp_obj;
		}
		return resp_obj;

	}

	@POST
	@Path("/offermktmessages")
	@Consumes("application/json")
	@Produces("application/json")
	public resp_util set_offer_mkt_messages(String req_param) {
		logger.info("set_offer_mkt_messages(); Enter");
		request_log.info("set_offer_mkt_messages(); Enter");
		// request_log.info("set_offer_mkt_messages request with data :: "+req_param);
		String first_remove = req_param.substring(1); // index starts at zero
		String last_value = first_remove.substring(0, first_remove.length() - 1);
		logger.info("final request  :: " + last_value);
		request_log.info("final request  :: " + last_value);

		db_operations o_db_operation = new db_operations();
		resp_util resp_obj = new resp_util();
		String work_request_id = "";
		String campaign = "";
		String campaign_details = "";
		String agent_id = "";
		String status = "";
		boolean status_db = false;

		try {
			JSONObject outerObject = new JSONObject(last_value);
			// JSONObject innerObject = outerObject.getJSONObject("JObjects");
			JSONArray jsonArray = outerObject.getJSONArray("offer");
			for (int i = 0; i < jsonArray.length(); i++) {
				Object get = jsonArray.get(i);
				JSONObject job = (JSONObject) get;
				work_request_id = job.get("workrequestId").toString();
				campaign = job.get("campaign").toString();
				campaign_details = job.get("campaignDetails").toString();
				agent_id = job.get("agentId").toString();
				status = job.get("status").toString();
				Timestamp created_time = new Timestamp(System.currentTimeMillis());
				logger.info("set_offer_mkt_messages(); json data inserted to the db  ");
				request_log.info("set_offer_mkt_messages(); json data inserted to the db  ");
				status_db = o_db_operation.set_offer_mkt_messages(work_request_id, agent_id, campaign, campaign_details,
						status, created_time);
				logger.info("Response of set_offer_mkt_messages() " + status_db);
				request_log.info("Response of set_offer_mkt_messages() " + status_db);
			}

			if (status_db != false) {
				resp_obj.setError_code("0");
				resp_obj.setError_message("sucess");
				return resp_obj;
			}
			logger.info("set_offer_mkt_messages(); Exit");
			request_log.info("set_offer_mkt_messages(); Exit");
		} catch (Exception e) {
			logger.error("Exception in process_set_offer_mkt_messages_request  :: " + e);
			logger.info("set_offer_mkt_messages(); Exit");
			request_log.severe("Exception in process_set_offer_mkt_messages_request  :: " + e);
			request_log.info("set_offer_mkt_messages(); Exit");
			resp_obj.setError_code("-1");
			resp_obj.setError_message(e.getMessage());
			return resp_obj;
		}
		return resp_obj;

	}

	@POST
	@Path("/cardrelatedaction")
	@Consumes("application/json")
	@Produces("application/json")
	public resp_util set_card_related_action(String req_param) {
		logger.info("set_card_related_action(); Enter");
		request_log.info("set_card_related_action(); Enter");
		// request_log.info("set_card_related_action request with data :: "+req_param);
		db_operations o_db_operation = new db_operations();
		resp_util resp_obj = new resp_util();
		String work_request_id;
		String action_type;
		String card_number;
		String account_number;
		String agent_id;
		String status;

		try {
			JSONObject json_obj = new JSONObject(req_param);

			work_request_id = o_json.get_json_value(json_obj, "workrequestId");
			action_type = o_json.get_json_value(json_obj, "actionType");
			card_number = o_json.get_json_value(json_obj, "cardNo");
			account_number = o_json.get_json_value(json_obj, "accountNo");
			agent_id = o_json.get_json_value(json_obj, "agentId");
			status = o_json.get_json_value(json_obj, "status");
			Timestamp created_time = new Timestamp(System.currentTimeMillis());
			logger.info("set_card_related_action(); json data insert to the db  ");
			request_log.info("set_card_related_action(); json data insert to the db  ");
			boolean status_db = o_db_operation.set_card_related_action(work_request_id, agent_id, account_number,
					card_number, action_type, status, created_time);

			if (status_db != false) {
				logger.info("set_card_related_action() database response  :: " + status_db);
				request_log.info("set_card_related_action() database response  :: " + status_db);
				resp_obj.setError_code("0");
				resp_obj.setError_message("sucess");
				return resp_obj;
			}
			logger.info("set_card_related_action(); Exit");
			request_log.info("set_card_related_action(); Exit");

		} catch (Exception e) {
			logger.error("Exception in process_set_card_related_action_request  :: " + e);
			logger.info("set_card_related_action(); Exit");
			request_log.severe("Exception in process_set_card_related_action_request  :: " + e);
			request_log.info("set_card_related_action(); Exit");
			resp_obj.setError_code("-1");
			resp_obj.setError_message(e.getMessage());
			return resp_obj;
		}
		return resp_obj;

	}

	@POST
	@Path("/SetscreenPopDetails")
	@Consumes("application/json")
	@Produces("application/json")
	public resp_util Set_screen_pop_details(String req_param) {
		logger.info("Set_screen_pop_details(); Enter");
		request_log.info("Set_screen_pop_details(); Enter");
		// request_log.info("Set_screen_pop_details request with data :: "+req_param);
		db_operations o_db_operation = new db_operations();
		resp_util resp_obj = new resp_util();
		String ucid;
		String work_request_id;
		String direction;
		String card_number;
		String customer_name;
		String cm_mobile;
		String agent_id;
		String agent_extension;
		String client_code;
		String account_number;
		String calling_no;
		try {
			JSONObject json_obj = new JSONObject(req_param);

			work_request_id = o_json.get_json_value(json_obj, "workrequestId");
			agent_id = o_json.get_json_value(json_obj, "agentId");
			agent_extension = o_json.get_json_value(json_obj, "agentExtension");
			cm_mobile = o_json.get_json_value(json_obj, "cmMobile");
			account_number = o_json.get_json_value(json_obj, "accountNo");
			card_number = o_json.get_json_value(json_obj, "cardNo");
			customer_name = o_json.get_json_value(json_obj, "customerName");
			client_code = o_json.get_json_value(json_obj, "clientCode");
			calling_no = o_json.get_json_value(json_obj, "callingNo");
			ucid = o_json.get_json_value(json_obj, "ucid");
			direction = o_json.get_json_value(json_obj, "direction");
			Timestamp created_time = new Timestamp(System.currentTimeMillis());
			logger.info("Set_screen_pop_details(); json data insert to the db  ");

			request_log.info("Set_screen_pop_details(); json data insert to the db  ");

			boolean status = o_db_operation.set_screen_pop_details(work_request_id, agent_id, agent_extension,
					cm_mobile, account_number, card_number, customer_name, client_code, calling_no, ucid, direction,
					created_time);

			if (status != false) {
				logger.info("Set_screen_pop_details database response  :: " + status);

				request_log.info("Set_screen_pop_details database response  :: " + status);
				resp_obj.setError_code("0");
				resp_obj.setError_message("sucess");
				logger.info("Set_screen_pop_details(); Exit");

				request_log.info("Set_screen_pop_details(); Exit");
				return resp_obj;
			}

		} catch (Exception e) {
			logger.error("Exception in process_Set_screen_pop_details_request  :: " + e);
			logger.info("Set_screen_pop_details(); Exit");
			request_log.severe("Exception in process_Set_screen_pop_details_request  :: " + e);
			request_log.info("Set_screen_pop_details(); Exit");
			resp_obj.setError_code("-1");
			resp_obj.setError_message(e.getMessage());
			return resp_obj;
		}
		return resp_obj;

	}

	@POST
	@Path("/setagentDispositionDetails")
	@Consumes("application/json")
	@Produces("application/json")
	public resp_util set_agent_disposition_details(String req_param) {
		logger.info("set_agent_disposition_details(); Enter");
		request_log.info("set_agent_disposition_details(); Enter");
		// request_log.info("set_agent_disposition_details request with data ::
		// "+req_param);
		db_operations o_db_operation = new db_operations();
		resp_util resp_obj = new resp_util();
		String disposition_group;
		String agent_id;
		String card_number;
		String call_notes;
		String work_request_id;
		String disposition_code;
		String disposition_desc;
		String client_code;
		String department;
		String agentname;
		try {
			JSONObject json_obj = new JSONObject(req_param);

			work_request_id = o_json.get_json_value(json_obj, "workrequestId");
			agent_id = o_json.get_json_value(json_obj, "agentId");
			card_number = o_json.get_json_value(json_obj, "cardNo");
			call_notes = o_json.get_json_value(json_obj, "callNotes");
			disposition_group = o_json.get_json_value(json_obj, "dispositionGroup");
			disposition_code = o_json.get_json_value(json_obj, "dispositionCode");
			disposition_desc = o_json.get_json_value(json_obj, "dispositionDesc");
			client_code = o_json.get_json_value(json_obj, "clientCode");
			department = o_json.get_json_value(json_obj, "department");
			agentname = o_json.get_json_value(json_obj, "agentName");
			System.out.println("agentname " + agentname);
			Timestamp created_time = new Timestamp(System.currentTimeMillis());

			if (work_request_id.equals("") && agent_id.equals("") && card_number.equals("") && client_code.equals("")) {
				logger.info("set_agent_disposition_details json request values are empty  :: ");

				request_log.info("set_agent_disposition_details json request values are empty  :: ");
				resp_obj.setError_code("0");
				resp_obj.setError_message("sucess");
				return resp_obj;
			}
			logger.info("set_agent_disposition_details(); json data insert to the db  ");

			request_log.info("set_agent_disposition_details(); json data insert to the db  ");

			boolean status = o_db_operation.set_agent_disposition_details(work_request_id, agent_id, client_code,
					card_number, call_notes, disposition_group, disposition_code, disposition_desc, created_time,
					department, agentname);

			if (status != false) {
				logger.info("set_agent_disposition_details database response  :: " + status);

				request_log.info("set_agent_disposition_details database response  :: " + status);
				resp_obj.setError_code("0");
				resp_obj.setError_message("success");
				return resp_obj;
			}
			logger.info("set_agent_disposition_details(); Exit");

			request_log.info("set_agent_disposition_details(); Exit");

		} catch (Exception e) {
			logger.error("Exception in process_set_agent_disposition_details_request  :: " + e);

			logger.info("set_agent_disposition_details(); Exit");

			request_log.severe("Exception in process_set_agent_disposition_details_request  :: " + e);
			request_log.info("set_agent_disposition_details(); Exit");
			resp_obj.setError_code("-1");
			resp_obj.setError_message(e.getMessage());
			return resp_obj;
		}
		return resp_obj;

	}

	@POST
	@Path("/getAgentMenuAccess")
	@Consumes("application/json")
	@Produces("application/json")
	public ArrayList<Get_agent_menuaccess_util> get_agent_menu_access(String req_param) {
		logger.info("get_agent_menu_access(); Enter");

		request_log.info("get_agent_menu_access(); Enter");
		// request_log.info("get_agent_menu_access request with data :: "+req_param);
		ArrayList<Get_agent_menuaccess_util> agentmenu_list = new ArrayList<Get_agent_menuaccess_util>();
		db_operations o_db_operation = new db_operations();
		Get_agent_menuaccess_util o_menuaccess_util = null;
		String agent_id;

		try {
			JSONObject json_obj = new JSONObject(req_param);
			agent_id = o_json.get_json_value(json_obj, "agentId");

			if (agent_id.equals("") || agent_id.equalsIgnoreCase("NA")) {
				o_menuaccess_util = new Get_agent_menuaccess_util();
				o_menuaccess_util.code = "Client code is empty or NA";
				agentmenu_list.add(o_menuaccess_util);
				return agentmenu_list;
			}
			logger.info("get_agent_menu_access(); data fetched from db  ");
			logger.info("Request to db getcallnotes method : " + agent_id);

			request_log.info("get_agent_menu_access(); data fetched from db  ");
			request_log.info("Request to db getcallnotes method : " + agent_id);
			agentmenu_list = o_db_operation.get_agent_menu_access(agent_id);

			if (agentmenu_list == null || agentmenu_list.isEmpty()) {
				logger.info("invalid Agent ID or table is empty : " + agent_id);
				logger.info("get_agent_menu_access(); Exit");

				request_log.info("invalid Agent ID or table is empty : " + agent_id);
				request_log.info("get_agent_menu_access(); Exit");
				o_menuaccess_util = new Get_agent_menuaccess_util();
				/*
				 * if (o_menuaccess_util ==null) callnotes_list.add(o_callnotes_util) will throw
				 * null pointer Exception;
				 */
				agentmenu_list.add(o_menuaccess_util);
				return agentmenu_list;
			}
			logger.info("get_agent_menu_access details are fetched from db  ");
			logger.info("get_agent_menu_access(); Exit");

			request_log.info("get_agent_menu_access details are fetched from db  ");
			request_log.info("get_agent_menu_access(); Exit");

		} catch (Exception e) {
			o_menuaccess_util = new Get_agent_menuaccess_util();
			agentmenu_list.add(o_menuaccess_util);
			logger.error("Exception in process_get_agent_menu_access_request  :: " + e);
			logger.info("get_agent_menu_access(); Exit");

			request_log.severe("Exception in process_get_agent_menu_access_request  :: " + e);
			request_log.info("get_agent_menu_access(); Exit");
			return agentmenu_list;
		}
		return agentmenu_list;
	}

	@POST
	@Path("/SetAcrFailRequest")
	@Consumes("application/json")
	@Produces("application/json")
	public resp_util Set_acr_fail_request(String req_param) {
		logger.info("Set_acr_fail_request(); Enter");

		request_log.info("Set_acr_fail_request(); Enter");
		// request_log.info("Set_acr_fail_request request with data :: "+req_param);
		db_operations o_db_operation = new db_operations();
		resp_util resp_obj = new resp_util();

		String work_request_id = "";
		String client_code = "";
		String agent_id = "";
		String udfname = "";
		String udfvalue = "";
		String callid = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);

			work_request_id = o_json.get_json_value(json_obj, "workrequestId");
			client_code = o_json.get_json_value(json_obj, "clientCode");
			agent_id = o_json.get_json_value(json_obj, "agentId");
			udfname = o_json.get_json_value(json_obj, "udfName");
			udfvalue = o_json.get_json_value(json_obj, "udfValue");
			callid = o_json.get_json_value(json_obj, "callID");
			Timestamp created_time = new Timestamp(System.currentTimeMillis());
			logger.info("Set_acr_fail_request(); json data insert to the db  ");

			request_log.info("Set_acr_fail_request(); json data insert to the db  ");

			boolean status = o_db_operation.set_acr_fail_request(work_request_id, client_code, agent_id, udfname,
					udfvalue, callid, created_time);

			if (status != false) {
				request_log.info("Set_acr_fail_request database response  :: " + status);
				resp_obj.setError_code("0");
				resp_obj.setError_message("success");
				request_log.info("Set_acr_fail_request(); Exit");
				return resp_obj;
			}
			logger.info("Set_acr_fail_request(); Exit");

			request_log.info("Set_acr_fail_request(); Exit");

		} catch (Exception e) {
			logger.error("Exception in Set_acr_fail_request  :: " + e);
			logger.info("Set_acr_fail_request(); Exit");

			request_log.severe("Exception in Set_acr_fail_request  :: " + e);
			request_log.info("Set_acr_fail_request(); Exit");
			resp_obj.setError_code("-1");
			resp_obj.setError_message(e.getMessage());
			return resp_obj;
		}
		return resp_obj;

	}

	@POST
	@Path("/SetAcrTagging")
	@Consumes("application/json")
	@Produces("application/json")
	public resp_util Set_acr_tagging(String req_param) {
		logger.info("Set_acr_tagging(); Enter");
		request_log.info("Set_acr_tagging(); Enter");
		// request_log.info("Set_acr_tagging request with data :: "+req_param);
		db_operations o_db_operation = new db_operations();
		resp_util resp_obj = new resp_util();

		String work_request_id = "";
		String client_code = "";
		String agent_id = "";
		String udfname = "";
		String udfvalue = "";
		String callid = "";
		String url = "";
		String username = "";
		String password = "";

		try {
			JSONObject json_obj = new JSONObject(req_param);

			work_request_id = o_json.get_json_value(json_obj, "workrequestId");
			client_code = o_json.get_json_value(json_obj, "clientCode");
			agent_id = o_json.get_json_value(json_obj, "agentId");
			udfname = o_json.get_json_value(json_obj, "udfName");
			udfvalue = o_json.get_json_value(json_obj, "udfValue");
			callid = o_json.get_json_value(json_obj, "callId");

			url = o_json.get_json_value(json_obj, "URL");
			username = o_json.get_json_value(json_obj, "UserName");
			password = o_json.get_json_value(json_obj, "Password");

			Timestamp created_time = new Timestamp(System.currentTimeMillis());

			soap_req o_soap = new soap_req();
			logger.info("Set_acr_fail_request(); sending request to send_request(URL) for API response");

			request_log.info("Set_acr_fail_request(); sending request to send_request(URL) for API response");
			String response = o_soap.send_request(url, username, password, config.XML_KEY.trim());

			if (response != null && response.equals("success")) {
				logger.info("Set_acr_fail_request(); API response message  :: " + response);
				request_log.info("Set_acr_fail_request(); API response message  :: " + response);
				resp_obj.setError_code("01");
				resp_obj.setError_message("API success");
				logger.info("Set_acr_fail_request(); Exit");

				request_log.info("Set_acr_fail_request(); Exit");
				return resp_obj;
			} else {
				logger.info("Set_acr_fail_request(); API URL is not reachable");

				request_log.info("Set_acr_fail_request(); API URL is not reachable");

				boolean status = o_db_operation.set_acr_fail_request(work_request_id, client_code, agent_id, udfname,
						udfvalue, callid, created_time);

				if (status != false) {
					logger.info("Set_acr_fail_request database response  :: " + status);

					request_log.info("Set_acr_fail_request database response  :: " + status);
					resp_obj.setError_code("02");
					resp_obj.setError_message("DB success");
					logger.info("Set_acr_fail_request(); Exit");

					request_log.info("Set_acr_fail_request(); Exit");
					return resp_obj;
				}
				logger.info("Set_acr_fail_request(); Exit");

				request_log.info("Set_acr_fail_request(); Exit");
			}

		} catch (Exception e) {
			logger.info("Exception in Set_acr_fail_request  :: " + e);
			logger.info("Set_acr_fail_request(); Exit");

			request_log.severe("Exception in Set_acr_fail_request  :: " + e);
			request_log.info("Set_acr_fail_request(); Exit");
			resp_obj.setError_code("-1");
			resp_obj.setError_message(e.getMessage());
			return resp_obj;
		}
		return resp_obj;

	}

}

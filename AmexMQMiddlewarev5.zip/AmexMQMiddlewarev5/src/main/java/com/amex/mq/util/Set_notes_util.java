package com.amex.mq.util;

public class Set_notes_util 
{
	private String code;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}	

}

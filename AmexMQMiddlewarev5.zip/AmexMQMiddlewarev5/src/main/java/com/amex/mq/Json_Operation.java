package com.amex.mq;


import org.json.JSONObject;

public class Json_Operation 
{
	org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(Rest_ws_request.class);

	public String get_json_value(JSONObject jsonObj, String jsonObj_key) 
	{
		try {
		String value = "";
		if(!jsonObj.has(jsonObj_key))
			return "";
		else
			value = jsonObj.get(jsonObj_key).toString()== null || jsonObj.get(jsonObj_key).toString().isEmpty()  ? value : jsonObj.get(jsonObj_key).toString();
		
		return value;
		}
		catch (Exception e) {
			logger.error("json value getting exception "+e);
		}
		return null;
	}
}

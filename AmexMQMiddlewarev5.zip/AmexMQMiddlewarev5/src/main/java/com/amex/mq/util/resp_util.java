package com.amex.mq.util;

public class resp_util 
{
		private String error_code="-1";
		private String error_message="fail";
		
			
		
		public String getError_message() {
			return error_message;
		}
		public void setError_message(String error_message) {
			this.error_message = error_message;
		}
		public String getError_code() {
			return error_code;
		}
		public void setError_code(String error_code) {
			this.error_code = error_code;
		}
}

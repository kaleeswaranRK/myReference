package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class ChargeCardAccountBalanceReturn 
{
	public String errorCode = emptyStr;
	public String status = emptyStr;
	public String currentBalance = emptyStr;
	public String dateLastStatement = emptyStr;
	public String amountDue = emptyStr;
	public String accountStatusMessage = emptyStr;
	public String billingCycle = emptyStr;
	
	public String toString()
	{
		String returnStr = newLine +
				resErrorCode + errorCode + newLine +
				resStatus + status + newLine +
				resCurrentBalance + currentBalance + newLine +
				resDateLastStatement + dateLastStatement + newLine +
				resAmountDue + amountDue + newLine + 
				resAccStatusMsg + accountStatusMessage + newLine +
				resBillingCycle + billingCycle + newLine ;
		return returnStr;
	}
}
/*
 * (C) Copyright 2011 Geomant Kft. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

//import javax.jms.Destination;
import javax.jms.TextMessage;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
//import com.realsoftinc.amex.mq.returnObjs.EmbosserDetailReturn;
import com.realsoftinc.amex.mq.returnObjs.ConfirmCSIEnrollmentReturn;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the main business logic of the function
 * CardActivation
 * 
 * @author Norbert Toth / Geomant Kft.
 * @version $Revision: 1.0 $ $Date: 2011/06/21 11:48:55 $
 */
public class ConfirmCSIEnrollment {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(ConfirmCSIEnrollment.class);

	@SuppressWarnings({ "unchecked", "static-access" })
	public ConfirmCSIEnrollmentReturn ConfirmEnrollement(String accNum) {
		logger.info("ConfirmEnrollement(); Confirm CSI Enrolled function is called by IVR .. ");
		logger.info("ConfirmEnrollement(); Enter");
		log.info("ConfirmEnrollement(); Confirm CSI Enrolled function is called by IVR .. ");
		log.info("ConfirmEnrollement(); Enter");

		MQCommon mqc = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser CSIEnrolledParser = null;
		ConfirmCSIEnrollmentReturn confirmEnrollementReturn = null;
		TextMessage mqReply = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;
		// Map<String, String> respMap = null;

		String dateTimeStampInStr = emptyStr;
		String date = emptyStr;
		String time = emptyStr;
		String auditSeqInStr = emptyStr;
		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		String status = emptyStr;
		// String xmlResp = emptyStr;
		// String sso = emptyStr;
		String maskAccNum = emptyStr;
		// String MsgId_ConfEnrl = "6019";
		// String ProdID = "CSI000";
		// String ChannelMsg = "I";
		// String MsgLgth = "75";
		// String UserName = "FMULLA";//It should be read from property file

		confirmEnrollementReturn = new ConfirmCSIEnrollmentReturn();
//		EmbosserDetail embosserDtl = null;
//		EmbosserDetailReturn embosserDetailRtObj = null;
//		try{
//			log.info("CheckCSIEnrolled(); Calling Embosser Detail function .."); 
//			embosserDtl = new EmbosserDetail();
//			embosserDetailRtObj = embosserDtl.getEmbosserDetail(cardNum);
//			checkEnrolledReturn = new CheckCSIEnrolledReturn();
//		}
//		
//		catch (Exception e) {
//			log.severe("CheckCSIEnrolled(); Exception is raised. Reason : " + e.getStackTrace());
//		}

//		log.info("CheckCSIEnrolled(); " + resCurrentUsageFlag + embosserDetailRtObj.firstUsageFlag);
//		log.info("CheckCSIEnrolled(); " + resLastUsageFlag	+ embosserDetailRtObj.priorUsageFlag);
//		log.info("CheckCSIEnrolled(); " + resErrorCode	+ embosserDetailRtObj.ErrorCode);

//		if ((embosserDetailRtObj.ErrorCode.equalsIgnoreCase("0")
//				|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("00")
//				|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("000") || embosserDetailRtObj.ErrorCode
//				.equalsIgnoreCase("0000"))
//				&& (embosserDetailRtObj.firstUsageFlag.equalsIgnoreCase("Y"))
//				&& (embosserDetailRtObj.priorUsageFlag.equalsIgnoreCase("N"))) {

		try {
			/*
			 * sso = MQCommon.SSO; if(sso == null) { log.info("accountBal(); sso is null");
			 * log.info("ConfirmEnrollement(); Calling getSSO() function ..."); sso =
			 * mqc.getSSO(); } else if(sso.equalsIgnoreCase(emptyStr)) {
			 * log.info("ConfirmEnrollement(); sso is an empty string");
			 * log.info("ConfirmEnrollement(); Calling getSSO() function ..."); sso =
			 * mqc.getSSO(); }
			 */

			xmlMap = new HashMap<String, String>();
			// respMap = new HashMap<String, String>();
			map = new HashMap<String, String>();

			mqc = new MQCommon();
			rc = new RequestCreater();
			rr = new RequestResponse();
			CSIEnrolledParser = new ResponseParser();

//				currentFlag = currentFlagN;
//				lastFlag = CardActv_Hpr;

			if (accNum.length() == 12) {
				// maskAccNum = accNum.replace(accNum.subSequence(4,
				// accNum.length()-5),maskString2);
				maskAccNum = accNum.substring(0, 4) + "***" + accNum.substring(accNum.length() - 5, accNum.length());
				logger.info("ConfirmEnrollement(); Account Number is : " + maskAccNum);

				log.info("ConfirmEnrollement(); Account Number is : " + maskAccNum);
			} else {
				logger.info("ConfirmEnrollement(); Account Number is less than 12 digits.");

				log.info("ConfirmEnrollement(); Account Number is less than 12 digits.");
			}

			/*
			 * if(cardNum.length() == 15){ maskCardNum =
			 * cardNum.replace(cardNum.subSequence(4, cardNum.length()-5),maskString1);
			 * log.info("CheckCSIEnrolled(); Card Number is : " + maskCardNum); } else{
			 * log.info("CheckCSIEnrolled(); Card Number is less than 15 digits."); }
			 */
			logger.info("ConfirmEnrollement(); Calling the getDateTime function ..");

			log.info("ConfirmEnrollement(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("ConfirmEnrollement(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("ConfirmEnrollement(); Calling the getAuditSequence function ..");
			log.info("ConfirmEnrollement(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("ConfirmEnrollement(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("CheckCSIEnrolled(); Audit Sequence is : " + auditSeqInStr);

			logger.info("ConfirmEnrollement(); Calling the getDate function ..");
			log.info("CheckCSIEnrolled(); Audit Sequence is : " + auditSeqInStr);

			log.info("ConfirmEnrollement(); Calling the getDate function ..");
			date = mqc.getDate();
			logger.info("ConfirmEnrollement(); Date is : " + date);

			logger.info("ConfirmEnrollement(); Calling the getTime function ..");
			log.info("ConfirmEnrollement(); Date is : " + date);

			log.info("ConfirmEnrollement(); Calling the getTime function ..");
			time = mqc.getTime();
			logger.info("ConfirmEnrollement(); Time is : " + time);

			logger.info("ConfirmEnrollement(); Created all the required parameters to prepare the xml ..");
			log.info("ConfirmEnrollement(); Time is : " + time);

			log.info("ConfirmEnrollement(); Created all the required parameters to prepare the xml ..");
			// xmlMap.put("MessageLength", MsgLgth);
			xmlMap.put("MessageLength", mqc.getproperties("ConfirmCSIEnrollment.MsgLength"));
			xmlMap.put("MessageId", MsgId_ConfEnrl);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AccountNumber", accNum);
			xmlMap.put("SSO", mqc.getproperties("ConfirmCSIEnrollment.SSO"));
			// xmlMap.put("ProductId", ProdID);
			// xmlMap.put("Channel", ChannelMsg);
			// xmlMap.put("username", UserName);
			xmlMap.put("ProductId", mqc.getproperties("ConfirmCSIEnrollment.ProdID"));
			xmlMap.put("Channel", mqc.getproperties("ConfirmCSIEnrollment.ChannelMsg"));
			xmlMap.put("username", mqc.getproperties("ConfirmCSIEnrollment.UserName"));
			logger.info("ConfirmEnrollement(); Sending values to form proper format of xml request .. ");

			log.info("ConfirmEnrollement(); Sending values to form proper format of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "ConfirmeCSIEnrollment");
			logger.info("ConfirmEnrollement(); Received xml in proper format ..");
			logger.info("ConfirmEnrollement(); XML is : " + xmlReq);

			logger.info("ConfirmEnrollement(); Sending the prepared xml to MQ .. ");
			log.info("ConfirmEnrollement(); Received xml in proper format ..");
			log.info("ConfirmEnrollement(); XML is : " + xmlReq);

			log.info("ConfirmEnrollement(); Sending the prepared xml to MQ .. ");
			mqReply = rr.MessageSenderAck(xmlReq);
			replyMsg = mqReply.getText();
			logger.info("ConfirmEnrollement(); Response received from MQ .. ");
			logger.info("ConfirmEnrollement(); Received response from MQ is : " + replyMsg);

			logger.info("ConfirmEnrollement(); Received response from MQ : " + replyMsg);
			log.info("ConfirmEnrollement(); Response received from MQ .. ");
			log.info("ConfirmEnrollement(); Received response from MQ is : " + replyMsg);

			log.info("ConfirmEnrollement(); Received response from MQ : " + replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("ConfirmEnrollement(); Sending the received response from MQ to the parser ..");
				logger.info("ConfirmEnrollement(); XML sent for parsing is :" + replyMsg);
				log.info("ConfirmEnrollement(); Sending the received response from MQ to the parser ..");
				log.info("ConfirmEnrollement(); XML sent for parsing is :" + replyMsg);
				map = CSIEnrolledParser.XmlParser(replyMsg);
				confirmEnrollementReturn.ErrorCode = (String) map.get("errCode");
				confirmEnrollementReturn.ErrorDescription = (String) map.get("errDesc");
				confirmEnrollementReturn.Length = (String) map.get("Length");
				confirmEnrollementReturn.MessageID = (String) map.get("MessageID");
				confirmEnrollementReturn.AuditSeq = (String) map.get("AuditSeq");
				confirmEnrollementReturn.DateTimeStamp = (String) map.get("DateTimeStamp");

				if (confirmEnrollementReturn.ErrorCode.equalsIgnoreCase("0")
						|| confirmEnrollementReturn.ErrorCode.equalsIgnoreCase("00")
						|| confirmEnrollementReturn.ErrorCode.equalsIgnoreCase("000")
						|| confirmEnrollementReturn.ErrorCode.equalsIgnoreCase("0000")) {
					logger.info("ConfirmEnrollement(); Response from MQ is 'SUCCESS'.. ");

					log.info("ConfirmEnrollement(); Response from MQ is 'SUCCESS'.. ");
					status = validStr;
				} else {
					logger.info("ConfirmEnrollement(); Response from MQ is 'FAILURE'.. ");

					log.info("ConfirmEnrollement(); Response from MQ is 'FAILURE'.. ");
					status = invalidStr;
				}

				// log.info("ConfirmEnrollement(); Sending acknowledge string for xml
				// formation.. :");
//				respMap.put("MessageId", MsgId_ChckCSIEnrolled);
//				respMap.put("Description", CardActv_DescAck);
//				respMap.put("errorCode", confirmEnrollementReturn.ErrorCode);
//				respMap.put("errorDescription", confirmEnrollementReturn.ErrorDescription);

				confirmEnrollementReturn.Status = status;
				/* cardActivation.isNewCardRequest = errorCode; */

//				xmlResp = rc.XmlRequest(respMap, "CardActivation_Ack");
//				
//				Destination destQ = mqReply.getJMSReplyTo();
//				log.info("ConfirmEnrollement(); Destination Q is : " + destQ.toString());
//				
//				log.info("CheckCSIEnrolled(); Sending acknowledgment .. ");
//				rr.sendAck(xmlResp,destQ);
//				log.info("ConfirmEnrollement(); Acknowledgment sent to MQ .");
			} else {
				logger.info("ConfirmEnrollement(); Since the response from MQ is not proper .. ");
				logger.info("ConfirmEnrollement(); Setting error values.");
				log.info("ConfirmEnrollement(); Since the response from MQ is not proper .. ");
				log.info("ConfirmEnrollement(); Setting error values.");
				confirmEnrollementReturn.ErrorCode = errorCode;
				confirmEnrollementReturn.ErrorDescription = errorDesc;
				confirmEnrollementReturn.Status = invalidStr;
			}

		} catch (Exception e) {
			logger.error("ConfirmEnrollement(); Exception is raised. Reason : " + e.getStackTrace());

			log.severe("ConfirmEnrollement(); Exception is raised. Reason : " + e.getStackTrace());
		} finally {
			mqc = null;
			rc = null;
			rr = null;
			CSIEnrolledParser = null;
			mqReply = null;
			xmlMap = null;
			map = null;
			// respMap = null;

			dateTimeStampInStr = emptyStr;
			date = emptyStr;
			time = emptyStr;
			auditSeqInStr = emptyStr;
//				currentFlag = emptyStr;
//				lastFlag = emptyStr;
			xmlReq = emptyStr;
			replyMsg = emptyStr;
			status = emptyStr;
			// xmlResp = emptyStr;
			// sso = emptyStr;
			maskAccNum = emptyStr;
			// ChannelMsg = emptyStr;
			// MsgLgth = emptyStr;
		}
//		} else {
//			if ((embosserDetailRtObj.ErrorCode.equalsIgnoreCase("0")
//					|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("00")
//					|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("000") || embosserDetailRtObj.ErrorCode
//					.equalsIgnoreCase("0000"))
//					&& (embosserDetailRtObj.firstUsageFlag
//							.equalsIgnoreCase("Y") && embosserDetailRtObj.priorUsageFlag
//							.equalsIgnoreCase("Y"))) {
//				checkEnrolledReturn.isNewCardRequest = true;
//			} else {
//				checkEnrolledReturn.isNewCardRequest = false;
//			}
//			log.info("CheckCSIEnrolled(); The Embosser Detail Message Failed.");
//			log.info("CheckCSIEnrolled(); Setting the ErrorCode and ErrorDescription inside checkEnrolledReturn Return Object.");
//			checkEnrolledReturn.ErrorCode = errorCode;
//			checkEnrolledReturn.ErrorDescription = errorDesc;
//			checkEnrolledReturn.Status = invalidStr;
//		}
		logger.info("ConfirmEnrollement(); Response is returned to the IVR. Response : "
				+ confirmEnrollementReturn.toString());
		logger.info("ConfirmEnrollement(); Exit");
		log.info("ConfirmEnrollement(); Response is returned to the IVR. Response : "
				+ confirmEnrollementReturn.toString());
		log.info("ConfirmEnrollement(); Exit");
		return confirmEnrollementReturn;
	}
}

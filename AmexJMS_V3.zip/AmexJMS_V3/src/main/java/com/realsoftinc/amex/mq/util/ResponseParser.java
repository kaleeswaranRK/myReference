/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */

package com.realsoftinc.amex.mq.util;

import java.util.*;

import java.util.logging.Logger;
import org.dom4j.*;

import com.realsoftinc.amex.mq.common.*;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class parses the response XML file and stores the result in a Hash Map
 * 
 * in key-value format.
 * 
 * @name ResponseParser
 * @author Purvi Lad
 * @version 1.0 Date 11 Mar 2010
 */

public class ResponseParser {
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(ResponseParser.class);

	Logger log = Utility.getLogger();

	// final static Logger log = Logger.getLogger(RequestCreater.class);
	@SuppressWarnings("unchecked")
	public Map XmlParser(String replyText) {
		logger.info("XmlParser(); Enter");

		log.info("XmlParser(); Enter");

		String description = emptyStr;
		String errorCode = emptyStr;
		String errorDescription = emptyStr;
		String accountNum = emptyStr;
		String dateTimeStampOutStr = emptyStr;
		String auditSeqOutStr = emptyStr;
		String returnMsgIdActualStr = emptyStr;
		String priorUsageFlag = emptyStr;
		String firstUsageFlag = emptyStr;
		String orgStr = emptyStr;
		String logoStr = emptyStr;
		String curBal = emptyStr;
		String amntDue = emptyStr;
		String totCreLimit = emptyStr;
		String cashCreLimit = emptyStr;
		String cashBal = emptyStr;
		String cashAvail = emptyStr;
		String otb = emptyStr;
		String bgnBal = emptyStr;
		String blCode = emptyStr;
		String status = emptyStr;
		String pastDue = emptyStr;
		String lastPur = emptyStr;
		String billCycle = emptyStr;
		String dateOpened = emptyStr;
		String dueDate = emptyStr;
		String blCode2 = emptyStr;
		String memoBal = emptyStr;
		String ctaReason = emptyStr;
		String title = emptyStr;
		String homePh = emptyStr;
		String empPh = emptyStr;
		String mobPh = emptyStr;
		String name = emptyStr;
		String memo1 = emptyStr;
		String memo2 = emptyStr;
		String amtLastPay = emptyStr;
		String dateLastPay = emptyStr;
		String delqTpd = emptyStr;
		String delqXdayNo = emptyStr;
		String delqXdayAmt = emptyStr;
		String ssoStr = emptyStr;
		String dateTimeStampStr = emptyStr;
		String auditSeqStr = emptyStr;
		String msgIdActualStr = emptyStr;
		String dateOfBirth = emptyStr;
		String errCode = emptyStr;
		String errDesc = emptyStr;
		String currencyName = emptyStr;
		String errDes = emptyStr;
		String dueLastStat = emptyStr;
		String currencySym = emptyStr;
		String primSuppFlag = emptyStr;
		String title1 = emptyStr;
		String name1 = emptyStr;
		String date = emptyStr;
		String toDateBal = emptyStr;
		String billDt = emptyStr;
		String billBal = emptyStr;
		String statusMsg = emptyStr;
		String cnumber = emptyStr;
		String cardType = emptyStr;
		String cardNum = emptyStr;
		String accNum = emptyStr;
		String msgId = emptyStr;
		String expiryDate = emptyStr;
		String cardNumber = emptyStr;
		String maskCardNum = emptyStr;
		String maskAccNum = emptyStr;
		String enrolledStatus = emptyStr;
		String Length = emptyStr;
		String branchCodeStr = emptyStr;
		String powercardID = emptyStr;
		String statAddress1 = emptyStr;
		String statAddress2 = emptyStr;
		String statAddress3 = emptyStr;
		String homeCountrySel = emptyStr;
		String mobCountry = emptyStr;
		String emailID = emptyStr;
		String workNO = emptyStr;
		String workCountrySel = emptyStr;
		String smsFlag = emptyStr;
		String eStatFlag = emptyStr;
		String prodCodeStr = emptyStr;
		String amountPurchCTD = emptyStr;
		String amountPurchYTD = emptyStr;
		String amountPurchLTD = emptyStr;
		String amountCashCTD = emptyStr;
		String amountCashYTD = emptyStr;
		String amountCashLTD = emptyStr;
		String memberSince = emptyStr;
		String dbc = emptyStr;
		String embossName = emptyStr;
		String passportNum = emptyStr;
		String cprid = emptyStr;
		String bankName = emptyStr;
		String bankBranch = emptyStr;
		String bankAccountNumber = emptyStr;
		String nationality = emptyStr;
		String income = emptyStr;
		String xRef1 = emptyStr;
		String xRef2 = emptyStr;
		String homeAddr1 = emptyStr;
		String homeAddr2 = emptyStr;
		String homeAddr3 = emptyStr;
		String homePhArea = emptyStr;
		String prevAddr1 = emptyStr;
		String prevAddr2 = emptyStr;
		String prevAddr3 = emptyStr;
		String empAddr1 = emptyStr;
		String empAddr2 = emptyStr;
		String empAddr3 = emptyStr;
		String homeMail = emptyStr;
		String empName = emptyStr;
		String empMail = emptyStr;
		String empFax = emptyStr;
		String empPhone = emptyStr;
		String empPhArea = emptyStr;
		String pageSize = emptyStr;
		String startPos = emptyStr;
		String numRec = emptyStr;
		String moreRec = emptyStr;
		String dateCardFee = emptyStr;
		String overdueFlag = emptyStr;
		String lastStmtBal = emptyStr;

		String cardSeq = emptyStr;
		String uci = emptyStr;
		String cmFamilyName = emptyStr;
		String legalId = emptyStr;
		String clientCode = emptyStr;

		String cmBillingAddress = emptyStr;
		String clientUnderride = emptyStr;
		String clientOverride = emptyStr;
		String cardActivationFlag = emptyStr;
		String cardActivationDate = emptyStr;
		String cardExpiryDate = emptyStr;
		String productType = emptyStr;
		String pinStatus = emptyStr;
		String cardStatus = emptyStr;
		String productName = emptyStr;
		String employeeID = emptyStr;
		String rmName = emptyStr;
		String vipLevel = emptyStr;
		String stopList = emptyStr;
		String transaction = emptyStr;

		String statementoption = emptyStr;
		String accountstatus = emptyStr;
		String totalcashlimit = emptyStr;
		String totalminimumdue = emptyStr;
		String lastpaymentamount = emptyStr;
		String totalspendexposure = emptyStr;
		String accountparoverride = emptyStr;
		String masterlimit = emptyStr;
		String basiccontrolnumber = emptyStr;
		String basiccontrolname = emptyStr;
		String availablecredit = emptyStr;
		String availablecash = emptyStr;
		String daysdelinquent = emptyStr;
		String totalbilledbalance = emptyStr;
		String paraccountunderride = emptyStr;
		String masterexposure = emptyStr;
		String currency = emptyStr;
		String expresscashflag = emptyStr;
		String directdebitflag = emptyStr;
		String casenumber = emptyStr;

		String cmtitle = emptyStr;
		String cmfirstname = emptyStr;
		String cmdateofbirth = emptyStr;

		String customeremail = emptyStr;
		String customermobile = emptyStr;
		String cmbranchcode = emptyStr;
		String flashermemo1 = emptyStr;
		String flashermemo2 = emptyStr;
		String primSupplFlag = emptyStr;

		// String desc = emptyStr;
		// String amount = emptyStr;
		// String date1 = emptyStr;

		Map<String, String> xmlmap = null;
		try {
			StringTokenizer st = new StringTokenizer(replyText, "|");
			if (st.hasMoreTokens()) {
				replyText = st.nextToken();
				// log.info("XmlParser(); XMl string is : " + replyText);
				// MQCommon.maskAccNumber("XmlParser(); XMl string is : " , replyText);
			} else {
				logger.info("XmlParser(); 1st Condition not satisfied");

				log.info("XmlParser(); 1st Condition not satisfied");
			}
			if (st.hasMoreTokens()) {
				cardNumber = st.nextToken();
				if (cardNumber.length() > 9) {
					maskCardNum = cardNumber.substring(0, 4) + "******"
							+ cardNumber.substring(cardNumber.length() - 5, cardNumber.length());
					// maskCardNo = cardNumber.replace(cardNumber.substring(0, 4), maskString1);
					// maskCardNum = maskCardNo.replace(maskCardNo.substring(maskCardNo.length()-5,
					// maskCardNo.length()),maskString2);
					logger.info("XmlParser(); Card Number is : " + maskCardNum);

					log.info("XmlParser(); Card Number is : " + maskCardNum);
				} else {
					logger.info("XmlParser(); Card Number is less than 9 digits.");

					log.info("XmlParser(); Card Number is less than 9 digits.");
				}
			} else {
				logger.info("XmlParser(); 2nd Condition not satisfied");

				log.info("XmlParser(); 2nd Condition not satisfied");
			}

			xmlmap = new HashMap<String, String>();
			Document document = DocumentHelper.parseText(replyText);

			List list = document.selectNodes("//Message");
			List list1 = document.selectNodes("//Message_Res");
			List list2 = document.selectNodes("//Message_Res/CardInfo");
			List list3 = document.selectNodes("//EAIBody");
			List list4 = document.selectNodes("//EAIHeader");
			List list5 = document.selectNodes("//Message_Res/List");
//            List list6 = document.selectNodes("//Message_Res/CardList/CardDetails");
//            List list7 = document.selectNodes("//Message_Res/RecentTransactions");
//            List list8 = document.selectNodes("//Message_Res/AvailableOffers/Offer");

			Iterator iter = list.iterator();
			logger.info("XmlParser(); Node is : //Message");
			log.info("XmlParser(); Node is : //Message");
			while (iter.hasNext()) {
				Element element = (Element) iter.next();
				for (Iterator iterator = element.elementIterator("ErrorCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					errorCode = titleElement.getText().trim();
					logger.info("XmlParser(); Error Code is : " + errorCode);

					log.info("XmlParser(); Error Code is : " + errorCode);
					xmlmap.put("errorCode", errorCode);
				}
				for (Iterator iterator = element.elementIterator("ErrorDescription"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					errorDescription = titleElement.getText().trim();
					logger.info("XmlParser(); Error Description is : " + errorDescription);

					log.info("XmlParser(); Error Description is : " + errorDescription);
					xmlmap.put("errorDescription", errorDescription);
				}
				for (Iterator iterator = element.elementIterator("AccountNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					accountNum = titleElement.getText().trim();
					if (accountNum.length() == 12) {
						maskAccNum = accountNum.substring(0, 4) + "***"
								+ accountNum.substring(accountNum.length() - 5, accountNum.length());
						// maskAccNum = accountNum.replace(accountNum.subSequence(4,
						// accountNum.length()-5),maskString2);
						logger.info("XmlParser(); Account Number is : " + maskAccNum);

						log.info("XmlParser(); Account Number is : " + maskAccNum);
					} else {
						logger.info("XmlParser(); Account Number is less than 12 digits.");

						log.info("XmlParser(); Account Number is less than 12 digits.");
					}
					xmlmap.put("accountNum", accountNum);
				}
				for (Iterator iterator = element.elementIterator("DateTimeStamp"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dateTimeStampOutStr = titleElement.getText().trim();
					logger.info("XmlParser(); Date Time Stamp is : " + dateTimeStampOutStr);

					log.info("XmlParser(); Date Time Stamp is : " + dateTimeStampOutStr);
					xmlmap.put("dateTimeStampOutStr", dateTimeStampOutStr);
				}
				for (Iterator iterator = element.elementIterator("AuditSeq"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					auditSeqOutStr = titleElement.getText().trim();
					logger.info("XmlParser(); Audit Sequence is : " + auditSeqOutStr);

					log.info("XmlParser(); Audit Sequence is : " + auditSeqOutStr);
					xmlmap.put("auditSeqOutStr", auditSeqOutStr);
				}
				for (Iterator iterator = element.elementIterator("MessageID"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					returnMsgIdActualStr = titleElement.getText().trim();
					logger.info("XmlParser(); Message ID is : " + returnMsgIdActualStr);

					log.info("XmlParser(); Message ID is : " + returnMsgIdActualStr);
					xmlmap.put("returnMsgIdActualStr", returnMsgIdActualStr);
				}
				for (Iterator iterator = element.elementIterator("PriorUsageFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					priorUsageFlag = titleElement.getText().trim();
					logger.info("XmlParser(); Prior Usage Flag is : " + priorUsageFlag);

					log.info("XmlParser(); Prior Usage Flag is : " + priorUsageFlag);
					xmlmap.put("priorUsageFlag", priorUsageFlag);
				}
				for (Iterator iterator = element.elementIterator("FirstUsageFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					firstUsageFlag = titleElement.getText().trim();
					logger.info("XmlParser(); First Usage Flag is : " + firstUsageFlag);

					log.info("XmlParser(); First Usage Flag is : " + firstUsageFlag);
					xmlmap.put("firstUsageFlag", firstUsageFlag);
				}
				for (Iterator iterator = element.elementIterator("ExpiryDate"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					expiryDate = titleElement.getText().trim();
					logger.info("XmlParser(); Expiry Date is : " + expiryDate);

					log.info("XmlParser(); Expiry Date is : " + expiryDate);
					xmlmap.put("expiryDate", expiryDate);
				}
				for (Iterator iterator = element.elementIterator("Org"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					orgStr = titleElement.getText().trim();
					logger.info("XmlParser(); Org is : " + orgStr);

					log.info("XmlParser(); Org is : " + orgStr);
					xmlmap.put("orgStr", orgStr);
				}
				for (Iterator iterator = element.elementIterator("Logo"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					logoStr = titleElement.getText().trim();
					logger.info("XmlParser(); Logo is : " + logoStr);

					log.info("XmlParser(); Logo is : " + logoStr);
					xmlmap.put("logoStr", logoStr);
				}
				for (Iterator iterator = element.elementIterator("CurrentBalance"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					curBal = titleElement.getText().trim();
					logger.info("XmlParser(); Current Balance is : " + curBal);

					log.info("XmlParser(); Current Balance is : " + curBal);
					xmlmap.put("curBal", curBal);
				}
				for (Iterator iterator = element.elementIterator("AmountDue"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					amntDue = titleElement.getText().trim();
					logger.info("XmlParser(); Amount Due is : " + amntDue);

					log.info("XmlParser(); Amount Due is : " + amntDue);
					xmlmap.put("amntDue", amntDue);
				}
				for (Iterator iterator = element.elementIterator("TotalCreditLimit"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					totCreLimit = titleElement.getText().trim();
					logger.info("XmlParser(); Total Credit Limit is : " + totCreLimit);

					log.info("XmlParser(); Total Credit Limit is : " + totCreLimit);
					xmlmap.put("totCreLimit", totCreLimit);
				}
				for (Iterator iterator = element.elementIterator("CashCreditLimit"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cashCreLimit = titleElement.getText().trim();
					logger.info("XmlParser(); Cash Credit Limit is : " + cashCreLimit);

					log.info("XmlParser(); Cash Credit Limit is : " + cashCreLimit);
					xmlmap.put("cashCreLimit", cashCreLimit);
				}
				for (Iterator iterator = element.elementIterator("CashBalance"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cashBal = titleElement.getText().trim();
					logger.info("XmlParser(); Cash Balance is : " + cashBal);

					log.info("XmlParser(); Cash Balance is : " + cashBal);
					xmlmap.put("cashBal", cashBal);
				}
				for (Iterator iterator = element.elementIterator("CashAvailable"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cashAvail = titleElement.getText().trim();
					logger.info("XmlParser(); Cash Available is : " + cashAvail);

					log.info("XmlParser(); Cash Available is : " + cashAvail);
					xmlmap.put("cashAvail", cashAvail);
				}
				for (Iterator iterator = element.elementIterator("OTB"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					otb = titleElement.getText().trim();
					logger.info("XmlParser(); OTB is : " + otb);

					log.info("XmlParser(); OTB is : " + otb);
					xmlmap.put("otb", otb);
				}
				for (Iterator iterator = element.elementIterator("BeginBalance"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					bgnBal = titleElement.getText().trim();
					logger.info("XmlParser(); Begin Balance is : " + bgnBal);

					log.info("XmlParser(); Begin Balance is : " + bgnBal);
					xmlmap.put("bgnBal", bgnBal);
				}
				for (Iterator iterator = element.elementIterator("BlockCode1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					blCode = titleElement.getText().trim();
					logger.info("XmlParser(); Block Code1 is : " + blCode);

					log.info("XmlParser(); Block Code1 is : " + blCode);
					xmlmap.put("blCode", blCode);
				}
				for (Iterator iterator = element.elementIterator("Status"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					status = titleElement.getText().trim();
					logger.info("XmlParser(); Status is : " + status);
					log.info("XmlParser(); Status is : " + status);
					xmlmap.put("status", status);
				}
				for (Iterator iterator = element.elementIterator("PastDue"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					pastDue = titleElement.getText().trim();
					logger.info("XmlParser(); Past Due is : " + pastDue);
					log.info("XmlParser(); Past Due is : " + pastDue);
					xmlmap.put("pastDue", pastDue);
				}
				for (Iterator iterator = element.elementIterator("LastPurchase"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					lastPur = titleElement.getText().trim();
					logger.info("XmlParser(); Last Purchase is : " + lastPur);
					log.info("XmlParser(); Last Purchase is : " + lastPur);
					xmlmap.put("lastPur", lastPur);
				}
				for (Iterator iterator = element.elementIterator("BillingCycle"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					billCycle = titleElement.getText().trim();
					logger.info("XmlParser(); Billing Cycle is : " + billCycle);
					log.info("XmlParser(); Billing Cycle is : " + billCycle);
					xmlmap.put("billCycle", billCycle);
				}
				for (Iterator iterator = element.elementIterator("DateOpened"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dateOpened = titleElement.getText().trim();
					if (dateOpened.length() == 0) {
						logger.error("XmlParser(); Length of DateOpened is zero.");

						log.severe("XmlParser(); Length of DateOpened is zero.");
					}
					if (dateOpened.length() == 7) {
						dateOpened = "0" + dateOpened;
					}
					logger.info("XmlParser(); Date Opened is : " + dateOpened);

					log.info("XmlParser(); Date Opened is : " + dateOpened);
					xmlmap.put("dateOpened", dateOpened);
				}
				for (Iterator iterator = element.elementIterator("DueDate"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dueDate = titleElement.getText().trim();
					if (dueDate.length() == 0) {
						logger.error("XmlParser(); Length of Due Date is zero.");

						log.severe("XmlParser(); Length of Due Date is zero.");
					}
					if (dueDate.length() == 7) {
						dueDate = "0" + dueDate;
					}
					logger.info("XmlParser(); Due Date is : " + dueDate);

					log.info("XmlParser(); Due Date is : " + dueDate);
					xmlmap.put("dueDate", dueDate);
				}
				for (Iterator iterator = element.elementIterator("DateLastStatement"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dueLastStat = titleElement.getText().trim();
					if (dueLastStat.length() == 0) {
						logger.info("XmlParser(); Due Last Statement length is :" + dueLastStat.length());

						log.info("XmlParser(); Due Last Statement length is :" + dueLastStat.length());
					}
					if (dueLastStat.length() == 7) {
						dueLastStat = "0" + dueLastStat;
					}
					logger.info("XmlParser(); Due Last Statement is :" + dueLastStat);

					log.info("XmlParser(); Due Last Statement is :" + dueLastStat);
					xmlmap.put("dueLastStat", dueLastStat);
				}
				for (Iterator iterator = element.elementIterator("BlockCode2"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					blCode2 = titleElement.getText().trim();
					logger.info("XmlParser(); Block Code2 is : " + blCode2);

					log.info("XmlParser(); Block Code2 is : " + blCode2);
					xmlmap.put("blCode2", blCode2);
				}
				for (Iterator iterator = element.elementIterator("MemoBalance"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					memoBal = titleElement.getText().trim();
					logger.info("XmlParser(); Memo Balance is : " + memoBal);

					log.info("XmlParser(); Memo Balance is : " + memoBal);
					xmlmap.put("memoBal", memoBal);
				}
				for (Iterator iterator = element.elementIterator("CTAReason"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					ctaReason = titleElement.getText().trim();
					logger.info("XmlParser(); CTA Reason is : " + ctaReason);

					log.info("XmlParser(); CTA Reason is : " + ctaReason);
					xmlmap.put("ctaReason", ctaReason);
				}
				for (Iterator iterator = element.elementIterator("Title"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					title = titleElement.getText().trim();
					logger.info("XmlParser();Title is : " + title);

					log.info("XmlParser();Title is : " + title);
					xmlmap.put("title", title);
				}
				for (Iterator iterator = element.elementIterator("HomePhone"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					homePh = titleElement.getText().trim();
					logger.info("XmlParser(); Home Phone is : " + homePh);

					log.info("XmlParser(); Home Phone is : " + homePh);
					xmlmap.put("homePh", homePh);
				}
				for (Iterator iterator = element.elementIterator("EmployPhone"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					empPh = titleElement.getText().trim();
					logger.info("XmlParser(); Employ Phone is : " + empPh);

					log.info("XmlParser(); Employ Phone is : " + empPh);
					xmlmap.put("empPh", empPh);
				}
				for (Iterator iterator = element.elementIterator("MobilePhone"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					mobPh = titleElement.getText().trim();
					logger.info("XmlParser(); Mobile Phone is : " + mobPh);

					log.info("XmlParser(); Mobile Phone is : " + mobPh);
					xmlmap.put("mobPh", mobPh);
				}
				for (Iterator iterator = element.elementIterator("Name1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					name = titleElement.getText().trim();
					logger.info("XmlParser(); Name1 is : " + name);

					log.info("XmlParser(); Name1 is : " + name);
					xmlmap.put("name", name);
				}
				for (Iterator iterator = element.elementIterator("Memo1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					memo1 = titleElement.getText().trim();
					logger.info("XmlParser(); Memo1 is : " + memo1);

					log.info("XmlParser(); Memo1 is : " + memo1);
					xmlmap.put("memo1", memo1);
				}
				for (Iterator iterator = element.elementIterator("Memo2"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					memo2 = titleElement.getText().trim();
					logger.info("XmlParser(); Memo2 is : " + memo2);

					log.info("XmlParser(); Memo2 is : " + memo2);
					xmlmap.put("memo2", memo2);
				}
				for (Iterator iterator = element.elementIterator("BranchCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					branchCodeStr = titleElement.getText().trim();
					logger.info("XmlParser(); Branch code is : " + branchCodeStr);

					log.info("XmlParser(); Branch code is : " + branchCodeStr);
					xmlmap.put("branchCodeStr", branchCodeStr);
				}
				for (Iterator iterator = element.elementIterator("AmountLastPayment"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					amtLastPay = titleElement.getText().trim();
					logger.info("XmlParser(); Amount Last Payment is : " + amtLastPay);

					log.info("XmlParser(); Amount Last Payment is : " + amtLastPay);
					xmlmap.put("amtLastPay", amtLastPay);
				}
				for (Iterator iterator = element.elementIterator("DateLastPayment"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dateLastPay = titleElement.getText().trim();
					logger.info("XmlParser(); Date Last Payment is : " + dateLastPay);

					log.info("XmlParser(); Date Last Payment is : " + dateLastPay);
					xmlmap.put("dateLastPay", dateLastPay);
				}
				for (Iterator iterator = element.elementIterator("DelqTPD"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					delqTpd = titleElement.getText().trim();
					logger.info("XmlParser(); DelqTPD is : " + delqTpd);

					log.info("XmlParser(); DelqTPD is : " + delqTpd);
					xmlmap.put("delqTpd", delqTpd);
				}
				for (Iterator iterator = element.elementIterator("DelqXdayNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					delqXdayNo = titleElement.getText().trim();
					logger.info("XmlParser(); DelqXdayNumber is : " + delqXdayNo);

					log.info("XmlParser(); DelqXdayNumber is : " + delqXdayNo);
					xmlmap.put("delqXdayNo", delqXdayNo);
				}
				for (Iterator iterator = element.elementIterator("DelqXdayAmount"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					delqXdayAmt = titleElement.getText().trim();
					logger.info("XmlParser(); DelqXdayAmount is : " + delqXdayAmt);

					log.info("XmlParser(); DelqXdayAmount is : " + delqXdayAmt);
					xmlmap.put("delqXdayAmt", delqXdayAmt);
				}
				for (Iterator iterator = element.elementIterator("TITLE"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					title1 = titleElement.getText().trim();
					logger.info("XmlParser();Title is : " + title1);

					log.info("XmlParser();Title is : " + title1);
					xmlmap.put("title1", title1);
				}
				for (Iterator iterator = element.elementIterator("NAME"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					name1 = titleElement.getText().trim();
					logger.info("XmlParser(); NAME is : " + name1);

					log.info("XmlParser(); NAME is : " + name1);
					xmlmap.put("name1", name1);
				}
				for (Iterator iterator = element.elementIterator("Date"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					date = titleElement.getText().trim();

					if (emptyStr.equalsIgnoreCase(date)) {
						logger.info("XmlParser(); DueDate returned from MQ is empty.");

						log.info("XmlParser(); DueDate returned from MQ is empty.");
					}
					if (date.length() == 3) {
						date = "0" + date;
					}
					logger.info("XmlParser(); Date is : " + date);

					log.info("XmlParser(); Date is : " + date);
					xmlmap.put("date", date);
				}
				for (Iterator iterator = element.elementIterator("TODATEBALANCE1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					toDateBal = titleElement.getText().trim();
					logger.info("XmlParser(); To Date Balance is : " + toDateBal);

					log.info("XmlParser(); To Date Balance is : " + toDateBal);
					xmlmap.put("toDateBal", toDateBal);
				}
				for (Iterator iterator = element.elementIterator("BILLDT"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					billDt = titleElement.getText().trim();
					if (billDt.equalsIgnoreCase("")) {
						logger.info("XmlParser(); Bill Date from MQ is empty");

						log.info("XmlParser(); Bill Date from MQ is empty");
					}
					if (billDt.length() == 7) {
						billDt = "0" + billDt;

					}
					logger.info("XmlParser(); Bill Date  is : " + billDt);

					log.info("XmlParser(); Bill Date  is : " + billDt);
					xmlmap.put("billDt", billDt);
				}
				for (Iterator iterator = element.elementIterator("BILLBAL"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					billBal = titleElement.getText().trim();
					logger.info("XmlParser(); Billing Balance is : " + billBal);

					log.info("XmlParser(); Billing Balance is : " + billBal);
					xmlmap.put("billBal", billBal);
				}
				for (Iterator iterator = element.elementIterator("StatusMessage"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					statusMsg = titleElement.getText().trim();
					logger.info("XmlParser(); Status Message is : " + statusMsg);

					log.info("XmlParser(); Status Message is : " + statusMsg);
					xmlmap.put("statusMsg", statusMsg);
				}
				for (Iterator iterator = element.elementIterator("CardSeq"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardSeq = titleElement.getText().trim();
					logger.info("XmlParser(); Card Sequence is : " + cardSeq);

					log.info("XmlParser(); Card Sequence is : " + cardSeq);
					xmlmap.put("cardSeq", cardSeq);
				}
				for (Iterator iterator = element.elementIterator("UCI"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					uci = titleElement.getText().trim();
					logger.info("XmlParser(); UCI is : " + uci);

					log.info("XmlParser(); UCI is : " + uci);
					xmlmap.put("uci", uci);
				}
				for (Iterator iterator = element.elementIterator("CMFamilyName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmFamilyName = titleElement.getText().trim();
					logger.info("XmlParser(); CM Family Name is : " + cmFamilyName);

					log.info("XmlParser(); CM Family Name is : " + cmFamilyName);
					xmlmap.put("cmFamilyName", cmFamilyName);
				}
				for (Iterator iterator = element.elementIterator("LegalId"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					legalId = titleElement.getText().trim();
					logger.info("XmlParser(); Legal Id is : " + legalId);

					log.info("XmlParser(); Legal Id is : " + legalId);
					xmlmap.put("legalId", legalId);
				}
				for (Iterator iterator = element.elementIterator("ClientCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					clientCode = titleElement.getText().trim();
					logger.info("XmlParser(); Client Code is : " + clientCode);

					log.info("XmlParser(); Client Code is : " + clientCode);
					xmlmap.put("clientCode", clientCode);
				}

				for (Iterator iterator = element.elementIterator("CMBillingAddress"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmBillingAddress = titleElement.getText().trim();
					logger.info("XmlParser(); CMBilling Address is : " + cmBillingAddress);

					log.info("XmlParser(); CMBilling Address is : " + cmBillingAddress);
					xmlmap.put("cmBillingAddress", cmBillingAddress);
				}
				for (Iterator iterator = element.elementIterator("ClientUnderride"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					clientUnderride = titleElement.getText().trim();
					logger.info("XmlParser(); Client Underride is : " + clientUnderride);

					log.info("XmlParser(); Client Underride is : " + clientUnderride);
					xmlmap.put("clientUnderride", clientUnderride);
				}
				for (Iterator iterator = element.elementIterator("ClientOverride"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					clientOverride = titleElement.getText().trim();
					logger.info("XmlParser(); Client Override is : " + clientOverride);

					log.info("XmlParser(); Client Override is : " + clientOverride);
					xmlmap.put("clientOverride", clientOverride);
				}
				for (Iterator iterator = element.elementIterator("CardActivationFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardActivationFlag = titleElement.getText().trim();
					logger.info("XmlParser(); Card Activation Flag is : " + cardActivationFlag);

					log.info("XmlParser(); Card Activation Flag is : " + cardActivationFlag);
					xmlmap.put("cardActivationFlag", cardActivationFlag);
				}
				for (Iterator iterator = element.elementIterator("CardActivationDate"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardActivationDate = titleElement.getText().trim();
					logger.info("XmlParser(); Card Activation Date is : " + cardActivationDate);

					log.info("XmlParser(); Card Activation Date is : " + cardActivationDate);
					xmlmap.put("cardActivationDate", cardActivationDate);
				}
				for (Iterator iterator = element.elementIterator("CardExpiryDate"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardExpiryDate = titleElement.getText().trim();
					logger.info("XmlParser(); Card ExpiryDate is : " + cardExpiryDate);

					log.info("XmlParser(); Card ExpiryDate is : " + cardExpiryDate);
					xmlmap.put("cardExpiryDate", cardExpiryDate);
				}
				for (Iterator iterator = element.elementIterator("ProductType"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					productType = titleElement.getText().trim();
					logger.info("XmlParser(); Product Type is : " + productType);

					log.info("XmlParser(); Product Type is : " + productType);
					xmlmap.put("productType", productType);
				}
				for (Iterator iterator = element.elementIterator("PINStatus"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					pinStatus = titleElement.getText().trim();
					logger.info("XmlParser(); PIN Status is : " + pinStatus);

					log.info("XmlParser(); PIN Status is : " + pinStatus);
					xmlmap.put("pinStatus", pinStatus);
				}
				for (Iterator iterator = element.elementIterator("CardStatus"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardStatus = titleElement.getText().trim();
					logger.info("XmlParser(); Card Status is : " + cardStatus);

					log.info("XmlParser(); Card Status is : " + cardStatus);
					xmlmap.put("cardStatus", cardStatus);
				}
				for (Iterator iterator = element.elementIterator("ProductName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					productName = titleElement.getText().trim();
					logger.info("XmlParser(); Product Name is : " + productName);

					log.info("XmlParser(); Product Name is : " + productName);
					xmlmap.put("productName", productName);
				}
				for (Iterator iterator = element.elementIterator("EmployeeID"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					employeeID = titleElement.getText().trim();
					logger.info("XmlParser(); Employee ID is : " + employeeID);

					log.info("XmlParser(); Employee ID is : " + employeeID);
					xmlmap.put("employeeID", employeeID);
				}
				for (Iterator iterator = element.elementIterator("RMName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					rmName = titleElement.getText().trim();
					logger.info("XmlParser(); RMName is : " + rmName);

					log.info("XmlParser(); RMName is : " + rmName);
					xmlmap.put("rmName", rmName);
				}
				for (Iterator iterator = element.elementIterator("VIPLevel"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					vipLevel = titleElement.getText().trim();
					logger.info("XmlParser(); VIPLevel is : " + vipLevel);

					log.info("XmlParser(); VIPLevel is : " + vipLevel);
					xmlmap.put("vipLevel", vipLevel);
				}
				for (Iterator iterator = element.elementIterator("StopList"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					stopList = titleElement.getText().trim();
					logger.info("XmlParser(); Stop List is : " + stopList);

					log.info("XmlParser(); Stop List is : " + stopList);
					xmlmap.put("stopList", stopList);
				}
				for (Iterator iterator = element.elementIterator("Transaction"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					transaction = titleElement.getText().trim();
					logger.info("XmlParser(); Transaction is : " + transaction);

					log.info("XmlParser(); Transaction is : " + transaction);
					xmlmap.put("transaction", transaction);
				}
			}

			// ***********************************************
			// This is used for new SOA messages
			// ***********************************************
			Iterator iter1 = list1.iterator();
			logger.info("XmlParser(); Node is : //Message_Res");

			log.info("XmlParser(); Node is : //Message_Res");
			while (iter1.hasNext()) {
				Element element = (Element) iter1.next();
				for (Iterator iterator = element.elementIterator("SSO"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					ssoStr = titleElement.getText().trim();
					logger.info("XmlParser(); SSO is : " + ssoStr);

					log.info("XmlParser(); SSO is : " + ssoStr);
					xmlmap.put("ssoStr", ssoStr);
				}
				for (Iterator iterator = element.elementIterator("DateTimeStamp"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dateTimeStampStr = titleElement.getText().trim();
					logger.info("XmlParser(); DateTimeStamp is : " + dateTimeStampStr);

					log.info("XmlParser(); DateTimeStamp is : " + dateTimeStampStr);
					xmlmap.put("dateTimeStampStr", dateTimeStampStr);
				}
				for (Iterator iterator = element.elementIterator("AuditSeq"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					auditSeqStr = titleElement.getText().trim();
					logger.info("XmlParser(); AuditSeq is : " + auditSeqStr);

					log.info("XmlParser(); AuditSeq is : " + auditSeqStr);
					xmlmap.put("auditSeqStr", auditSeqStr);
				}
				for (Iterator iterator = element.elementIterator("MessageID"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					msgIdActualStr = titleElement.getText().trim();
					logger.info("XmlParser(); MessageID is : " + msgIdActualStr);

					log.info("XmlParser(); MessageID is : " + msgIdActualStr);
					xmlmap.put("msgIdActualStr", msgIdActualStr);
				}
				for (Iterator iterator = element.elementIterator("Description"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					description = titleElement.getText().trim();
					logger.info("XmlParser(); Description is : " + description);

					log.info("XmlParser(); Description is : " + description);
					xmlmap.put("description", description);
				}
				for (Iterator iterator = element.elementIterator("DateOfBirth"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dateOfBirth = titleElement.getText().trim();
					logger.info("XmlParser(); DateOfBirth is : " + dateOfBirth);

					log.info("XmlParser(); DateOfBirth is : " + dateOfBirth);
					xmlmap.put("dateOfBirth", dateOfBirth);
				}
				for (Iterator iterator = element.elementIterator("ErrorCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					errCode = titleElement.getText().trim();
					logger.info("XmlParser(); ErrorCode is : " + errCode);

					log.info("XmlParser(); ErrorCode is : " + errCode);
					xmlmap.put("errCode", errCode);
				}
				for (Iterator iterator = element.elementIterator("ErrorDescription"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					errDesc = titleElement.getText().trim();
					logger.info("XmlParser(); ErrorDescription is : " + errDesc);

					log.info("XmlParser(); ErrorDescription is : " + errDesc);
					xmlmap.put("errDesc", errDesc);
				}
				for (Iterator iterator = element.elementIterator("ErrorDesc"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					errDesc = titleElement.getText().trim();
					logger.info("XmlParser(); ErrorDescription is : " + errDesc);

					log.info("XmlParser(); ErrorDescription is : " + errDesc);
					xmlmap.put("errDesc", errDesc);
				}
				for (Iterator iterator = element.elementIterator("ErrorMsg"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					errorDescription = titleElement.getText().trim();
					logger.info("XmlParser(); Error message is : " + errorDescription);

					log.info("XmlParser(); Error message is : " + errorDescription);
					xmlmap.put("errorMsg", errorDescription);
				}

				for (Iterator iterator = element.elementIterator("error_code"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					errCode = titleElement.getText().trim();
					logger.info("XmlParser(); ErrorCode is : " + errCode);

					log.info("XmlParser(); ErrorCode is : " + errCode);
					xmlmap.put("errCode", errCode);
				}
				for (Iterator iterator = element.elementIterator("error_message"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					errDesc = titleElement.getText().trim();
					logger.info("XmlParser(); ErrorDescription is : " + errDesc);

					log.info("XmlParser(); ErrorDescription is : " + errDesc);
					xmlmap.put("errDesc", errDesc);
				}
				for (Iterator iterator = element.elementIterator("powercardID"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					powercardID = titleElement.getText().trim();
					logger.info("XmlParser(); PowercardID is : " + powercardID);

					log.info("XmlParser(); PowercardID is : " + powercardID);
					xmlmap.put("powcardID", powercardID);
				}
				for (Iterator iterator = element.elementIterator("Org"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					orgStr = titleElement.getText().trim();
					logger.info("XmlParser(); Org is : " + orgStr);

					log.info("XmlParser(); Org is : " + orgStr);
					xmlmap.put("orgStr", orgStr);
				}
				for (Iterator iterator = element.elementIterator("Logo"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					logoStr = titleElement.getText().trim();
					logger.info("XmlParser(); Logo is : " + logoStr);

					log.info("XmlParser(); Logo is : " + logoStr);
					xmlmap.put("logoStr", logoStr);
				}
				for (Iterator iterator = element.elementIterator("CurrencyName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					currencyName = titleElement.getText().trim();
					logger.info("XmlParser(); CurrencyName is : " + currencyName);

					log.info("XmlParser(); CurrencyName is : " + currencyName);
					xmlmap.put("currencyName", currencyName);
				}
				for (Iterator iterator = element.elementIterator("PrimSupplFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					primSuppFlag = titleElement.getText().trim();
					logger.info("XmlParser(); Primary Supply Flag is : " + primSuppFlag);

					log.info("XmlParser(); Primary Supply Flag is : " + primSuppFlag);
					xmlmap.put("primSuppFlag", primSuppFlag);
				}
				for (Iterator iterator = element.elementIterator("Title"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					title = titleElement.getText().trim();
					logger.info("XmlParser(); Title is : " + title);

					log.info("XmlParser(); Title is : " + title);
					xmlmap.put("title", title);
				}
				for (Iterator iterator = element.elementIterator("Name1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					name1 = titleElement.getText().trim();
					logger.info("XmlParser(); Name1 is : " + name1);

					log.info("XmlParser(); Name1 is : " + name1);
					xmlmap.put("name1", name1);
				}
				for (Iterator iterator = element.elementIterator("StatementAddress1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					statAddress1 = titleElement.getText().trim();
					logger.info("XmlParser(); StatementAddress1 is : " + statAddress1);

					log.info("XmlParser(); StatementAddress1 is : " + statAddress1);
					xmlmap.put("statAddress1", statAddress1);
				}
				for (Iterator iterator = element.elementIterator("StatementAddress2"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					statAddress2 = titleElement.getText().trim();
					logger.info("XmlParser(); StatementAddress2 is : " + statAddress2);

					log.info("XmlParser(); StatementAddress2 is : " + statAddress2);
					xmlmap.put("statAddress2", statAddress2);
				}
				for (Iterator iterator = element.elementIterator("StatementAddress3"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					statAddress3 = titleElement.getText().trim();
					logger.info("XmlParser(); StatementAddress3 is : " + statAddress3);

					log.info("XmlParser(); StatementAddress3 is : " + statAddress3);
					xmlmap.put("statAddress3", statAddress3);
				}
				for (Iterator iterator = element.elementIterator("HomeNO"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					homePh = titleElement.getText().trim();
					logger.info("XmlParser(); Home NO is : " + homePh);

					log.info("XmlParser(); Home NO is : " + homePh);
					xmlmap.put("homeNO", homePh);
				}
				for (Iterator iterator = element.elementIterator("HomeCountrySel"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					homeCountrySel = titleElement.getText().trim();
					logger.info("XmlParser(); HomeCountrySel is : " + homeCountrySel);

					log.info("XmlParser(); HomeCountrySel is : " + homeCountrySel);
					xmlmap.put("homeCountry", homeCountrySel);
				}
				for (Iterator iterator = element.elementIterator("MobileNO"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					mobPh = titleElement.getText().trim();
					logger.info("XmlParser(); Mobile NO is : " + mobPh);

					log.info("XmlParser(); Mobile NO is : " + mobPh);
					xmlmap.put("mobNO", mobPh);
				}

				for (Iterator iterator = element.elementIterator("MobileNOCountySel"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					mobCountry = titleElement.getText().trim();
					logger.info("XmlParser(); MobileNOCountySel is : " + mobCountry);

					log.info("XmlParser(); MobileNOCountySel is : " + mobCountry);
					xmlmap.put("mobNOCountry", mobCountry);
				}

				for (Iterator iterator = element.elementIterator("EmailID"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					emailID = titleElement.getText().trim();
					logger.info("XmlParser(); EmailID is : " + emailID);

					log.info("XmlParser(); EmailID is : " + emailID);
					xmlmap.put("emailID", emailID);
				}
				for (Iterator iterator = element.elementIterator("Memo1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					memo1 = titleElement.getText().trim();
					logger.info("XmlParser(); Memo1 is : " + memo1);

					log.info("XmlParser(); Memo1 is : " + memo1);
					xmlmap.put("memo1", memo1);
				}
				for (Iterator iterator = element.elementIterator("Memo2"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					memo2 = titleElement.getText().trim();
					logger.info("XmlParser(); Memo2 is : " + memo2);

					log.info("XmlParser(); Memo2 is : " + memo2);
					xmlmap.put("memo2", memo2);
				}
				for (Iterator iterator = element.elementIterator("WorkNO"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					workNO = titleElement.getText().trim();
					logger.info("XmlParser(); WorkNO is : " + workNO);

					log.info("XmlParser(); WorkNO is : " + workNO);
					xmlmap.put("workNO", workNO);
				}

				for (Iterator iterator = element.elementIterator("WorkNoCountrySel"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					workCountrySel = titleElement.getText().trim();
					logger.info("XmlParser(); WorkNoCountrySel is : " + workCountrySel);

					log.info("XmlParser(); WorkNoCountrySel is : " + workCountrySel);
					xmlmap.put("workCountry", workCountrySel);
				}
				for (Iterator iterator = element.elementIterator("SMSFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					smsFlag = titleElement.getText().trim();
					logger.info("XmlParser(); SMSFlag is : " + smsFlag);

					log.info("XmlParser(); SMSFlag is : " + smsFlag);
					xmlmap.put("smsFlag", smsFlag);
				}
				for (Iterator iterator = element.elementIterator("eStatementFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					eStatFlag = titleElement.getText().trim();
					logger.info("XmlParser(); eStatementFlag is : " + eStatFlag);

					log.info("XmlParser(); eStatementFlag is : " + eStatFlag);
					xmlmap.put("eStatFlag", eStatFlag);
				}
				for (Iterator iterator = element.elementIterator("branchCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					branchCodeStr = titleElement.getText().trim();
					logger.info("XmlParser(); Branch code is : " + branchCodeStr);

					log.info("XmlParser(); Branch code is : " + branchCodeStr);
					xmlmap.put("branchCodeStr", branchCodeStr);
				}
				for (Iterator iterator = element.elementIterator("productCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					prodCodeStr = titleElement.getText().trim();
					logger.info("XmlParser(); Product code is : " + prodCodeStr);

					log.info("XmlParser(); Product code is : " + prodCodeStr);
					xmlmap.put("prodCodeStr", prodCodeStr);
				}
				for (Iterator iterator = element.elementIterator("OTB"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					otb = titleElement.getText().trim();
					logger.info("XmlParser(); OTB is : " + otb);

					log.info("XmlParser(); OTB is : " + otb);
					xmlmap.put("otb", otb);
				}
				for (Iterator iterator = element.elementIterator("CurrentBalance"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					curBal = titleElement.getText().trim();
					logger.info("XmlParser(); Current Balance is : " + curBal);

					log.info("XmlParser(); Current Balance is : " + curBal);
					xmlmap.put("curBal", curBal);
				}
				for (Iterator iterator = element.elementIterator("DueDate"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dueDate = titleElement.getText().trim();
					if (dueDate.length() == 0) {
						logger.error("XmlParser(); Length of Due Date is zero.");

						log.severe("XmlParser(); Length of Due Date is zero.");
					}
					if (dueDate.length() == 7) {
						dueDate = "0" + dueDate;
					}
					logger.info("XmlParser(); Due Date is : " + dueDate);

					log.info("XmlParser(); Due Date is : " + dueDate);
					xmlmap.put("dueDate", dueDate);
				}
				for (Iterator iterator = element.elementIterator("CashAvailable"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cashAvail = titleElement.getText().trim();
					logger.info("XmlParser(); Cash Available is : " + cashAvail);

					log.info("XmlParser(); Cash Available is : " + cashAvail);
					xmlmap.put("cashAvail", cashAvail);
				}

				for (Iterator iterator = element.elementIterator("AmountDue"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					amntDue = titleElement.getText().trim();
					logger.info("XmlParser(); Amount Due is : " + amntDue);

					log.info("XmlParser(); Amount Due is : " + amntDue);
					xmlmap.put("amntDue", amntDue);
				}
				for (Iterator iterator = element.elementIterator("TotalCreditLimit"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					totCreLimit = titleElement.getText().trim();
					logger.info("XmlParser(); Total Credit Limit is : " + totCreLimit);

					log.info("XmlParser(); Total Credit Limit is : " + totCreLimit);
					xmlmap.put("totCreLimit", totCreLimit);
				}
				for (Iterator iterator = element.elementIterator("BeginBalance"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					bgnBal = titleElement.getText().trim();
					logger.info("XmlParser(); Begin Balance is : " + bgnBal);

					log.info("XmlParser(); Begin Balance is : " + bgnBal);
					xmlmap.put("bgnBal", bgnBal);
				}
				for (Iterator iterator = element.elementIterator("DateLastPayment"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dateLastPay = titleElement.getText().trim();
					logger.info("XmlParser(); Date Last Payment is : " + dateLastPay);

					log.info("XmlParser(); Date Last Payment is : " + dateLastPay);
					xmlmap.put("dateLastPay", dateLastPay);
				}
				for (Iterator iterator = element.elementIterator("AmountPurchasesCTD"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					amountPurchCTD = titleElement.getText().trim();
					logger.info("XmlParser(); AmountPurchasesCTD is : " + amountPurchCTD);

					log.info("XmlParser(); AmountPurchasesCTD is : " + amountPurchCTD);
					xmlmap.put("amountPurchCTD", amountPurchCTD);
				}
				for (Iterator iterator = element.elementIterator("AmountPurchasesYTD"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					amountPurchYTD = titleElement.getText().trim();
					logger.info("XmlParser(); AmountPurchasesYTD is : " + amountPurchYTD);

					log.info("XmlParser(); AmountPurchasesYTD is : " + amountPurchYTD);
					xmlmap.put("amountPurchYTD", amountPurchYTD);
				}
				for (Iterator iterator = element.elementIterator("AmountPurchasesLTD"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					amountPurchLTD = titleElement.getText().trim();
					logger.info("XmlParser(); AmountPurchasesLTD is : " + amountPurchLTD);

					log.info("XmlParser(); AmountPurchasesLTD is : " + amountPurchLTD);
					xmlmap.put("amountPurchLTD", amountPurchLTD);
				}
				for (Iterator iterator = element.elementIterator("AmountCashCTD"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					amountCashCTD = titleElement.getText().trim();
					logger.info("XmlParser(); AmountCashCTDis : " + amountCashCTD);

					log.info("XmlParser(); AmountCashCTDis : " + amountCashCTD);
					xmlmap.put("amountCashCTD", amountCashCTD);
				}
				for (Iterator iterator = element.elementIterator("AmountCashYTD"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					amountCashYTD = titleElement.getText().trim();
					logger.info("XmlParser(); AmountCashYTD is : " + amountCashYTD);

					log.info("XmlParser(); AmountCashYTD is : " + amountCashYTD);
					xmlmap.put("amountCashYTD", amountCashYTD);
				}
				for (Iterator iterator = element.elementIterator("CashBalance"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cashBal = titleElement.getText().trim();
					logger.info("XmlParser(); Cash Balance is : " + cashBal);

					log.info("XmlParser(); Cash Balance is : " + cashBal);
					xmlmap.put("cashBal", cashBal);
				}
				for (Iterator iterator = element.elementIterator("CashCreditLimit"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cashCreLimit = titleElement.getText().trim();
					logger.info("XmlParser(); Cash Credit Limit is : " + cashCreLimit);

					log.info("XmlParser(); Cash Credit Limit is : " + cashCreLimit);
					xmlmap.put("cashCreLimit", cashCreLimit);
				}
				for (Iterator iterator = element.elementIterator("AmountCashLTD"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					amountCashLTD = titleElement.getText().trim();
					logger.info("XmlParser(); AmountCashLTD is : " + amountCashLTD);

					log.info("XmlParser(); AmountCashLTD is : " + amountCashLTD);
					xmlmap.put("amountCashLTD", amountCashLTD);
				}
				for (Iterator iterator = element.elementIterator("LastPurchase"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					lastPur = titleElement.getText().trim();
					logger.info("XmlParser(); Last Purchase is : " + lastPur);

					log.info("XmlParser(); Last Purchase is : " + lastPur);
					xmlmap.put("lastPur", lastPur);
				}
				for (Iterator iterator = element.elementIterator("DateLastStatement"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dueLastStat = titleElement.getText().trim();
					if (dueLastStat.length() == 0) {
						logger.info("XmlParser(); Due Last Statement length is :" + dueLastStat.length());

						log.info("XmlParser(); Due Last Statement length is :" + dueLastStat.length());
					}
					if (dueLastStat.length() == 7) {
						dueLastStat = "0" + dueLastStat;
					}
					logger.info("XmlParser(); Due Last Statement is :" + dueLastStat);

					log.info("XmlParser(); Due Last Statement is :" + dueLastStat);
					xmlmap.put("dueLastStat", dueLastStat);
				}
				for (Iterator iterator = element.elementIterator("LastStmtBal"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					lastStmtBal = titleElement.getText().trim();
					logger.info("XmlParser(); LastStmtBal is : " + lastStmtBal);

					log.info("XmlParser(); LastStmtBal is : " + lastStmtBal);
					xmlmap.put("lastStmtBal", lastStmtBal);
				}

				for (Iterator iterator = element.elementIterator("BillingCycle"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					billCycle = titleElement.getText().trim();
					logger.info("XmlParser(); Billing Cycle is : " + billCycle);

					log.info("XmlParser(); Billing Cycle is : " + billCycle);
					xmlmap.put("billCycle", billCycle);
				}
				for (Iterator iterator = element.elementIterator("Status"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					status = titleElement.getText().trim();
					logger.info("XmlParser(); Status is : " + status);

					log.info("XmlParser(); Status is : " + status);
					xmlmap.put("status", status);
				}
				for (Iterator iterator = element.elementIterator("DateOpened"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dateOpened = titleElement.getText().trim();
					if (dateOpened.length() == 0) {
						logger.error("XmlParser(); Length of DateOpened is zero.");

						log.severe("XmlParser(); Length of DateOpened is zero.");
					}
					if (dateOpened.length() == 7) {
						dateOpened = "0" + dateOpened;
					}
					logger.info("XmlParser(); Date Opened is : " + dateOpened);

					log.info("XmlParser(); Date Opened is : " + dateOpened);
					xmlmap.put("dateOpened", dateOpened);
				}
				for (Iterator iterator = element.elementIterator("PastDue"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					pastDue = titleElement.getText().trim();
					logger.info("XmlParser(); Past Due is : " + pastDue);

					log.info("XmlParser(); Past Due is : " + pastDue);
					xmlmap.put("pastDue", pastDue);
				}
				for (Iterator iterator = element.elementIterator("BlockCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					blCode = titleElement.getText().trim();
					logger.info("XmlParser(); Block Code is : " + blCode);

					log.info("XmlParser(); Block Code is : " + blCode);
					xmlmap.put("blCode", blCode);
				}
				for (Iterator iterator = element.elementIterator("BlockCode2"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					blCode2 = titleElement.getText().trim();
					logger.info("XmlParser(); Block Code2 is : " + blCode2);

					log.info("XmlParser(); Block Code2 is : " + blCode2);
					xmlmap.put("blCode2", blCode2);
				}
				for (Iterator iterator = element.elementIterator("OverdueFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					overdueFlag = titleElement.getText().trim();
					logger.info("XmlParser(); OverdueFlag is : " + overdueFlag);

					log.info("XmlParser(); OverdueFlag is : " + overdueFlag);
					xmlmap.put("overdueFlag", overdueFlag);
				}
				for (Iterator iterator = element.elementIterator("CTAReason"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					ctaReason = titleElement.getText().trim();
					logger.info("XmlParser(); CTA Reason is : " + ctaReason);

					log.info("XmlParser(); CTA Reason is : " + ctaReason);
					xmlmap.put("ctaReason", ctaReason);
				}
				for (Iterator iterator = element.elementIterator("MemoBalance"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					memoBal = titleElement.getText().trim();
					logger.info("XmlParser(); Memo Balance is : " + memoBal);

					log.info("XmlParser(); Memo Balance is : " + memoBal);
					xmlmap.put("memoBal", memoBal);
				}
				for (Iterator iterator = element.elementIterator("DateCardFee"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dateCardFee = titleElement.getText().trim();
					logger.info("XmlParser(); DateCardFee : " + dateCardFee);

					log.info("XmlParser(); DateCardFee : " + dateCardFee);
					xmlmap.put("dateCardFee", dateCardFee);
				}
				for (Iterator iterator = element.elementIterator("MemberSince"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					memberSince = titleElement.getText().trim();
					logger.info("XmlParser(); MemberSince is : " + memberSince);

					log.info("XmlParser(); MemberSince is : " + memberSince);
					xmlmap.put("memberSince", memberSince);
				}
				for (Iterator iterator = element.elementIterator("AmountLastPayment"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					amtLastPay = titleElement.getText().trim();
					logger.info("XmlParser(); Amount Last Payment is : " + amtLastPay);

					log.info("XmlParser(); Amount Last Payment is : " + amtLastPay);
					xmlmap.put("amtLastPay", amtLastPay);
				}
				for (Iterator iterator = element.elementIterator("DelqTPD"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					delqTpd = titleElement.getText().trim();
					logger.info("XmlParser(); DelqTPD is : " + delqTpd);

					log.info("XmlParser(); DelqTPD is : " + delqTpd);
					xmlmap.put("delqTpd", delqTpd);
				}
				for (Iterator iterator = element.elementIterator("DelqXdayNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					delqXdayNo = titleElement.getText().trim();
					logger.info("XmlParser(); DelqXdayNumber is : " + delqXdayNo);

					log.info("XmlParser(); DelqXdayNumber is : " + delqXdayNo);
					xmlmap.put("delqXdayNo", delqXdayNo);
				}
				for (Iterator iterator = element.elementIterator("DelqXdayAmount"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					delqXdayAmt = titleElement.getText().trim();
					logger.info("XmlParser(); DelqXdayAmount is : " + delqXdayAmt);

					log.info("XmlParser(); DelqXdayAmount is : " + delqXdayAmt);
					xmlmap.put("delqXdayAmt", delqXdayAmt);
				}
				for (Iterator iterator = element.elementIterator("DBC"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					dbc = titleElement.getText().trim();
					logger.info("XmlParser(); DBC is : " + dbc);

					log.info("XmlParser(); DBC is : " + dbc);
					xmlmap.put("dbc", dbc);
				}
				for (Iterator iterator = element.elementIterator("EmbossName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					embossName = titleElement.getText().trim();
					logger.info("XmlParser(); EmbossName is : " + embossName);

					log.info("XmlParser(); EmbossName is : " + embossName);
					xmlmap.put("embossName", embossName);
				}
				for (Iterator iterator = element.elementIterator("ExpiryDate"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					expiryDate = titleElement.getText().trim();
					logger.info("XmlParser(); Expiry Date is : " + expiryDate);

					log.info("XmlParser(); Expiry Date is : " + expiryDate);
					xmlmap.put("expiryDate", expiryDate);
				}

				for (Iterator iterator = element.elementIterator("EnrolledStatus"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					enrolledStatus = titleElement.getText().trim();
					logger.info("XmlParser(); EnrolledStatus is : " + enrolledStatus);

					log.info("XmlParser(); EnrolledStatus is : " + enrolledStatus);
					xmlmap.put("EnrolledStatus", enrolledStatus);
				}
				for (Iterator iterator = element.elementIterator("Length"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					Length = titleElement.getText().trim();
					logger.info("XmlParser(); Length is : " + Length);

					log.info("XmlParser(); Length is : " + Length);
					xmlmap.put("Length", Length);
				}
				for (Iterator iterator = element.elementIterator("PassportNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					passportNum = titleElement.getText().trim();
					logger.info("XmlParser(); PassportNumber is : " + passportNum);

					log.info("XmlParser(); PassportNumber is : " + passportNum);
					xmlmap.put("passportNum", passportNum);
				}
				for (Iterator iterator = element.elementIterator("CPRID"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cprid = titleElement.getText().trim();
					logger.info("XmlParser(); CPRID is : " + cprid);

					log.info("XmlParser(); CPRID is : " + cprid);
					xmlmap.put("cprid", cprid);
				}
				for (Iterator iterator = element.elementIterator("BankName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					bankName = titleElement.getText().trim();
					logger.info("XmlParser(); BankName is : " + bankName);

					log.info("XmlParser(); BankName is : " + bankName);
					xmlmap.put("bankName", bankName);
				}
				for (Iterator iterator = element.elementIterator("BankBranch"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					bankBranch = titleElement.getText().trim();
					logger.info("XmlParser(); BankBranch is : " + bankBranch);

					log.info("XmlParser(); BankBranch is : " + bankBranch);
					xmlmap.put("bankBranch", bankBranch);
				}
				for (Iterator iterator = element.elementIterator("BankAccountNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					bankAccountNumber = titleElement.getText().trim();
					logger.info("XmlParser(); BankAccountNumber is : " + bankAccountNumber);

					log.info("XmlParser(); BankAccountNumber is : " + bankAccountNumber);
					xmlmap.put("bankAccNumber", bankAccountNumber);
				}
				for (Iterator iterator = element.elementIterator("Nationality"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					nationality = titleElement.getText().trim();
					logger.info("XmlParser(); Nationality is : " + nationality);

					log.info("XmlParser(); Nationality is : " + nationality);
					xmlmap.put("nationality", nationality);
				}
				for (Iterator iterator = element.elementIterator("Income"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					income = titleElement.getText().trim();
					logger.info("XmlParser(); Income is : " + income);

					log.info("XmlParser(); Income is : " + income);
					xmlmap.put("income", income);
				}
				for (Iterator iterator = element.elementIterator("XRef1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					xRef1 = titleElement.getText().trim();
					logger.info("XmlParser(); XRef1 is : " + xRef1);

					log.info("XmlParser(); XRef1 is : " + xRef1);
					xmlmap.put("xRef1", xRef1);
				}
				for (Iterator iterator = element.elementIterator("XRef2"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					xRef2 = titleElement.getText().trim();
					logger.info("XmlParser(); XRef2 is : " + xRef2);

					log.info("XmlParser(); XRef2 is : " + xRef2);
					xmlmap.put("xRef2", xRef2);
				}
				for (Iterator iterator = element.elementIterator("HomeAddress1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					homeAddr1 = titleElement.getText().trim();
					logger.info("XmlParser(); HomeAddress1 is : " + homeAddr1);

					log.info("XmlParser(); HomeAddress1 is : " + homeAddr1);
					xmlmap.put("homeAddr1", homeAddr1);
				}
				for (Iterator iterator = element.elementIterator("HomeAddress2"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					homeAddr2 = titleElement.getText().trim();
					logger.info("XmlParser(); HomeAddress2 is : " + homeAddr2);

					log.info("XmlParser(); HomeAddress2 is : " + homeAddr2);
					xmlmap.put("homeAddr2", homeAddr2);
				}
				for (Iterator iterator = element.elementIterator("HomeAddress3"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					homeAddr3 = titleElement.getText().trim();
					logger.info("XmlParser(); HomeAddress3 is : " + homeAddr3);

					log.info("XmlParser(); HomeAddress3 is : " + homeAddr3);
					xmlmap.put("homeAddr3", homeAddr3);
				}
				for (Iterator iterator = element.elementIterator("HomePhoneArea"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					homePhArea = titleElement.getText().trim();
					logger.info("XmlParser(); HomePhoneArea is : " + homePhArea);

					log.info("XmlParser(); HomePhoneArea is : " + homePhArea);
					xmlmap.put("homePhArea", homePhArea);
				}
				for (Iterator iterator = element.elementIterator("HomePhone"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					homePh = titleElement.getText().trim();
					logger.info("XmlParser(); Home Phone is : " + homePh);

					log.info("XmlParser(); Home Phone is : " + homePh);
					xmlmap.put("homePh", homePh);
				}
				for (Iterator iterator = element.elementIterator("HomeEmail"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					homeMail = titleElement.getText().trim();
					logger.info("XmlParser(); HomeEmail is : " + homeMail);

					log.info("XmlParser(); HomeEmail is : " + homeMail);
					xmlmap.put("homeMail", homeMail);
				}
				for (Iterator iterator = element.elementIterator("PreviousAddress1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					prevAddr1 = titleElement.getText().trim();
					logger.info("XmlParser(); PreviousAddress1 is : " + prevAddr1);

					log.info("XmlParser(); PreviousAddress1 is : " + prevAddr1);
					xmlmap.put("prevAddr1", prevAddr1);
				}
				for (Iterator iterator = element.elementIterator("PreviousAddress2"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					prevAddr2 = titleElement.getText().trim();
					logger.info("XmlParser(); PreviousAddress2 is : " + prevAddr2);

					log.info("XmlParser(); PreviousAddress2 is : " + prevAddr2);
					xmlmap.put("prevAddr2", prevAddr2);
				}
				for (Iterator iterator = element.elementIterator("PreviousAddress3"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					prevAddr3 = titleElement.getText().trim();
					logger.info("XmlParser(); PreviousAddress3 is : " + prevAddr3);

					log.info("XmlParser(); PreviousAddress3 is : " + prevAddr3);
					xmlmap.put("prevAddr3", prevAddr3);
				}

				for (Iterator iterator = element.elementIterator("EmployerAddress1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					empAddr1 = titleElement.getText().trim();
					logger.info("XmlParser(); EmployerAddress1 is : " + empAddr1);

					log.info("XmlParser(); EmployerAddress1 is : " + empAddr1);
					xmlmap.put("empAddr1", empAddr1);
				}
				for (Iterator iterator = element.elementIterator("EmployerAddress2"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					empAddr2 = titleElement.getText().trim();
					logger.info("XmlParser(); EmployerAddress2 is : " + empAddr2);

					log.info("XmlParser(); EmployerAddress2 is : " + empAddr2);
					xmlmap.put("empAddr2", empAddr2);
				}
				for (Iterator iterator = element.elementIterator("EmployerAddress3"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					empAddr3 = titleElement.getText().trim();
					logger.info("XmlParser(); EmployerAddress3 is : " + empAddr3);

					log.info("XmlParser(); EmployerAddress3 is : " + empAddr3);
					xmlmap.put("empAddr3", empAddr3);
				}
				for (Iterator iterator = element.elementIterator("EmployerName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					empName = titleElement.getText().trim();
					logger.info("XmlParser(); EmployerName is : " + empName);

					log.info("XmlParser(); EmployerName is : " + empName);
					xmlmap.put("empName", empName);
				}
				for (Iterator iterator = element.elementIterator("EmployerPhone"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					empPhone = titleElement.getText().trim();
					logger.info("XmlParser(); EmployerPhone is : " + empPhone);

					log.info("XmlParser(); EmployerPhone is : " + empPhone);
					xmlmap.put("empPhone", empPhone);
				}
				for (Iterator iterator = element.elementIterator("EmployerPhoneArea"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					empPhArea = titleElement.getText().trim();
					logger.info("XmlParser(); EmployerPhoneArea is : " + empPhArea);

					log.info("XmlParser(); EmployerPhoneArea is : " + empPhArea);
					xmlmap.put("empPhArea", empPhArea);
				}
				for (Iterator iterator = element.elementIterator("EmployerFax"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					empFax = titleElement.getText().trim();
					logger.info("XmlParser(); EmployerFax is : " + empFax);

					log.info("XmlParser(); EmployerFax is : " + empFax);
					xmlmap.put("empFax", empFax);
				}
				for (Iterator iterator = element.elementIterator("EmployerEmail"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					empMail = titleElement.getText().trim();
					logger.info("XmlParser(); EmployerEmail is : " + empMail);

					log.info("XmlParser(); EmployerEmail is : " + empMail);
					xmlmap.put("empMail", empMail);
				}

				for (Iterator iterator = element.elementIterator("MobilePhone"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					mobPh = titleElement.getText().trim();
					logger.info("XmlParser(); Mobile Phone is : " + mobPh);

					log.info("XmlParser(); Mobile Phone is : " + mobPh);
					xmlmap.put("mobPh", mobPh);
				}
				for (Iterator iterator = element.elementIterator("PageSize"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					pageSize = titleElement.getText().trim();
					logger.info("XmlParser(); PageSize is : " + pageSize);

					log.info("XmlParser(); PageSize is : " + pageSize);
					xmlmap.put("pageSize", pageSize);
				}
				for (Iterator iterator = element.elementIterator("StartPosition"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					startPos = titleElement.getText().trim();
					logger.info("XmlParser(); StartPosition is : " + startPos);

					log.info("XmlParser(); StartPosition is : " + startPos);
					xmlmap.put("startPos", startPos);
				}
				for (Iterator iterator = element.elementIterator("NumberOfRecords"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					numRec = titleElement.getText().trim();
					logger.info("XmlParser(); NumberOfRecords is : " + numRec);

					log.info("XmlParser(); NumberOfRecords is : " + numRec);
					xmlmap.put("numRec", numRec);
				}
				for (Iterator iterator = element.elementIterator("MoreRecordsFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					moreRec = titleElement.getText().trim();
					logger.info("XmlParser(); MoreRecordsFlag is : " + moreRec);

					log.info("XmlParser(); MoreRecordsFlag is : " + moreRec);
					xmlmap.put("moreRec", moreRec);
				}
				for (Iterator iterator = element.elementIterator("AccountNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					accNum = titleElement.getText().trim();
					if (accNum.length() == 12) {
						// maskAccNum = accNum.replace(accNum.subSequence(4,
						// accNum.length()-5),maskString2);
						maskAccNum = accNum.substring(0, 4) + "***"
								+ accNum.substring(accNum.length() - 5, accNum.length());
						logger.info("XmlParser(); Account Number is : " + maskAccNum);

						log.info("XmlParser(); Account Number is : " + maskAccNum);
					} else {
						logger.info("XmlParser(); Account Number is less than 12 digits.");

						log.info("XmlParser(); Account Number is less than 12 digits.");
					}
					xmlmap.put("accountNum", accNum);
				}
				for (Iterator iterator = element.elementIterator("CardNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardNum = titleElement.getText().trim();
					if (cardNum.length() == 15) {
						// maskCardNum = cardNum.replace(cardNum.subSequence(4,
						// cardNum.length()-5),maskString1);
						maskCardNum = cardNum.substring(0, 4) + "******"
								+ cardNum.substring(cardNum.length() - 5, cardNum.length());
						logger.info("XmlParser(); Card Number is : " + maskCardNum);

						log.info("XmlParser(); Card Number is : " + maskCardNum);
					} else {
						logger.info("XmlParser(); Card Number is less than 15 digits.");

						log.info("XmlParser(); Card Number is less than 15 digits.");
					}
					xmlmap.put("cardNum", cardNum);
				}
				for (Iterator iterator = element.elementIterator("CardType"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardType = titleElement.getText().trim();
					logger.info("XmlParser(); Card Type is : " + cardType);

					log.info("XmlParser(); Card Type is : " + cardType);
					xmlmap.put("cardType", cardType);
				}
				for (Iterator iterator = element.elementIterator("CardSeq"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardSeq = titleElement.getText().trim();
					logger.info("XmlParser(); Card Sequence is : " + cardSeq);

					log.info("XmlParser(); Card Sequence is : " + cardSeq);
					xmlmap.put("cardSeq", cardSeq);
				}
				for (Iterator iterator = element.elementIterator("UCI"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					uci = titleElement.getText().trim();
					logger.info("XmlParser(); UCI is : " + uci);

					log.info("XmlParser(); UCI is : " + uci);
					xmlmap.put("uci", uci);
				}
				for (Iterator iterator = element.elementIterator("CMTitle"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmtitle = titleElement.getText().trim();
					logger.info("XmlParser(); CM Title is : " + cmtitle);

					log.info("XmlParser(); CM Title is : " + cmtitle);
					xmlmap.put("CMTitle", cmtitle);
				}
				for (Iterator iterator = element.elementIterator("CMFirstName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmfirstname = titleElement.getText().trim();
					logger.info("XmlParser(); CM First Name is : " + cmfirstname);

					log.info("XmlParser(); CM First Name is : " + cmfirstname);
					xmlmap.put("CMFirstName", cmfirstname);
				}
				for (Iterator iterator = element.elementIterator("CMFamilyName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmFamilyName = titleElement.getText().trim();
					logger.info("XmlParser(); CM Family Name is : " + cmFamilyName);

					log.info("XmlParser(); CM Family Name is : " + cmFamilyName);
					xmlmap.put("cmFamilyName", cmFamilyName);
				}
				for (Iterator iterator = element.elementIterator("LegalId"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					legalId = titleElement.getText().trim();
					logger.info("XmlParser(); Legal Id is : " + legalId);

					log.info("XmlParser(); Legal Id is : " + legalId);
					xmlmap.put("legalId", legalId);
				}
				for (Iterator iterator = element.elementIterator("ClientCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					clientCode = titleElement.getText().trim();
					logger.info("XmlParser(); Client Code is : " + clientCode);

					log.info("XmlParser(); Client Code is : " + clientCode);
					xmlmap.put("clientCode", clientCode);
				}

				for (Iterator iterator = element.elementIterator("CMBillingAddress"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmBillingAddress = titleElement.getText().trim();
					logger.info("XmlParser(); CMBilling Address is : " + cmBillingAddress);

					log.info("XmlParser(); CMBilling Address is : " + cmBillingAddress);
					xmlmap.put("cmBillingAddress", cmBillingAddress);
				}
				for (Iterator iterator = element.elementIterator("ClientUnderride"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					clientUnderride = titleElement.getText().trim();
					logger.info("XmlParser(); Client Underride is : " + clientUnderride);

					log.info("XmlParser(); Client Underride is : " + clientUnderride);
					xmlmap.put("clientUnderride", clientUnderride);
				}
				for (Iterator iterator = element.elementIterator("ClientOverride"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					clientOverride = titleElement.getText().trim();
					logger.info("XmlParser(); Client Override is : " + clientOverride);

					log.info("XmlParser(); Client Override is : " + clientOverride);
					xmlmap.put("clientOverride", clientOverride);
				}
				for (Iterator iterator = element.elementIterator("CardActivationFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardActivationFlag = titleElement.getText().trim();
					logger.info("XmlParser(); Card Activation Flag is : " + cardActivationFlag);

					log.info("XmlParser(); Card Activation Flag is : " + cardActivationFlag);
					xmlmap.put("cardActivationFlag", cardActivationFlag);
				}
				for (Iterator iterator = element.elementIterator("CardActivationDate"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardActivationDate = titleElement.getText().trim();
					logger.info("XmlParser(); Card Activation Date is : " + cardActivationDate);

					log.info("XmlParser(); Card Activation Date is : " + cardActivationDate);
					xmlmap.put("cardActivationDate", cardActivationDate);
				}
				for (Iterator iterator = element.elementIterator("CardExpiryDate"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardExpiryDate = titleElement.getText().trim();
					logger.info("XmlParser(); Card ExpiryDate is : " + cardExpiryDate);

					log.info("XmlParser(); Card ExpiryDate is : " + cardExpiryDate);
					xmlmap.put("cardExpiryDate", cardExpiryDate);
				}
				for (Iterator iterator = element.elementIterator("ProductType"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					productType = titleElement.getText().trim();
					logger.info("XmlParser(); Product Type is : " + productType);

					log.info("XmlParser(); Product Type is : " + productType);
					xmlmap.put("productType", productType);
				}
				for (Iterator iterator = element.elementIterator("PINStatus"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					pinStatus = titleElement.getText().trim();
					logger.info("XmlParser(); PIN Status is : " + pinStatus);

					log.info("XmlParser(); PIN Status is : " + pinStatus);
					xmlmap.put("pinStatus", pinStatus);
				}
				for (Iterator iterator = element.elementIterator("CardStatus"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardStatus = titleElement.getText().trim();
					logger.info("XmlParser(); Card Status is : " + cardStatus);

					log.info("XmlParser(); Card Status is : " + cardStatus);
					xmlmap.put("cardStatus", cardStatus);
				}
				for (Iterator iterator = element.elementIterator("ProductName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					productName = titleElement.getText().trim();
					logger.info("XmlParser(); Card Status is : " + productName);

					log.info("XmlParser(); Card Status is : " + productName);
					xmlmap.put("productName", productName);
				}
				for (Iterator iterator = element.elementIterator("EmployeeID"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					employeeID = titleElement.getText().trim();
					logger.info("XmlParser(); Employee ID is : " + employeeID);

					log.info("XmlParser(); Employee ID is : " + employeeID);
					xmlmap.put("employeeID", employeeID);
				}
				for (Iterator iterator = element.elementIterator("RMName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					rmName = titleElement.getText().trim();
					logger.info("XmlParser(); RMName is : " + rmName);

					log.info("XmlParser(); RMName is : " + rmName);
					xmlmap.put("rmName", rmName);
				}
				for (Iterator iterator = element.elementIterator("VIPLevel"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					vipLevel = titleElement.getText().trim();
					logger.info("XmlParser(); VIPLevel is : " + vipLevel);

					log.info("XmlParser(); VIPLevel is : " + vipLevel);
					xmlmap.put("vipLevel", vipLevel);
				}
				for (Iterator iterator = element.elementIterator("StopList"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					stopList = titleElement.getText().trim();
					logger.info("XmlParser(); Stop List is : " + stopList);

					log.info("XmlParser(); Stop List is : " + stopList);
					xmlmap.put("stopList", stopList);
				}
				for (Iterator iterator = element.elementIterator("Transaction"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					transaction = titleElement.getText().trim();
					logger.info("XmlParser(); Transaction is : " + transaction);

					log.info("XmlParser(); Transaction is : " + transaction);
					xmlmap.put("transaction", transaction);
				}
				for (Iterator iterator = element.elementIterator("StatementOption"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					statementoption = titleElement.getText().trim();
					logger.info("XmlParser(); Statement Option is : " + statementoption);

					log.info("XmlParser(); Statement Option is : " + statementoption);
					xmlmap.put("StatementOption", statementoption);
				}
				for (Iterator iterator = element.elementIterator("AccountStatus"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					accountstatus = titleElement.getText().trim();
					logger.info("XmlParser(); Account Status is : " + accountstatus);

					log.info("XmlParser(); Account Status is : " + accountstatus);
					xmlmap.put("AccountStatus", accountstatus);
				}
				for (Iterator iterator = element.elementIterator("TotalCashLimit"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					totalcashlimit = titleElement.getText().trim();
					logger.info("XmlParser(); Total CashLimit is : " + totalcashlimit);

					log.info("XmlParser(); Total CashLimit is : " + totalcashlimit);
					xmlmap.put("TotalCashLimit", totalcashlimit);
				}
				for (Iterator iterator = element.elementIterator("TotalMinimumDue"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					totalminimumdue = titleElement.getText().trim();
					logger.info("XmlParser(); Total MinimumDue is : " + totalminimumdue);

					log.info("XmlParser(); Total MinimumDue is : " + totalminimumdue);
					xmlmap.put("TotalMinimumDue", totalminimumdue);
				}
				for (Iterator iterator = element.elementIterator("LastPaymentAmount"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					lastpaymentamount = titleElement.getText().trim();
					logger.info("XmlParser(); Last PaymentAmount is : " + lastpaymentamount);

					log.info("XmlParser(); Last PaymentAmount is : " + lastpaymentamount);
					xmlmap.put("LastPaymentAmount", lastpaymentamount);
				}
				for (Iterator iterator = element.elementIterator("TotalSpendExposure"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					totalspendexposure = titleElement.getText().trim();
					logger.info("XmlParser(); Total Spend Exposure is : " + totalspendexposure);

					log.info("XmlParser(); Total Spend Exposure is : " + totalspendexposure);
					xmlmap.put("TotalSpendExposure", totalspendexposure);
				}
				for (Iterator iterator = element.elementIterator("AccountParOverride"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					accountparoverride = titleElement.getText().trim();
					logger.info("XmlParser(); Account ParOverride is : " + accountparoverride);

					log.info("XmlParser(); Account ParOverride is : " + accountparoverride);
					xmlmap.put("AccountParOverride", accountparoverride);
				}
				for (Iterator iterator = element.elementIterator("MasterLimit"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					masterlimit = titleElement.getText().trim();
					logger.info("XmlParser(); Master Limit is : " + masterlimit);

					log.info("XmlParser(); Master Limit is : " + masterlimit);
					xmlmap.put("MasterLimit", masterlimit);
				}
				for (Iterator iterator = element.elementIterator("BasicControlNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					basiccontrolnumber = titleElement.getText().trim();
					logger.info("XmlParser(); Basic Control Number is : " + basiccontrolnumber);

					log.info("XmlParser(); Basic Control Number is : " + basiccontrolnumber);
					xmlmap.put("BasicControlNumber", basiccontrolnumber);
				}
				for (Iterator iterator = element.elementIterator("BasicControlName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					basiccontrolname = titleElement.getText().trim();
					logger.info("XmlParser(); Basic Control Name is : " + basiccontrolname);

					log.info("XmlParser(); Basic Control Name is : " + basiccontrolname);
					xmlmap.put("BasicControlName", basiccontrolname);
				}
				for (Iterator iterator = element.elementIterator("AvailableCredit"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					availablecredit = titleElement.getText().trim();
					logger.info("XmlParser(); Available Credit is : " + availablecredit);

					log.info("XmlParser(); Available Credit is : " + availablecredit);
					xmlmap.put("AvailableCredit", availablecredit);
				}
				for (Iterator iterator = element.elementIterator("AvailableCash"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					availablecash = titleElement.getText().trim();
					logger.info("XmlParser(); Available Cash is : " + availablecash);

					log.info("XmlParser(); Available Cash is : " + availablecash);
					xmlmap.put("AvailableCash", availablecash);
				}
				for (Iterator iterator = element.elementIterator("DaysDelinquent"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					daysdelinquent = titleElement.getText().trim();
					logger.info("XmlParser(); Days Delinquent is : " + daysdelinquent);

					log.info("XmlParser(); Days Delinquent is : " + daysdelinquent);
					xmlmap.put("DaysDelinquent", daysdelinquent);
				}
				for (Iterator iterator = element.elementIterator("TotalBilledBalance"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					totalbilledbalance = titleElement.getText().trim();
					logger.info("XmlParser(); Total Billed Balance is : " + totalbilledbalance);

					log.info("XmlParser(); Total Billed Balance is : " + totalbilledbalance);
					xmlmap.put("TotalBilledBalance", totalbilledbalance);
				}
				for (Iterator iterator = element.elementIterator("PARAccountUnderride"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					paraccountunderride = titleElement.getText().trim();
					logger.info("XmlParser(); PARAccount Underride is : " + paraccountunderride);

					log.info("XmlParser(); PARAccount Underride is : " + paraccountunderride);
					xmlmap.put("PARAccountUnderride", paraccountunderride);
				}
				for (Iterator iterator = element.elementIterator("MasterExposure"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					masterexposure = titleElement.getText().trim();
					logger.info("XmlParser(); Master Exposure is : " + masterexposure);

					log.info("XmlParser(); Master Exposure is : " + masterexposure);
					xmlmap.put("MasterExposure", masterexposure);
				}
				for (Iterator iterator = element.elementIterator("Currency"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					currency = titleElement.getText().trim();
					logger.info("XmlParser(); Currency is : " + currency);

					log.info("XmlParser(); Currency is : " + currency);
					xmlmap.put("Currency", currency);
				}
				for (Iterator iterator = element.elementIterator("ExpressCashFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					expresscashflag = titleElement.getText().trim();
					logger.info("XmlParser(); Express Cash Flag is : " + expresscashflag);

					log.info("XmlParser(); Express Cash Flag is : " + expresscashflag);
					xmlmap.put("ExpressCashFlag", expresscashflag);
				}
				for (Iterator iterator = element.elementIterator("DirectDebitFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					directdebitflag = titleElement.getText().trim();
					logger.info("XmlParser(); Direct Debit Flag is : " + directdebitflag);

					log.info("XmlParser(); Direct Debit Flag is : " + directdebitflag);
					xmlmap.put("DirectDebitFlag", directdebitflag);
				}
				for (Iterator iterator = element.elementIterator("CaseNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					casenumber = titleElement.getText().trim();
					logger.info("XmlParser(); Case Number is : " + casenumber);

					log.info("XmlParser(); Case Number is : " + casenumber);
					xmlmap.put("CaseNumber", casenumber);
				}
				for (Iterator iterator = element.elementIterator("CMDateOfBirth"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmdateofbirth = titleElement.getText().trim();
					logger.info("XmlParser(); CM Date Of Birth is : " + cmdateofbirth);

					log.info("XmlParser(); CM Date Of Birth is : " + cmdateofbirth);
					xmlmap.put("CMDateOfBirth", cmdateofbirth);
				}
				for (Iterator iterator = element.elementIterator("CustomerEmail"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					customeremail = titleElement.getText().trim();
					logger.info("XmlParser(); Customer Email is : " + customeremail);

					log.info("XmlParser(); Customer Email is : " + customeremail);
					xmlmap.put("CustomerEmail", customeremail);
				}
				for (Iterator iterator = element.elementIterator("CustomerMobile"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					customermobile = titleElement.getText().trim();
					logger.info("XmlParser(); Customer Mobile is : " + customermobile);

					log.info("XmlParser(); Customer Mobile is : " + customermobile);
					xmlmap.put("CustomerMobile", customermobile);
				}
				for (Iterator iterator = element.elementIterator("CMBranchCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmbranchcode = titleElement.getText().trim();
					logger.info("XmlParser(); CM Branch Code is : " + cmbranchcode);

					log.info("XmlParser(); CM Branch Code is : " + cmbranchcode);
					xmlmap.put("CMBranchCode", cmbranchcode);
				}
				for (Iterator iterator = element.elementIterator("FlasherMemo1"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					flashermemo1 = titleElement.getText().trim();
					logger.info("XmlParser(); Flasher Memo1 is : " + flashermemo1);
					log.info("XmlParser(); Flasher Memo1 is : " + flashermemo1);
					xmlmap.put("FlasherMemo1", flashermemo1);
				}
				for (Iterator iterator = element.elementIterator("FlasherMemo2"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					flashermemo2 = titleElement.getText().trim();
					logger.info("XmlParser(); Flasher Memo2 is : " + flashermemo2);

					log.info("XmlParser(); Flasher Memo2 is : " + flashermemo2);
					xmlmap.put("FlasherMemo2", flashermemo2);
				}
				for (Iterator iterator = element.elementIterator("PrimSuppFlag"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					primSupplFlag = titleElement.getText().trim();
					logger.info("XmlParser(); PrimSupp Flag Option is : " + primSupplFlag);

					log.info("XmlParser(); PrimSupp Flag Option is : " + primSupplFlag);
					xmlmap.put("PrimSuppFlag", primSupplFlag);
				}
				for (Iterator iterator = element.elementIterator("LegalID"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					legalId = titleElement.getText().trim();
					logger.info("XmlParser(); Legal Id is : " + legalId);

					log.info("XmlParser(); Legal Id is : " + legalId);
					xmlmap.put("LegalID", legalId);
				}
				for (Iterator iterator = element.elementIterator("ProductCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					prodCodeStr = titleElement.getText().trim();
					logger.info("XmlParser(); Product code is : " + prodCodeStr);

					log.info("XmlParser(); Product code is : " + prodCodeStr);
					xmlmap.put("ProductCode", prodCodeStr);
				}
			}
			Iterator iter2 = list2.iterator();
			logger.info("XmlParser(); Node is : //Message_Res/CardInfo");

			log.info("XmlParser(); Node is : //Message_Res/CardInfo");
			while (iter2.hasNext()) {
				Element element = (Element) iter2.next();
				cnumber = element.valueOf("@cnumber");
				if (cnumber.length() == 15) {
					// maskCardNum = cnumber.replace(cnumber.subSequence(4,
					// cnumber.length()-5),maskString1);
					maskCardNum = cnumber.substring(0, 4) + "******"
							+ cnumber.substring(cnumber.length() - 5, cnumber.length());
					logger.info("XmlParser(); Card Number is : " + maskCardNum);

					log.info("XmlParser(); Card Number is : " + maskCardNum);
				} else {
					logger.info("XmlParser(); Card Number is less than 15 digits.");

					log.info("XmlParser(); Card Number is less than 15 digits.");
				}
				xmlmap.put("cnumber", cnumber);

				if (cnumber.equalsIgnoreCase(cardNumber)) {

					/*
					 * for(Iterator iterator = element.elementIterator("@cnumber");
					 * iterator.hasNext();) { Element titleElement = (Element)iterator.next();
					 * cnumber = titleElement.getText().trim();
					 * log.info("XmlParser(); Card Number is : " + cnumber ); xmlmap.put("cnumber",
					 * cnumber); }
					 */
					for (Iterator iterator = element.elementIterator("CurrencyName"); iterator.hasNext();) {
						Element titleElement = (Element) iterator.next();
						currencyName = titleElement.getText().trim();
						logger.info("XmlParser(); CurrencyName is : " + currencyName);

						log.info("XmlParser(); CurrencyName is : " + currencyName);
						xmlmap.put("currencyName", currencyName);
					}
					for (Iterator iterator = element.elementIterator("CurrencySymbol"); iterator.hasNext();) {
						Element titleElement = (Element) iterator.next();
						currencySym = titleElement.getText().trim();
						logger.info("XmlParser(); CurrencySymbol is : " + currencySym);

						log.info("XmlParser(); CurrencySymbol is : " + currencySym);
						xmlmap.put("currencySymbol", currencySym);
					}
					for (Iterator iterator = element.elementIterator("PrimSupplFlag"); iterator.hasNext();) {
						Element titleElement = (Element) iterator.next();
						primSuppFlag = titleElement.getText().trim();
						logger.info("XmlParser(); Primary Supply Flag is : " + primSuppFlag);

						log.info("XmlParser(); Primary Supply Flag is : " + primSuppFlag);
						xmlmap.put("primSuppFlag", primSuppFlag);
					}
				} else {
					logger.info("XmlParser(); Ignoring this card Number for fetching the details.");

					log.info("XmlParser(); Ignoring this card Number for fetching the details.");
				}
			}
			Iterator iter3 = list3.iterator();
			logger.info("XmlParser(); Node is : //EAIBody");
			log.info("XmlParser(); Node is : //EAIBody");
			while (iter3.hasNext()) {
				Element element = (Element) iter3.next();
				for (Iterator iterator = element.elementIterator("ErrorDescription"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					errDes = titleElement.getText().trim();
					logger.info("XmlParser(); ErrorDescription is : " + errDes);

					log.info("XmlParser(); ErrorDescription is : " + errDes);
					xmlmap.put("errDes", errDes);
				}
			}
			Iterator iter4 = list4.iterator();
			logger.info("XmlParser(); Node is : //EAIHeader");

			log.info("XmlParser(); Node is : //EAIHeader");
			while (iter4.hasNext()) {
				Element element = (Element) iter4.next();

				for (Iterator iterator = element.elementIterator("MessageID"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					msgId = titleElement.getText().trim();
					logger.info("XmlParser(); Message Id is : " + msgId);

					log.info("XmlParser(); Message Id is : " + msgId);
					xmlmap.put("msgId", msgId);
				}
				for (Iterator iterator = element.elementIterator("Description"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					description = titleElement.getText().trim();
					logger.info("XmlParser(); Description is : " + description);

					log.info("XmlParser(); Description is : " + description);
					xmlmap.put("description", description);
				}
			}
			// This part is added for messages 3009/3010 and 3021/3022
			/*
			 * Iterator iter5=list.iterator();
			 * log.info("XmlParser(); Node is : //Message_Res/List"); while(iter5.hasNext())
			 * { Element element = (Element)iter5.next();
			 * 
			 * for(Iterator iterator = element.elementIterator("Date"); iterator.hasNext();)
			 * { Element titleElement = (Element)iterator.next(); date1 =
			 * titleElement.getText().trim(); log.info("XmlParser(); Date is : " + date1 );
			 * xmlmap.put("date1", date1); } for(Iterator iterator =
			 * element.elementIterator("Amount"); iterator.hasNext();) { Element
			 * titleElement = (Element)iterator.next(); amount =
			 * titleElement.getText().trim(); log.info("XmlParser(); Amount is : " + amount
			 * ); xmlmap.put("amount", amount); } for(Iterator iterator =
			 * element.elementIterator("Description"); iterator.hasNext();) { Element
			 * titleElement = (Element)iterator.next(); desc =
			 * titleElement.getText().trim(); log.info("XmlParser(); Description is : " +
			 * desc); xmlmap.put("desc", desc); } for(Iterator iterator =
			 * element.elementIterator("ForeignCurAmount"); iterator.hasNext();) { Element
			 * titleElement = (Element)iterator.next(); description =
			 * titleElement.getText().trim(); log.info("XmlParser(); Description is : " +
			 * description ); xmlmap.put("description", description); } for(Iterator
			 * iterator = element.elementIterator("ForeignCurCode"); iterator.hasNext();) {
			 * Element titleElement = (Element)iterator.next(); msgId =
			 * titleElement.getText().trim(); log.info("XmlParser(); Message Id is : " +
			 * msgId ); xmlmap.put("msgId", msgId); } for(Iterator iterator =
			 * element.elementIterator("CardNumber"); iterator.hasNext();) { Element
			 * titleElement = (Element)iterator.next(); description =
			 * titleElement.getText().trim(); log.info("XmlParser(); Description is : " +
			 * description ); xmlmap.put("description", description); } for(Iterator
			 * iterator = element.elementIterator("UnbilledFlag"); iterator.hasNext();) {
			 * Element titleElement = (Element)iterator.next(); msgId =
			 * titleElement.getText().trim(); log.info("XmlParser(); Message Id is : " +
			 * msgId ); xmlmap.put("msgId", msgId); } for(Iterator iterator =
			 * element.elementIterator("TransactionType"); iterator.hasNext();) { Element
			 * titleElement = (Element)iterator.next(); description =
			 * titleElement.getText().trim(); log.info("XmlParser(); Description is : " +
			 * description ); xmlmap.put("description", description); }
			 * log.info("*******************************" ); }
			 */

		} catch (DocumentException e) {
			logger.error((new StringBuilder("CardNumberValidationParser(); Document Exception is raised. Reason :"))
					.append(e.getMessage()).toString());
			log.severe((new StringBuilder("CardNumberValidationParser(); Document Exception is raised. Reason :"))
					.append(e.getMessage()).toString());
		}
		return xmlmap;
	}
}
package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class ContDetails 
{
	public String AccountNum = emptyStr;
	public String Org = emptyStr;
	public String Logo = emptyStr;
	public String CurrencyName = emptyStr;
	public String PrimSupplFlag = emptyStr;	
	public String Title = emptyStr;
	public String Name1 = emptyStr;
	public String StatementAddress1 = emptyStr;
	public String DateOfBirth = emptyStr;
	public String HomeNO = emptyStr;
	public String HomeCountrySel = emptyStr;
	public String MobileNO = emptyStr;
	public String MobileNOCountySel = emptyStr;
	public String EmailID = emptyStr;
	public String Memo1 = emptyStr;
	public String Memo2 = emptyStr;
	public String WorkNO = emptyStr;
	public String WorkNoCountrySel = emptyStr;
	public String SMSFlag = emptyStr;
	public String eStatementFlag = emptyStr;
	public String productCode = emptyStr;
	public String OTB = emptyStr;
	public String BranchCode = emptyStr;
	public String maskAccNum = emptyStr;
	//CR July 2016. - Geomant
	public String powercardID = emptyStr;
	
	public String toString ()
	{
		//maskAccNum = AccountNum.replace(AccountNum.subSequence(4, AccountNum.length()-5),maskString1);
		if (!(AccountNum.equalsIgnoreCase(emptyStr)))
		 maskAccNum=AccountNum.substring(0,4)+"******"+AccountNum.substring(AccountNum.length()-5,AccountNum.length());
		String returnStr = emptyStr;
			returnStr = newLine +
			resAccNum + maskAccNum + newLine +
			resOrg + Org + newLine +
			resLogo + Logo + newLine +
			resCurrencyName + CurrencyName + newLine +
			resPrimarySuppFlag + PrimSupplFlag + newLine +
			resTitle + Title + newLine +
			resName + Name1 + newLine +
			resStatementAddr1 + StatementAddress1 + newLine +
			resDOB + DateOfBirth + newLine +
			resHomePhone + HomeNO + newLine +
			resHomeCountrySel + HomeCountrySel     + newLine +
			resMobilePhone + MobileNO    + newLine +
			resMobileCountrySel + MobileNOCountySel   + newLine +
			resEmail + EmailID + newLine +
			resMemo1 + Memo1 + newLine +
			resMemo2 + Memo2 + newLine +
			resWorkPhone + WorkNO + newLine +
			resWorkCountrySel + WorkNoCountrySel + newLine +
			resSMSFlag + SMSFlag + newLine +
			resEStatementFlag + eStatementFlag + newLine +	
			resProductCode + productCode + newLine +	
			resOTB+ OTB + newLine +
			resBranchCode + BranchCode + newLine +
			resPowercardID + powercardID + newLine;
		return returnStr;
	}
}
package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class AdditionalCardInfo

{

	public String PassportNumber = emptyStr;	
	public String CPRID = emptyStr;
	public String BankName = emptyStr;
	public String BankBranch = emptyStr;
	public String BankAccountNumber = emptyStr;
	public String DateOfBirth = emptyStr;
	public String Nationality = emptyStr;
	public String Income = emptyStr;
	public String XRef1 = emptyStr;	
	public String XRef2 = emptyStr;
	public String MemberSince = emptyStr;
	public String HomeAddress1 = emptyStr;
	public String HomeAddress2 = emptyStr;
	public String HomeAddress3 = emptyStr;
	public String HomePhoneArea = emptyStr;
	public String HomePhone = emptyStr;
	public String MobilePhone = emptyStr;
	public String HomeEmail = emptyStr;
	public String PreviousAddress1 = emptyStr;
	public String PreviousAddress2 = emptyStr;
	public String PreviousAddress3 = emptyStr;
	public String StatementAddress1 = emptyStr;
	public String StatementAddress2 = emptyStr;
	public String StatementAddress3 = emptyStr;
	public String EmployerName = emptyStr;
	public String EmployerAddress1 = emptyStr;
	public String EmployerAddress2 = emptyStr;
	public String EmployerAddress3 = emptyStr;
	public String EmployerPhoneArea = emptyStr;
	public String EmployerPhone = emptyStr;
	public String EmployerFax = emptyStr;
	public String EmployerMail = emptyStr;
	public String toString()
	{
		String returnStr = emptyStr;		
			returnStr = newLine +
			resPassNum + PassportNumber + newLine +			
			resCPRID + CPRID    + newLine +
			resBankName + BankName         + newLine +
			resBankBranch + BankBranch  + newLine +
			resBankAccNumber  + BankAccountNumber   + newLine +
			resDOB + DateOfBirth       + newLine +
			resNationality + Nationality    + newLine +
			resIncome + Income               + newLine +
			resXRef1 + XRef1     + newLine +			
			resXRef2 + XRef2            + newLine +
			resMemberSince + MemberSince          + newLine +
			resHomeAddr1 + HomeAddress1     + newLine +
			resHomeAddr2 + HomeAddress2      + newLine +
			resHomeAddr3 + HomeAddress3        + newLine +
			resHomePhArea  + HomePhoneArea          + newLine +
			resHomePhone + HomePhone + newLine +
			resMobilePhone + MobilePhone + newLine +
			resHomeEmail + HomeEmail + newLine +
			resPrevAddr1 + PreviousAddress1 + newLine +
			resPrevAddr2 + PreviousAddress2 + newLine +
			resPrevAddr3 + PreviousAddress3 + newLine +
			resStatementAddr1 + StatementAddress1 + newLine +
			resStatementAddr2 + StatementAddress2 + newLine +
			resStatementAddr3 + StatementAddress3 + newLine  +
			resEmpName+ EmployerName + newLine  +
			resEmpAddr1 + EmployerAddress1 + newLine  +
			resEmpAddr2 + EmployerAddress2 + newLine  +
			resEmpAddr3 + EmployerAddress3 + newLine  +
			resEmpPhArea + EmployerPhoneArea + newLine  +
			resEmpPhone + EmployerPhone + newLine  +
			resEmpFax + EmployerFax + newLine  +			
			resEmpMail + EmployerMail + newLine ;
		return returnStr;
	}
}
	
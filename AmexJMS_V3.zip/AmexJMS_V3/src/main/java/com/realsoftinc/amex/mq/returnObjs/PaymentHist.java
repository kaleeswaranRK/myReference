package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class PaymentHist 
{
	public String AmountLastPayment = emptyStr;
	public String DateLastPayment = emptyStr;
	public String DelqTPD = emptyStr;
	public String DelqXdayNumber = emptyStr;
	public String DelqXdayAmount = emptyStr;
	
	public String toString()
	{
		String returnStr =emptyStr;
		returnStr = newLine +
			resAmountLastPayment + AmountLastPayment   +newLine +
			resDateLastPayment + DateLastPayment     +newLine +
			resDelqTPD + DelqTPD             +newLine +
			resDelqXdayNumber + DelqXdayNumber      +newLine +
			resDelqXdayAmount + DelqXdayAmount      +newLine ;
			return returnStr;
	}
}

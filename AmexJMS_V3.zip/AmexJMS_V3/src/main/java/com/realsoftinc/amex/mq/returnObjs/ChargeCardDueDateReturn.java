package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class ChargeCardDueDateReturn 
{
	public String errorCode = 	emptyStr;
	public String status    = 	emptyStr;
	public String dueDate	=	emptyStr;
	
	public String toString()
	{
		String returnStr = newLine + 
				resErrorCode    + errorCode + newLine +
				resStatus       + status    + newLine + 
				resDueDate      + dueDate   + newLine ;
		return returnStr;
	}
}

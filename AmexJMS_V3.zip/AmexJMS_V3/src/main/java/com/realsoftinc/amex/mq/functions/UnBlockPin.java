/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.functions;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.EmbosserDetailReturn;
import com.realsoftinc.amex.mq.returnObjs.UnBlockPinReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

/**
 * This class is responsible for having the main business logic for UnBlockPin
 * Function
 * 
 * @author Purvi Lad / Real Soft (Intl) Pvt. Ltd.
 * @version $Revision: 1.7 $ $Date: 2010/07/12 10:40:55 $
 */

public class UnBlockPin {

	Logger log = Utility.getLogger();
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(UnBlockPin.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public UnBlockPinReturn unBlockPin(String cardNum) {
		logger.info("unBlockPin(); Unblock Pin function is called by IVR .. ");
		logger.info("unBlockPin(); Enter ");

		log.info("unBlockPin(); Unblock Pin function is called by IVR .. ");
		log.info("unBlockPin(); Enter ");

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		MQCommon mqc = null;
		UnBlockPinReturn unblckPinRtn = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;
		EmbosserDetail embDtl = null;
		EmbosserDetailReturn embDtlRtn = null;

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		// String sso = emptyStr;
		String embErrorCode = emptyStr;
//		@SuppressWarnings("unused")
		String embErrorDesc = emptyStr;
		String embExpiryDate = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String msgId = emptyStr;
		String errCode = emptyStr;
		String errorDescription = emptyStr;
		String status = emptyStr;
		String maskCardNum = emptyStr;
		String expMonth = emptyStr;
		String expYear = emptyStr;

		try {
			mqc = new MQCommon();
			unblckPinRtn = new UnBlockPinReturn();
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			respParser = new ResponseParser();
			embDtl = new EmbosserDetail();
			embDtlRtn = new EmbosserDetailReturn();

			/*
			 * sso = MQCommon.SSO; if(sso == null) { log.info("unBlockPin(); sso is null");
			 * log.info("unBlockPin(); Calling getSSO() function .. "); sso = mqc.getSSO();
			 * } else if(sso.equalsIgnoreCase(emptyStr)) {
			 * log.info("unBlockPin(); sso is empty string");
			 * log.info("unBlockPin(); Calling getSSO() function .. "); sso = mqc.getSSO();
			 * }
			 */

			if (cardNum.length() == 15) {
				// maskCardNum = cardNum.replace(cardNum.subSequence(4,
				// cardNum.length()-5),maskString1);
				maskCardNum = cardNum.substring(0, 4) + "******"
						+ cardNum.substring(cardNum.length() - 5, cardNum.length());
				logger.info("unBlockPin(); Card Number is : " + maskCardNum);

				log.info("unBlockPin(); Card Number is : " + maskCardNum);
			} else {
				logger.info("unBlockPin(); Card Number is less than 15 digits.");

				log.info("unBlockPin(); Card Number is less than 15 digits.");
			}

			embDtlRtn = embDtl.getEmbosserDetail(cardNum);
			embErrorCode = embDtlRtn.ErrorCode;
			embErrorDesc = embDtlRtn.ErrorDescription;
			embExpiryDate = embDtlRtn.cardExpiryDate;
			logger.info("unBlockPin(); Swapping the embosser expiry month and year .. ");

			log.info("unBlockPin(); Swapping the embosser expiry month and year .. ");
			StringBuffer expDate = new StringBuffer();
			StringBuffer expSwapDate = new StringBuffer();
			if (embExpiryDate.length() == 3) {
				logger.info(
						"unBlockPin(); Expiry date received from embosser is of 3 digits." + "Adding 0 as the prefix.");

				log.info(
						"unBlockPin(); Expiry date received from embosser is of 3 digits." + "Adding 0 as the prefix.");
				expDate = expDate.append("0").append(embExpiryDate);
				expMonth = expDate.substring(0, 2);
				expYear = expDate.substring(2, 4);
				expSwapDate = expSwapDate.append(expYear).append(expMonth);
				logger.info("unBlockPin(); New swapped embosser expiry date is : " + expSwapDate.toString());

				log.info("unBlockPin(); New swapped embosser expiry date is : " + expSwapDate.toString());
			} else if (embExpiryDate.length() == 4) {
				logger.info("unBlockPin(); Expiry date received from embosser is of 4 digits.");

				log.info("unBlockPin(); Expiry date received from embosser is of 4 digits.");
				expDate = expDate.append(embExpiryDate);
				expMonth = expDate.substring(0, 2);
				expYear = expDate.substring(2, 4);
				expSwapDate = expSwapDate.append(expYear).append(expMonth);
				logger.info("unBlockPin(); New swapped embosser expiry date is : " + expSwapDate.toString());

				log.info("unBlockPin(); New swapped embosser expiry date is : " + expSwapDate.toString());
			} else {
				logger.info("unBlockPin(); Expiry date received from embosser is invalid.Length not proper. Length is :"
						+ embExpiryDate.length());

				log.info("unBlockPin(); Expiry date received from embosser is invalid.Length not proper. Length is :"
						+ embExpiryDate.length());
				expSwapDate = expSwapDate.append(embExpiryDate);
				logger.info("unBlockPin(); Sending expiry date as received from embosser. Expiry date is : "
						+ expSwapDate.toString());

				log.info("unBlockPin(); Sending expiry date as received from embosser. Expiry date is : "
						+ expSwapDate.toString());
			}

			if (embErrorCode.equalsIgnoreCase("0") || embErrorCode.equalsIgnoreCase("00")
					|| embErrorCode.equalsIgnoreCase("000") || embErrorCode.equalsIgnoreCase("0000")) {
				logger.info("unBlockPin(); Calling the getDateTime function ..");

				log.info("unBlockPin(); Calling the getDateTime function ..");
				dateTimeStampInStr = mqc.getDateTime();
				logger.info("unBlockPin(); DateTimeStamp is : " + dateTimeStampInStr);

				logger.info("unBlockPin(); Calling the getAuditSequence function ..");
				log.info("unBlockPin(); DateTimeStamp is : " + dateTimeStampInStr);

				log.info("unBlockPin(); Calling the getAuditSequence function ..");
				auditSeqInStr = mqc.getAuditSequence();
				logger.info("unBlockPin(); Audit Sequence is : " + auditSeqInStr);

				logger.info("unBlockPin(); Created all the required parameters to prepare the xml ..");
				log.info("unBlockPin(); Audit Sequence is : " + auditSeqInStr);

				log.info("unBlockPin(); Created all the required parameters to prepare the xml ..");
				xmlMap.put("MessageLength", mqc.getproperties("UnBlockPin.MsgLength"));
				xmlMap.put("MessageId", MsgId_UnblockPin);
				xmlMap.put("Description", "Pin Change");
				xmlMap.put("AuditSeq", auditSeqInStr);
				xmlMap.put("DateTimeStamp", dateTimeStampInStr);
				xmlMap.put("CardNumber", cardNum);
				xmlMap.put("CardExpiryDate", expSwapDate.toString());
				xmlMap.put("SSO", mqc.getproperties("UnBlockPin.SSO"));
				xmlMap.put("RackFlag", mqc.getproperties("UnBlockPin.RackFlag"));
				xmlMap.put("username", mqc.getproperties("UnBlockPin.UserName"));
				xmlMap.put("password", mqc.getproperties("UnBlockPin.Password"));
				logger.info("unBlockPin(); Sending values to form proper form of xml request .. ");

				log.info("unBlockPin(); Sending values to form proper form of xml request .. ");
				xmlReq = rc.XmlRequest(xmlMap, "PinUnblock");
				logger.info("unBlockPin(); Received xml in proper format ..");

				log.info("unBlockPin(); Received xml in proper format ..");
				// log.info("unBlockPin(); XML is : " + xmlReq);
				// Added to encrypt account number when display request in log file
				MQCommon.maskCardNumber("unBlockPin(); XML is : ", xmlReq);
				logger.info("unBlockPin(); Sending this xml as the request to MQ ..");

				log.info("unBlockPin(); Sending this xml as the request to MQ ..");
				replyMsg = rr.MessageSender(xmlReq);
				logger.info("unBlockPin(); Response received from MQ .. ");
				logger.info("unBlockPin(); Received response from MQ is : " + replyMsg);

				log.info("unBlockPin(); Response received from MQ .. ");
				log.info("unBlockPin(); Received response from MQ is : " + replyMsg);

				if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
					logger.info("unBlockPin(); Sending the received response from MQ to the parser ..");
					logger.info("unBlockPin(); XML sent for parsing is :" + replyMsg);
					log.info("unBlockPin(); Sending the received response from MQ to the parser ..");
					log.info("unBlockPin(); XML sent for parsing is :" + replyMsg);
					map = respParser.XmlParser(replyMsg);
					logger.info("unBlockPin(); Received Hash map after parsing of response.");

					log.info("unBlockPin(); Received Hash map after parsing of response.");

					errCode = (String) map.get("errCode");
					errorDescription = (String) map.get("errDes");
					if (errCode.equalsIgnoreCase("0") || errCode.equalsIgnoreCase("00")
							|| errCode.equalsIgnoreCase("000") || errCode.equalsIgnoreCase("0000")) {
						logger.info("unBlockPin(); Response from MQ is 'SUCCESS'.. ");

						log.info("unBlockPin(); Response from MQ is 'SUCCESS'.. ");
						msgId = (String) map.get("msgIdActualStr");
						status = validStr;
					} else {
						logger.info("unBlockPin(); Response from MQ is 'FAILURE'.. ");

						log.info("unBlockPin(); Response from MQ is 'FAILURE'.. ");
						status = invalidStr;
					}
					if (MsgId_UnblockPinResp.equalsIgnoreCase(msgId)) {
						logger.info("unBlockPin(); Getting valid msg id from the response.");

						log.info("unBlockPin(); Getting valid msg id from the response.");
					} else {
						logger.info("unBlockPin(); Since the response from MQ is not proper .. ");
						logger.info("unBlockPin(); Setting error values.");
						log.info("unBlockPin(); Since the response from MQ is not proper .. ");
						log.info("unBlockPin(); Setting error values.");
						errCode = errorCode;
						errorDescription = errorDesc;
					}
				} else {
					logger.info("unBlockPin(); Response received from MQ is not proper.");
					logger.info("unBlockPin(); Setting error values.");
					log.info("unBlockPin(); Response received from MQ is not proper.");
					log.info("unBlockPin(); Setting error values.");
					errCode = errorCode;
					errorDescription = errorDesc;
				}
			} else {
				logger.info("unBlockPin(); Setting error values.");

				log.info("unBlockPin(); Setting error values.");
				errCode = errorCode;
				errorDescription = errorDesc;
			}

			unblckPinRtn.errorCode = errCode;
			unblckPinRtn.errorDesc = errorDescription;
			unblckPinRtn.status = status;
		} catch (Exception e) {
			logger.info("unBlockPin(); Excception is raised." + e.toString());

			log.info("unBlockPin(); Excception is raised." + e.toString());
			errCode = errorCode;
			errorDescription = errorDesc;
			logger.error("unBlockPin(); Reason : " + e.getStackTrace());

			log.severe("unBlockPin(); Reason : " + e.getStackTrace());
		} finally {
			xmlMap = null;
			map = null;
			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			embDtl = null;
			embDtlRtn = null;

			xmlReq = emptyStr;
			replyMsg = emptyStr;
			// sso = emptyStr;
			embErrorCode = emptyStr;
			embErrorDesc = emptyStr;
			embExpiryDate = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			msgId = emptyStr;
			errCode = emptyStr;
			errorDescription = emptyStr;
			status = emptyStr;
			maskCardNum = emptyStr;
		}
		logger.info("unBlockPin(); Response is returned to the IVR. Response : " + unblckPinRtn.toString());
		logger.info("unBlockPin(); Exit");
		log.info("unBlockPin(); Response is returned to the IVR. Response : " + unblckPinRtn.toString());
		log.info("unBlockPin(); Exit");
		return unblckPinRtn;
	}

}

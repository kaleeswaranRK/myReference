package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class DoBValidationReturn 
{
	public String errorCode = emptyStr;
	public String errorDescription = emptyStr;
	public String status = emptyStr;	
	public AdditionalCardInfo addInfo= null;
	
	public String toString()
	{
		String returnStr = emptyStr;
		if(addInfo != null)
		{
			returnStr = newLine +
			resErrorCode + errorCode + newLine +
			resErrorDesc + errorDescription + newLine +
			resStatus + status + newLine +
			resPassNum + addInfo.PassportNumber + newLine +			
			resCPRID + addInfo.CPRID    + newLine +
			resBankName + addInfo.BankName         + newLine +
			resBankBranch + addInfo.BankBranch  + newLine +
			resBankAccNumber  + addInfo.BankAccountNumber   + newLine +
			resDOB + addInfo.DateOfBirth       + newLine +
			resNationality + addInfo.Nationality    + newLine +
			resIncome + addInfo.Income               + newLine +
			resXRef1 + addInfo.XRef1     + newLine +			
			resXRef2 + addInfo.XRef2            + newLine +
			resMemberSince + addInfo.MemberSince          + newLine +
			resHomeAddr1 + addInfo.HomeAddress1     + newLine +
			resHomeAddr2 + addInfo.HomeAddress2      + newLine +
			resHomeAddr3 + addInfo.HomeAddress3        + newLine +
			resHomePhArea  + addInfo.HomePhoneArea          + newLine +
			resHomePhone + addInfo.HomePhone + newLine +
			resMobilePhone + addInfo.MobilePhone + newLine +
			resHomeEmail + addInfo.HomeEmail + newLine +
			resPrevAddr1 + addInfo.PreviousAddress1 + newLine +
			resPrevAddr2 + addInfo.PreviousAddress2 + newLine +
			resPrevAddr3 + addInfo.PreviousAddress3 + newLine +
			resStatementAddr1 + addInfo.StatementAddress1 + newLine +
			resStatementAddr2 + addInfo.StatementAddress2 + newLine +
			resStatementAddr3 + addInfo.StatementAddress3 + newLine  +
			resEmpName+ addInfo.EmployerName + newLine  +
			resEmpAddr1 + addInfo.EmployerAddress1 + newLine  +
			resEmpAddr2 + addInfo.EmployerAddress2 + newLine  +
			resEmpAddr3 + addInfo.EmployerAddress3 + newLine  +
			resEmpPhArea + addInfo.EmployerPhoneArea + newLine  +
			resEmpPhone + addInfo.EmployerPhone + newLine  +
			resEmpFax + addInfo.EmployerFax + newLine  +			
			resEmpMail + addInfo.EmployerMail + newLine ;
		}
		else
		{
			returnStr = newLine +
			resErrorCode + errorCode + newLine +
			resErrorDesc + errorDescription + newLine +
			resStatus + status + newLine;
		}
		return returnStr;
	}
}

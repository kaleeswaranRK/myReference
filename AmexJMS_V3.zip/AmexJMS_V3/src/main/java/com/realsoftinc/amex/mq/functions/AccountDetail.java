package com.realsoftinc.amex.mq.functions;

import static com.realsoftinc.amex.mq.common.MQConstants.MsgId_AccountDetail;
import static com.realsoftinc.amex.mq.common.MQConstants.emptyStr;
import static com.realsoftinc.amex.mq.common.MQConstants.errorCode;
import static com.realsoftinc.amex.mq.common.MQConstants.errorDesc;
import static com.realsoftinc.amex.mq.common.MQConstants.invalidStr;
import static com.realsoftinc.amex.mq.common.MQConstants.validStr;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.AccountDetailReturn;
import com.realsoftinc.amex.mq.returnObjs.AccountDtl;
import com.realsoftinc.amex.mq.returnObjs.AccountDtlAvailableOffers;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
import com.realsoftinc.amex.mq.util.ResponseParserAvailableOffers;

public class AccountDetail {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(AccountDetail.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public AccountDetailReturn accountDetail(String accNum) {
		logger.info("accountDetail(); Account Detail function is called by IVR .. ");
		logger.info("accountDetail(); Enter ");
		log.info("accountDetail(); Account Detail function is called by IVR .. ");
		log.info("accountDetail(); Enter ");

		MQCommon mqc = new MQCommon();

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		//String dateTimeStampOutStr = emptyStr;
		//String auditSeqOutStr = emptyStr;
		//String accountNum = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String maskAccNum = emptyStr;

		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;
		ResponseParserAvailableOffers respAvailOfferParser = null;
		AccountDtl accunt = null;
		AccountDetailReturn acctDetRtn = null;
		AccountDtlAvailableOffers[] accntAvlOff = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		try {
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			accunt = new AccountDtl();
			acctDetRtn = new AccountDetailReturn();
			respParser = new ResponseParser();
			respAvailOfferParser = new ResponseParserAvailableOffers();
			logger.info("accountDetail(); Calling the getDateTime function ..");

			log.info("accountDetail(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("accountDetail(); DateTimeStamp is : " + dateTimeStampInStr);
			logger.info("accountDetail(); Calling the getAuditSequence function ..");

			log.info("accountDetail(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("accountDetail(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("accountDetail(); Audit Sequence is : " + auditSeqInStr);

			log.info("accountDetail(); Audit Sequence is : " + auditSeqInStr);
			
			if(accNum.length() == 12){
				maskAccNum=accNum.substring(0,4)+"******"+accNum.substring(accNum.length()-5,accNum.length());
				logger.info("accountBal(); Account Number is : " + maskAccNum);

				log.info("accountBal(); Account Number is : " + maskAccNum);
				}
				else{
					logger.info("accountBal(); Account Number is less than 12 digits.");

					log.info("accountBal(); Account Number is less than 12 digits.");
				}
			logger.info("accountDetail(); Created all the required parameters to prepare the xml ..");

			log.info("accountDetail(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("AccountNumber", accNum);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("MessageId", MsgId_AccountDetail);
			xmlMap.put("SysID", mqc.getproperties("CardList.SysID"));
			logger.info("accountDetail(); Sending values to form proper format of xml request .. ");

			log.info("accountDetail(); Sending values to form proper format of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "AccountDetail");
			logger.info("accountDetail(); Received xml in proper format ..");

			log.info("accountDetail(); Received xml in proper format ..");
			MQCommon.maskAccNumber("accountDetail(); XML is : ", xmlReq);
			logger.info("accountDetail(); Sending the prepared xml to MQ .. ");

			log.info("accountDetail(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("accountDetail(); Response received from MQ .. ");

			log.info("accountDetail(); Response received from MQ .. ");
			MQCommon.maskAccNumber("accountDetail(); Received response from MQ is : ", replyMsg);
			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("accountDetail(); Sending the received response from MQ to the parser ..");

				log.info("accountDetail(); Sending the received response from MQ to the parser ..");
				// log.info("accountDetail(); XML sent for parsing is :"+ replyMsg);
				map = respParser.XmlParser(replyMsg);
				accntAvlOff = respAvailOfferParser.responseParserAvailableOffers(replyMsg);
				logger.info("accountDetail(); Received Hash map after parsing of response.");

				log.info("accountDetail(); Received Hash map after parsing of response.");

				acctDetRtn.errorCode = (String) map.get("errCode");
				acctDetRtn.errorDescription = (String) map.get("errDesc");

				if (acctDetRtn.errorCode.equalsIgnoreCase("0") 
						|| acctDetRtn.errorCode.equalsIgnoreCase("00")
						|| acctDetRtn.errorCode.equalsIgnoreCase("000")
						|| acctDetRtn.errorCode.equalsIgnoreCase("0000")) {
					logger.info("accountDetail(); Response from MQ is 'SUCCESS'.. ");

					log.info("accountDetail(); Response from MQ is 'SUCCESS'.. ");

					if ((String) map.get("MessageID")!= null) {
						accunt.MessageID = (String) map.get("MessageID");
					}
					if ((String) map.get("dateTimeStampStr")!= null) {
						accunt.DateTimeStampOutStr = (String) map.get("dateTimeStampStr");
					}
					if ((String) map.get("auditSeqOutStr")!= null) {
						accunt.AuditSeqOutStr = (String) map.get("auditSeqOutStr");
					}
					if ((String) map.get("description")!= null) {
						accunt.Description = (String) map.get("description");
					}
					
					if ((String) map.get("AccountParOverride")!= null) {
						accunt.AccountParOverride = (String) map.get("AccountParOverride");
					}
					if ((String) map.get("AccountStatus")!= null) {
						accunt.AccountStatus = (String) map.get("AccountStatus");
					}
					if ((String) map.get("amntDue")!= null) {
						accunt.AmountDue = (String) map.get("amntDue");
					}
					if ((String) map.get("auditSeqStr")!= null) {
						accunt.AuditSeqOutStr = (String) map.get("auditSeqStr");
					}
					if ((String) map.get("AvailableCash")!= null) {
						accunt.AvailableCash = (String) map.get("AvailableCash");
					}
					if ((String) map.get("AvailableCredit")!= null) {
						accunt.AvailableCredit = (String) map.get("AvailableCredit");
					}
					if ((String) map.get("BasicControlName")!= null) {
						accunt.BasicControlName = (String) map.get("BasicControlName");
					}
					if ((String) map.get("BasicControlNumber")!= null) {
						accunt.BasicControlNumber = (String) map.get("BasicControlNumber");
					}
					if ((String) map.get("billCycle")!= null) {
						accunt.BillingCycle = (String) map.get("billCycle");
					}
					if ((String) map.get("Currency")!= null) {
						accunt.Currency = (String) map.get("Currency");
					}
					if ((String) map.get("DaysDelinquent")!= null) {
						accunt.DaysDelinquent = (String) map.get("DaysDelinquent");
					}
					if ((String) map.get("DirectDebitFlag")!= null) {
						accunt.DirectDebitFlag = (String) map.get("DirectDebitFlag");
					}
					if ((String) map.get("ExpressCashFlag")!= null) {
						accunt.ExpressCashFlag = (String) map.get("ExpressCashFlag");
					}
					if ((String) map.get("LastPaymentAmount")!= null) {
						accunt.LastPaymentAmount = (String) map.get("LastPaymentAmount");
					}
					if ((String) map.get("MasterExposure")!= null) {
						accunt.MasterExposure = (String) map.get("MasterExposure");
					}
					if ((String) map.get("MasterLimit")!= null) {
						accunt.MasterLimit = (String) map.get("MasterLimit");
					}
					if ((String) map.get("PARAccountUnderride")!= null) {
						accunt.PARAccountUnderride = (String) map.get("PARAccountUnderride");
					}
					if ((String) map.get("pastDue")!= null) {
						accunt.PastDue = (String) map.get("pastDue");
					}
					if ((String) map.get("productName")!= null) {
						accunt.ProductName = (String) map.get("productName");
					}
					if ((String) map.get("StatementOption")!= null) {
						accunt.StatementOption = (String) map.get("StatementOption");
					}
					if ((String) map.get("TotalBilledBalance")!= null) {
						accunt.TotalBilledBalance = (String) map.get("TotalBilledBalance");
					}
					if ((String) map.get("TotalCashLimit")!= null) {
						accunt.TotalCashLimit = (String) map.get("TotalCashLimit");
					}
					if ((String) map.get("totCreLimit")!= null) {
						accunt.TotalCreditLimit = (String) map.get("totCreLimit");
					}
					if ((String) map.get("TotalMinimumDue")!= null) {
						accunt.TotalMinimumDue = (String) map.get("TotalMinimumDue");
					}
					if ((String) map.get("TotalSpendExposure")!= null) {
						accunt.TotalSpendExposure = (String) map.get("TotalSpendExposure");
					}
					
					/**Array Of Value Need To Set**/
					if (accntAvlOff != null) {
						accunt.AvailableOffers = accntAvlOff;
					}
					
					/*if ((String) map.get("")!= null) {
						accunt. = (String) map.get("");
					}*/
					
					acctDetRtn.status = validStr;

				} else {
					logger.info("accountDetail(); Response from MQ is 'FAILURE'.. ");

					log.info("accountDetail(); Response from MQ is 'FAILURE'.. ");
					acctDetRtn.status = invalidStr;
				}
				acctDetRtn.accuntDtl = accunt;

			} else {
				logger.info("accountDetail(); Since the response from MQ is not proper .. ");
				logger.info("accountDetail(); Setting error values.");
				log.info("accountDetail(); Since the response from MQ is not proper .. ");
				log.info("accountDetail(); Setting error values.");
				acctDetRtn.errorCode = errorCode;
				acctDetRtn.errorDescription = errorDesc;
				acctDetRtn.status = invalidStr;
				acctDetRtn.accuntDtl = accunt;
			}

		} catch (Exception e) {
			log.info("accountDetail(); Exception is raised." + e.toString());
			logger.info("accountDetail(); Exception is raised." + e.toString());

			acctDetRtn.accuntDtl = accunt;
			acctDetRtn.errorCode = errorCode;
			acctDetRtn.errorDescription = errorDesc;
			acctDetRtn.status = invalidStr;
			log.severe("accountDetail(); Reason : "+e.getStackTrace());
			logger.error("accountDetail(); Reason : "+e.getStackTrace());


		} finally {
			xmlReq = emptyStr;
			replyMsg = emptyStr;
			//dateTimeStampOutStr = emptyStr;
			//auditSeqOutStr = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			//	maskAccNum = emptyStr;

			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			xmlMap = null;
			map = null;
		}
		logger.info("accountDetail(); Response is returned to the IVR. Response : " + acctDetRtn.toString());
		logger.info("accountDetail(); Exit ");
		log.info("accountDetail(); Response is returned to the IVR. Response : " + acctDetRtn.toString());
		log.info("accountDetail(); Exit ");
		return acctDetRtn;
	}

}

package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class CardInformation {
	
	public String AccountNum = emptyStr;
	public String CMTitle = emptyStr;
	public String CMFirstName = emptyStr;
	public String CMDateOfBirth = emptyStr;
	public String MobileNO = emptyStr;
	public String CMEmailID = emptyStr;
	public String ProductCode = emptyStr;
	public String maskAccNum = emptyStr;
	public String DateTimeStamp = emptyStr;
	public String AuditSeq = emptyStr;
	public String CardNumber = emptyStr;
	public String CardSeq = emptyStr;
	public String UCI = emptyStr;
	public String CMFamilyName = emptyStr;
	public String LegalId = emptyStr;
	public String ClientCode = emptyStr;

	public String toString() {
		String returnStr = emptyStr;
		returnStr = newLine +
				resAccNum + maskAccNum + newLine +
				resTitle + CMTitle + newLine +
				resName + CMFirstName + newLine +
				resDOB + CMDateOfBirth + newLine +
				resMobilePhone + MobileNO    + newLine +
				resEmail + CMEmailID + newLine +
				resProductCode + ProductCode + newLine +
				resDateTimeStampLog + DateTimeStamp + newLine +
				resAuditSeq + AuditSeq + newLine +
				resCardNumber + CardNumber + newLine +
				resUCI + UCI + newLine +
				resCMFamilyName + CMFamilyName + newLine +
				resLegalID + LegalId + newLine +
				resClientCode + ClientCode + newLine;
		return returnStr;
	}
	
}

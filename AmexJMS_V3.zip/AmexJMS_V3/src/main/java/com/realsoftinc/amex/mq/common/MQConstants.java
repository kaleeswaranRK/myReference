/*
 * (C) Copyright 2008 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */

package com.realsoftinc.amex.mq.common;



/**
 * This class is responsible for initializing all the constants that are used in
 * this project.
 * 
 * @author Purvi Lad / Real Soft (Intl) Pvt. Ltd.
 * @version $Revision: 1.7 $ $Date: 2010/07/12 10:40:13 $
 */

public class MQConstants {

	public static final String emptyStr = "";
	public static final String newLine = "\n\r";
	public static final String digitZero = "0";
	public static final String maskString1 = "******";
	public static final String maskString2 = "***";
	public static final String currentFlagN = "N";
	
	public static final String validStr = "valid";
	public static final String invalidStr = "invalid";

	public static final String funcName = "RequestFunction";
	public static final String dob = "DateOfBirth";
	public static final String cardNo = "CardNumber";
	public static final String accNo = "AccountNumber";
	public static final String uniqId = "UniqueId";
	public static final String pinNo = "PinNumber";
	public static final String cardExpDt = "CardExpiryDate";

	public static final String logReq = "LoginRequest";
	public static final String cardNoValid = "CardNumberValidation";
	public static final String dateOfBrth = "DateofBirthValidation";
	public static final String cardActiv = "CardActivation";
	public static final String getEmbosDtl = "EmbosserDetail";
	public static final String accBal = "AccountBalance";
	public static final String getConDtls = "ContactDetails";
	public static final String getPayHist = "PaymentHistory";
	public static final String screenPopDtls = "ScreenPopDetails";
	public static final String getCurrCode = "CurrencyCode";
	public static final String chargeCardNoValid = "ChargeCardNoValidation";
	public static final String chargeCardDueDate = "ChargeCardDueDate";
	public static final String getchargCardAccBal = "ChargeCardAccountBalance";
	public static final String uniqueIdValidation = "UniqueIdValidation";
	public static final String pinSetup = "PinSetUp";
	public static final String unblckPin1 = "UnblockPin";
	// XML input string tags

	public static final String xmlHead = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

	public static final String eaiReq_s = "<EAIMessage_Req>";
	public static final String eaiReq_e = "</EAIMessage_Req>";
	public static final String eaiRes_s = "<EAIMessage_Res>";
	public static final String eaiRes_e = "</EAIMessage_Res>";

	public static final String eaiHead_s = "<EAIHeader>";
	public static final String eaiHead_e = "</EAIHeader>";
	public static final String eaiBody_s = "<EAIBody>";
	public static final String eaiBody_e = "</EAIBody>";

	public static final String msg_s = "<Message>";
	public static final String msg_e = "</Message>";
	public static final String msgReq_s = "<Message_Req>";
	public static final String msgReq_e = "</Message_Req>";
	public static final String msgRes_s = "<Message_Res>";
	public static final String msgRes_e = "</Message_Res>";

	public static final String accNo_s = "<AccountNumber>";
	public static final String accNo_e = "</AccountNumber>";
	public static final String act_s = "<Action>";
	public static final String act_e = "</Action>";
	public static final String actCode_s = "<ActionCode>";
	public static final String actCode_e = "</ActionCode>";
	public static final String audSeq_s = "<AuditSeq>";
	public static final String audSeq_e = "</AuditSeq>";
	public static final String cardSeqNo_s = "<CardSequenceNumber>";
	public static final String cardSeqNo_e = "</CardSequenceNumber>";
	public static final String cardSqNo_s = "<CardSeqNumber>";
	public static final String cardSqNo_e = "</CardSeqNumber>";
	public static final String cardNo_s = "<CardNumber>";
	public static final String cardNo_e = "</CardNumber>";
	public static final String cardNum_s = "<CardNo>";
	public static final String cardNum_e = "</CardNo>";
	public static final String cardExpDt_s = "<CardExpiryDate>";
	public static final String cardExpDt_e = "</CardExpiryDate>";
	public static final String caseNo_s = "<CaseNumber>";
	public static final String caseNo_e = "</CaseNumber>";
	public static final String channel_s = "<Channel>";
	public static final String channel_e = "</Channel>";
	public static final String currFlag_s = "<CurrentFlag>";
	public static final String currFlag_e = "</CurrentFlag>";
	public static final String cprno_s = "<CPRNo>";
	public static final String cprno_e = "</CPRNo>";
	public static final String dob_s = "<DateOfBirth>";
	public static final String dob_e = "</DateOfBirth>";
	public static final String dateTimeStamp_s = "<DateTimeStamp>";
	public static final String dateTimeStamp_e = "</DateTimeStamp>";
	public static final String desc_s = "<Description>";
	public static final String desc_e = "</Description>";
	public static final String hpr_s = "<HPR>";
	public static final String hpr_e = "</HPR>";
	public static final String lasFlag_s = "<LastFlag>";
	public static final String lasFlag_e = "</LastFlag>";
	public static final String len_s = "<Length>";
	public static final String len_e = "</Length>";
	public static final String msgId_s = "<MessageID>";
	public static final String msgId_e = "</MessageID>";
	public static final String mob_s = "<MobileNo>";
	public static final String mob_e = "</MobileNo>";
	public static final String mobNumb_s = "<MobileNumber>";
	public static final String mobNumb_e = "</MobileNumber>";
	public static final String note_s = "<Note>";
	public static final String note_e = "</Note>";
	public static final String pwd_s = "<Password>";
	public static final String pwd_e = "</Password>";
	public static final String pinNo_s = "<PinNumber>";
	public static final String pinNo_e = "</PinNumber>";
	public static final String prodID_s = "<ProductId>";
	public static final String prodID_e = "</ProductId>";
	public static final String rackFlag_s = "<RACKFlag>";
	public static final String rackFlag_e = "</RACKFlag>";
	public static final String repId_s = "<RepID>";
	public static final String repId_e = "</RepID>";
	public static final String respCode_s = "<ResponseCode>";
	public static final String respCode_e = "</ResponseCode>";
	public static final String respDesc_s = "<ResponseDescription>";
	public static final String respDesc_e = "</ResponseDescription>";
	public static final String revDate_s = "<ReviewDate>";
	public static final String revDate_e = "</ReviewDate>";
	public static final String revTime_s = "<ReviewTime>";
	public static final String revTime_e = "</ReviewTime>";
	public static final String sso_s = "<SSO>";
	public static final String sso_e = "</SSO>";
	public static final String uniqId_s = "<UniqueID>";
	public static final String uniqId_e = "</UniqueID>";
	public static final String user_s = "<username>";
	public static final String user_e = "</username>";
	public static final String usrName_s = "<UserName>";
	public static final String usrName_e = "</UserName>";
	public static final String msgTyp = "<MessageType />";
	public static final String sessionId = "<SessionID />";
	public static final String checkSum = "<Checksum />";
	public static final String clientIP = "<ClientIPAddress />";
	public static final String sourceApp_s = "<SourceApp>";
	public static final String sourceApp_e = "</SourceApp>";
	public static final String user1 = "<User1 />";
	public static final String user2 = "<User2 />";
	public static final String user3 = "<User3 />";
	public static final String user4 = "<User4 />";
	public static final String user5 = "<User5 />";
	public static final String sysID_s = "<SysID>";
	public static final String sysID_e = "</SysID>";
	
	public static final String workNoCC_s = "<WorkNOCountryCode>";
	public static final String workNoCC_e = "</WorkNOCountryCode>";
	public static final String homeNoCC_s = "<HomeNOCountryCode>";
	public static final String homeNoCC_e = "</HomeNOCountryCode>";
	public static final String mobNoCC_s = "<MobileNOCountryCode>";
	public static final String mobNoCC_e = "</MobileNOCountryCode>";
	public static final String workNo_s = "<WorkNO>";
	public static final String workNo_e = "</WorkNO>";
	public static final String homeNo_s = "<HomeNO>";
	public static final String homeNo_e = "</HomeNO>";
	public static final String mobNo_s = "<MobileNO>";
	public static final String mobNo_e = "</MobileNO>";
	public static final String emailID_s = "<EmailID>";
	public static final String emailID_e = "</EmailID>";
	public static final String email_s = "<Email>";
	public static final String email_e = "</Email>";
	public static final String eStatOptFlag_s = "<EStatementOptionFlag>";
	public static final String eStatOptFlag_e = "</EStatementOptionFlag>";
	public static final String smsOptFlag_s = "<SMSOptionFlag>";
	public static final String smsOptFlag_e = "</SMSOptionFlag>";
	public static final String lang_s = "<Language>";
	public static final String lang_e = "</Language>";
	
	public static final String firstName_s = "<FirstName>";
	public static final String firstName_e = "</FirstName>";
	public static final String familyName_s = "<FamilyName>";
	public static final String familyName_e = "</FamilyName>";
	public static final String clientCode_s = "<ClientCode>";
	public static final String clientCode_e = "</ClientCode>";
	public static final String uci_s = "<UCI>";
	public static final String uci_e = "</UCI>";
	public static final String legal_s = "<LegalID>";
	public static final String legal_e = "</LegalID>";
	
	public static final String campaignName_s = "<CampaignName>";
	public static final String campaignName_e = "</CampaignName>";
	public static final String startDate_s = "<StartDate>";
	public static final String startDate_e = "</StartDate>";
	public static final String endDate_s = "<EndDate>";
	public static final String endDate_e = "</EndDate>";
	public static final String campaignDetail_s = "<CampaignDetail>";
	public static final String campaignDetail_e = "</CampaignDetail>";
	public static final String campaignStatus_s = "<CampaignStatus>";
	public static final String campaignStatus_e = "</CampaignStatus>";
	public static final String origineFlag_s = "<OrigineFlag>";
	public static final String origineFlag_e = "</OrigineFlag>";
	
	public static final String ctiUser_s = "<CtiUser>";
	public static final String ctiUser_e = "</CtiUser>";
	public static final String caseReasonCode_s = "<CaseReasonCode>";
	public static final String caseReasonCode_e = "</CaseReasonCode>";
	
	public static final String representativeId_s = "<RepresentativeId>";
	public static final String representativeId_e = "</RepresentativeId>";
	public static final String holdProcessRefer_s = "<HoldProcessRefer>";
	public static final String holdProcessRefer_e = "</HoldProcessRefer>";
	public static final String caseNumber_s = "<CaseNumber>";
	public static final String caseNumber_e = "</CaseNumber>";


	public static final String MsgId_AccBal = "3003";
	public static final String MsgId_CardActv = "3069";
	public static final String MsgId_CardActvAck = "6000";
	public static final String MsgId_CardNoVal = "3001";
	public static final String MsgId_CardNoValResp = "3002";
//  public static final String MsgId_CntctDtls = "2001";
	public static final String MsgId_CurrCode = "6005";
	public static final String MsgId_ChkEnrl = "6017";
	public static final String MsgId_ConfEnrl= "6019";
	public static final String MsgId_DobValid = "2019";
	public static final String MsgId_EmbsrDtl = "3017";
	public static final String MsgId_PaymntHist = "3005";
	public static final String MsgId_LoginReq = "1001";
	public static final String MsgId_LoginResp = "1002";
	public static final String MsgId_UniqueId = "2029";
	public static final String MsgId_UniqueIdResp = "2030";
	public static final String MsgId_PinSetup = "3041";
	public static final String MsgId_PinSetupResp = "3042";
	public static final String MsgId_PinSetupAck = "6000";
	public static final String MsgId_UnblockPin = "6013";	
	public static final String MsgId_UnblockPinResp = "6014";	
	public static final String MsgId_ChrgCrdAccBal = "5003";
	public static final String MsgId_ChrgCrdAccBalResp = "5004";
	public static final String MsgId_ChckCSIEnrolled = "6018";
	public static final String MsgId_EnrollCSI = "6020";
	public static final String ChrgCrdSrcApp = "AEUB";
	public static final String MsgId_ChrgCrdDueDt = "5041";
	public static final String MsgId_ChrgCrdDueDtResp = "5042";
	public static final String ChrgCrdSrcApp1 = "AQOM";
	public static final String MsgId_ChrgCrdNoValid = "5005";
	public static final String MsgId_ChrgCrdNoValidResp = "5006";
	public static final String ChrgCrdSrcApp2 = "AEBA";
	public static final String MsgId_UpdateConDet = "3007";
	public static final String MsgId_UpdateConDetResp = "3008";
	public static final String MsgId_MREnrollment = "2040";
	public static final String MsgId_SendMail = "2042";
	public static final String MsgId_CardList = "8265";
	public static final String MsgId_CardDetails = "8267";
	public static final String MsgId_AccountDetail = "8269";
	public static final String MsgId_AccountOffers = "8273";
	public static final String MsgId_PinMailer = "8275";
	public static final String MsgId_GetClientCode = "8271";
	
	
	public static final String UniqueId_Desc = "Unique ID";
	public static final String PinSetup_Desc = "Pin Change";
	public static final String PinSetup_ActnCode = "PINS";
	public static final String PinSetup_Actn = "005";
	public static final String PinSetup_CrdSeqNo = "0001";
	public static final String PinSetup_Note = "PIN Setup from SOA";
	public static final String PinSetup_RepId = "CSE";
	public static final String PinSetup_Hpr = "P";
	public static final String UpdateConDet_Desc = "Request For Edit Contact Details";
	public static final String MREnrollment_Desc = "IVR MR EMAIL";
	public static final String SendMail_Desc = "IVR EMAIL Attachment";
	
	public static final String CurrencyCode_Desc = "Get Card Type";
	public static final String DobValidation_Desc = "Additional Card Member Info Request message";
	public static final String Login_Desc = "Login Request message";
	public static final String CardActv_Desc = "Card Activation Request message";
	public static final String CardActv_DescAck = "Avaya Response Acknowledgement";
	//public static final String PinSetup_DescAck = "Avaya Response Acknowledgement";
	public static final String CardActv_CardSeqNo = "1";
	public static final String CardActv_note = "note";
	public static final String CardActv_RepId = "CSE";
	public static final String CardActv_CaseNo = "12425262727";
	public static final String CardActv_Hpr = "Y";
	public static final String CardList_Desc = "Response From Search Avaya";

	public static final String resSSOLog = "SSO                : ";
	public static final String resDateTimeStampLog = "DateTimeStamp      : ";
	public static final String resAuditSeq = "AuditSeq           : ";
	public static final String resMsgId = "MessageID          : ";
	public static final String resErrorCode = "ErrorCode          : ";
	public static final String resErrorDesc = "ErrorDescription   : ";
	public static final String resAccNum = "Account Number     : ";
	public static final String resCurrentUsageFlag = "Current Usage Flag : ";
	public static final String resLastUsageFlag = "Last Usage Flag    : ";
	public static final String resFirstUsageFlag = "FirstUsageFlag   	: ";
	public static final String resPriorUsageFlag = "PriorUsageFlag   	: ";
	public static final String resOrg = "Org                : ";
	public static final String resLogo = "Logo               : ";
	public static final String resOrgLogo = "OrgLogo            : ";
	public static final String resCurrentBalance = "CurrentBalance     : ";
	public static final String resAmountDue = "AmountDue          : ";
	public static final String resTotalCreditLimit = "TotalCreditLimit   : ";
	public static final String resCashCreditLimit = "CashCreditLimit    : ";
	public static final String resCashBalance = "CashBalance        : ";
	public static final String resCashAvailable = "CashAvailable      : ";
	public static final String resOTB = "OTB                : ";
	public static final String resBeginBalance = "BeginBalance       : ";
	public static final String resBlockCode = "BlockCode         : ";
	public static final String resStatus = "Status             : ";
	public static final String resPastDue = "PastDue            : ";
	public static final String resLastPurchase = "LastPurchase       : ";
	public static final String resBillingCycle = "BillingCycle       : ";
	public static final String resDateOpened = "DateOpened         : ";
	public static final String resDueDate = "DueDate            : ";
	public static final String resDateLastStatement = "DateLastStatement  : ";
	public static final String resLastStatBal = "LastStatementBalance  : ";
	public static final String resBlockCode2 = "BlockCode2         : ";
	public static final String resOverdueFlag = "OverdueFlag         : ";
	public static final String resMemoBalance = "MemoBalance        : ";
	public static final String resDateCardFee = "DateCardFee        : ";
	public static final String resCTAReason = "CTAReason          : ";
	public static final String resTitle = "Title              : ";
	public static final String resHomePhone = "HomePhone          : ";
	public static final String resHomeCountrySel = "HomeCountrySel          : ";
	public static final String resWorkPhone = "WorkPhone        : ";
	public static final String resWorkCountrySel = "WorkCountrySel        : ";
	public static final String resMobilePhone = "MobilePhone        : ";
	public static final String resMobileCountrySel = "MobileCountrySel        : ";
	public static final String resEmail = "EmailID             : ";
	public static final String resSMSFlag = "SMSFlag              : ";
	public static final String resEStatementFlag = "eStatementFlag              : ";
	public static final String resName = "Name1              : ";
	public static final String resNameOther = "Name               : ";
	public static final String resMemo1 = "Memo1              : ";
	public static final String resMemo2 = "Memo2              : ";
	public static final String resMemo3 = "Memo3              : ";
	public static final String resBranchCode = "BranchCode              : ";
	//CR July 2016. - Geomant
	public static final String resPowercardID = "PowercardID              : ";
	public static final String resAmountLastPayment = "AmountLastPayment  : ";
	public static final String resAmountPurchCTD = "AmountPurchaseCTD    : ";
	public static final String resAmountPurchYTD = "AmountPurchaseYTD    : ";
	public static final String resAmountPurchLTD = "AmountPurchaseLTD   : ";
	public static final String resAmountCashCTD = "AmountCashCTD    : ";
	public static final String resAmountCashYTD = "AmountCashYTD    : ";
	public static final String resAmountCashLTD = "AmountCashLTD   : ";
	public static final String resDateLastPayment = "DateLastPayment    : ";
	public static final String resMemberSince = "MemberSince    : ";
	public static final String resStatementAddr1 = "StatementAddress1    : ";
	public static final String resDOB = "DOB   : ";
	
	public static final String resAvailPoints = "AvailablePoints   : ";
	public static final String resBonusPoints = "BonusPoints   : ";
	public static final String resClosingBalance = "ClosingBalance   : ";
	public static final String resEarnedPoints = "EarnedPoints   : ";
	public static final String resMembId = "MemberId   : ";
	public static final String resOpenBalance = "PointsOpeningBalance   : ";
	public static final String resPrevBalance = "PreviousBalance   : ";
	public static final String resAdjPoints = "RedeemedPoints   : ";
	public static final String resReedemedPoints = "AdjustedPoints   : ";
	
		
	public static final String resPassNum = "PassportNumber   : ";
	public static final String resCPRID = "CPRID   : ";
	public static final String resBankName = "BankName   : ";
	public static final String resBankBranch = "BankBranch   : ";
	public static final String resBankAccNumber = "BankAccountNumber   : ";
	public static final String resNationality = "Nationality   : ";
	public static final String resIncome = "Income    : ";
	public static final String resXRef1 = "XRef1   : ";
	public static final String resXRef2 = "XRef2   : ";
	public static final String resHomeAddr1 = "HomeAddress1   : ";
	public static final String resHomeAddr2 = "HomeAddress2   : ";
	public static final String resHomeAddr3 = "HomeAddress3   : ";
	public static final String resHomePhArea = "HomePhoneArea   : ";
	public static final String resHomeEmail = "HomeEmail   : ";
	public static final String resPrevAddr1 = "PreviousAddress1   : ";
	public static final String resPrevAddr2 = "PreviousAddress2   : ";
	public static final String resPrevAddr3 = "PreviousAddress3   : ";
	public static final String resStatementAddr2 = "StatementAddress2   : ";
	public static final String resStatementAddr3 = "StatementAddress3   : ";
	public static final String resEmpName = "EmployerName   : ";
	public static final String resEmpAddr1 = "EmployerAddress1   : ";
	public static final String resEmpAddr2 = "EmployerAddress2   : ";
	public static final String resEmpAddr3 = "EmployerAddress3   : ";
	public static final String resEmpPhArea = "EmployerPhoneArea   : ";
	public static final String resEmpPhone = "EmployerPhone   : ";
	public static final String resEmpFax = "EmployerFax   : ";
	public static final String resEmpMail = "EmployerMail  : ";
	
	
	public static final String resDelqTPD = "DelqTPD            : ";
	public static final String resDelqXdayNumber = "DelqXdayNumber     : ";
	public static final String resDelqXdayAmount = "DelqXdayAmount     : ";
	public static final String resCardNumber = "Card Number 	    : ";
	public static final String resCardType = "Card Type          : ";
	public static final String resAccStatusMsg = "Account Status Message : ";
	public static final String resCurrencyName = "Currency Name      : ";
	public static final String resCurrencySymbol = "Currency Symbol    : ";
	public static final String resPrimarySuppFlag = "Primary Supp Flag  : ";
	public static final String resIsNewCardActivation = "Is New Card Activation : ";
	public static final String resEnrolledStatus = "EnrolledStatus                : ";
	public static final String resLength = "Length                : ";
	public static final String resDBC = "DBC               : ";
	public static final String resEmbossName = "Embosser Name                : ";
	public static final String resExpiryDate = "Expiry Date              : ";
	public static final String resProductCode = "Product Code              : ";
	
	public static final String resUCI = "UCI              : ";
	public static final String resCMFirstName = "CM FirstName              : ";
	public static final String resCMFamilyName = "CM Family Name              : ";
	public static final String resLegalID = "Legal ID              : ";
	public static final String resClientCode = "ClientCode              : ";
	public static final String resCardSeq = "Card Sequence 	    : ";
	
	public static final String resDesc = "Description               : ";
	public static final String resClientUnderride = "Client Underride               : ";
	public static final String resClientOverride = "Client Override               : ";
	public static final String resCardActivationFlag = "Card Activation Flag               : ";
	public static final String resCardActivationDate = "Card Activation Date               : ";
	public static final String resCardExpiryDate = "Card Expiry Date               : ";
	public static final String resProductType = "Product Type              : ";
	public static final String resPINStatus = "PIN Status              : ";
	public static final String resCardStatus = "Card Status              : ";
	public static final String resProductName = "Product Name              : ";
	public static final String resEmployeeID = "Employee ID              : ";
	public static final String resRMName = "RM Name              : ";
	public static final String resVIPLevel = "VIP Level              : ";
	public static final String resStopList = "Stop List              : ";
	public static final String resTransaction = "Transaction              : ";
	
	public static final String resStatementOption = "Statement Option               : ";
	public static final String resAccountStatus = "Account Status               : ";
	public static final String resTotalCashLimit = "Total CashLimit               : ";
	public static final String resTotalMinimumDue = "Total Minimum Due               : ";
	public static final String resLastPaymentAmount = "Last Payment Amount               : ";
	public static final String resTotalSpendExposure = "Total Spend Exposure               : ";
	public static final String resAccountParOverride = "Account ParOverride              : ";
	public static final String resMasterLimit = "Master Limit              : ";
	public static final String resBasicControlNumber = "Basic Control Number              : ";
	public static final String resBasicControlName = "Basic Control Name              : ";
	public static final String resAvailableCredit = "Available Credit              : ";
	public static final String resAvailableCash = "Available Cash             : ";
	public static final String resDaysDelinquent = "Days Delinquent              : ";
	public static final String resTotalBilledBalance = "Total Billed Balance              : ";
	public static final String resPARAccountUnderride = "PARA ccount Underride              : ";
	public static final String resMasterExposure = "Master Exposure              : ";
	public static final String resCurrency = "Currency              : ";
	public static final String resExpressCashFlag = "Express Cash Flag              : ";
	public static final String resDirectDebitFlag = "Direct Debit Flag              : ";
	public static final String resAccountDtlAvailableOffers = "Available Offers              : ";
	
	public static final String resCampaignName = "Campaign Name              : ";
	public static final String resStartDate = "Start Date              : ";
	public static final String resEndDate = "End Date              : ";
	public static final String resCampaignDetail = "Campaign Detail              : ";
	public static final String resPrimSupplFlag = "primSuppl Flag              : ";
	
	
	public static final String errorCode = "1000";
	public static final String errorDesc = "FAILURE";

}

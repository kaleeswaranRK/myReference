/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.ChargeCardNoValidationReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for having the main business logic for Charge Card
 * AccountBalance Function
 * 
 * @name ChargeCardNoValidation
 * @author Purvi Lad
 * @version 1.0 Date 11 Mar 2010
 */

public class ChargeCardNoValidation {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(ChargeCardNoValidation.class);

	@SuppressWarnings({ "unchecked" })
	public ChargeCardNoValidationReturn chargeCardValidation(String CardNum) {
		logger.info("chargeCardValidation(); Charge Card Validation function is called by IVR .. ");
		logger.info("chargeCardValidation(); Enter ");
		log.info("chargeCardValidation(); Charge Card Validation function is called by IVR .. ");
		log.info("chargeCardValidation(); Enter ");

		ChargeCardNoValidationReturn cardValid = null;
		Map<String, String> xmlMap = null;
		Map<String, String> map = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser cardnoparser = null;
		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		String errorCode = emptyStr;
		String returnMsgIdActualStr = emptyStr;
		String maskCardNum = emptyStr;

		try {
			cardValid = new ChargeCardNoValidationReturn();
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			cardnoparser = new ResponseParser();

			if (CardNum.length() == 15) {

				maskCardNum = CardNum.substring(0, 4) + "******"
						+ CardNum.substring(CardNum.length() - 5, CardNum.length());
				logger.info("chargeCardValidation(); Card Number is : " + maskCardNum);

				log.info("chargeCardValidation(); Card Number is : " + maskCardNum);
			} else {
				logger.info("chargeCardValidation(); Card Number is less than 15 digits.");

				log.info("chargeCardValidation(); Card Number is less than 15 digits.");
			}
			logger.info("chargeCardValidation(); Created all the required parameters to prepare the xml ..");

			log.info("chargeCardValidation(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("AccountNumber", CardNum);
			xmlMap.put("MessageId", MsgId_ChrgCrdNoValid);
			xmlMap.put("sourceApp", ChrgCrdSrcApp2);
			logger.info("chargeCardValidation(); Sending values to form proper form of xml request .. ");

			log.info("chargeCardValidation(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "ChargeCardNoValidation");
			logger.info("chargeCardValidation(); Received xml in proper format ..");
			logger.info("chargeCardValidation(); XML is : " + xmlReq);

			logger.info("chargeCardValidation(); Sending this xml as the request to MQ ..");
			log.info("chargeCardValidation(); Received xml in proper format ..");
			log.info("chargeCardValidation(); XML is : " + xmlReq);

			log.info("chargeCardValidation(); Sending this xml as the request to MQ ..");
			replyMsg = rr.MessageSender(xmlReq);
			log.info("chargeCardValidation(); Response received from MQ .. ");
			log.info("chargeCardValidation(); Received response from MQ is : " + replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("chargeCardValidation(); Sending the received response from MQ to the parser ..");
				logger.info("chargeCardValidation(); XML sent for parsing is :" + replyMsg);
				log.info("chargeCardValidation(); Sending the received response from MQ to the parser ..");
				log.info("chargeCardValidation(); XML sent for parsing is :" + replyMsg);
				map = cardnoparser.XmlParser(replyMsg);
				logger.info("chargeCardValidation(); Received Hash map after parsing of response.");

				log.info("chargeCardValidation(); Received Hash map after parsing of response.");

				errorCode = (String) map.get("errorCode");
				cardValid.errorCode = errorCode;

				if (errorCode.equalsIgnoreCase("0") || errorCode.equalsIgnoreCase("00")
						|| errorCode.equalsIgnoreCase("000") || errorCode.equalsIgnoreCase("0000")) {
					logger.info("chargeCardValidation(); Response from MQ is 'SUCCESS'.. ");

					log.info("chargeCardValidation(); Response from MQ is 'SUCCESS'.. ");
					cardValid.title = (String) map.get("title1");
					cardValid.name = (String) map.get("name1");
					cardValid.accountNum = (String) map.get("accountNum");
					returnMsgIdActualStr = (String) map.get("returnMsgIdActualStr");
					cardValid.status = validStr;
				} else {
					logger.info("chargeCardValidation(); Response from MQ is 'FAILURE'.. ");

					log.info("chargeCardValidation(); Response from MQ is 'FAILURE'.. ");
					cardValid.status = invalidStr;
				}

				if (MsgId_ChrgCrdNoValidResp.equalsIgnoreCase(returnMsgIdActualStr)) {
					log.info("chargeCardValidation(); Getting valid msg id from the response.");
				} else {
					logger.info("chargeCardValidation(); Since the response from MQ is not proper .. ");
					logger.info("chargeCardValidation(); Setting error values.");
					log.info("chargeCardValidation(); Since the response from MQ is not proper .. ");
					log.info("chargeCardValidation(); Setting error values.");
					cardValid.errorCode = MQConstants.errorCode;
					cardValid.status = invalidStr;
				}
			}
		} catch (Exception e) {
			logger.info("chargeCardValidation(); Exception is raised." + e.toString());

			log.info("chargeCardValidation(); Exception is raised." + e.toString());
			cardValid.errorCode = MQConstants.errorCode;
			cardValid.status = invalidStr;
			logger.error("chargeCardValidation(); Reason : " + e.getStackTrace());

			log.severe("chargeCardValidation(); Reason : " + e.getStackTrace());
		} finally {
			xmlMap = null;
			map = null;
			rc = null;
			rr = null;
			cardnoparser = null;

			xmlReq = emptyStr;
			replyMsg = emptyStr;
			errorCode = emptyStr;
			returnMsgIdActualStr = emptyStr;
			maskCardNum = emptyStr;
		}
		logger.info("chargeCardValidation(); Response is returned to the IVR. Response : " + cardValid.toString());
		logger.info("chargeCardValidation(); Exit");
		log.info("chargeCardValidation(); Response is returned to the IVR. Response : " + cardValid.toString());
		log.info("chargeCardValidation(); Exit");
		return cardValid;
	}
}

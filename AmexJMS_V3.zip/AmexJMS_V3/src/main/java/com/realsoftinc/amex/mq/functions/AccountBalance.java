/*
* (C) Copyright 2013 Geomant Kft. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import static com.realsoftinc.amex.mq.common.MQConstants.MsgId_AccBal;
import static com.realsoftinc.amex.mq.common.MQConstants.emptyStr;
import static com.realsoftinc.amex.mq.common.MQConstants.errorCode;
import static com.realsoftinc.amex.mq.common.MQConstants.errorDesc;
import static com.realsoftinc.amex.mq.common.MQConstants.invalidStr;
import static com.realsoftinc.amex.mq.common.MQConstants.validStr;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.returnObjs.AccountBalanceReturn;
import com.realsoftinc.amex.mq.returnObjs.AccountInformation;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function Account Balance
 * 
 * @author Marijana Dujovic / Geomant Kft.
 */

public class AccountBalance {

//	Logger log = Utility.getLogger();
	final static Logger log = Logger.getLogger(AccountBalance.class.getName());
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(AccountBalance.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public AccountBalanceReturn accountBal(String accNum) {
		logger.info("accountBal(); Account Balance function is called by IVR .. ");
		logger.info("accountBal(); Enter ");
		log.info("accountBal(); Account Balance function is called by IVR .. ");
		log.info("accountBal(); Enter ");

		MQCommon mqc = new MQCommon();

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
//		@SuppressWarnings("unused")
		String accountNum = emptyStr;
//		@SuppressWarnings("unused")
		String dateTimeStampOutStr = emptyStr;
//		@SuppressWarnings("unused")
		String auditSeqOutStr = emptyStr;

		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;

		String maskAccNum = emptyStr;

		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;
		AccountInformation accInfo = null;
		AccountBalanceReturn accBalRtn = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;
		try {

			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			accInfo = new AccountInformation();
			accBalRtn = new AccountBalanceReturn();
			respParser = new ResponseParser();

			/*
			 * sso = MQCommon.SSO;
			 * 
			 * if(sso == null) { log.info("accountBal(); sso is null");
			 * log.info("accountBal(); Calling getSSO() function .. "); sso = mqc.getSSO();
			 * } else if(sso.equalsIgnoreCase(emptyStr)) {
			 * log.info("accountBal(); sso is empty string");
			 * log.info("accountBal(); Calling getSSO() function .. "); sso = mqc.getSSO();
			 * }
			 */

			if (accNum.length() == 12) {
				maskAccNum = accountNum.substring(0, 4) + "******"
						+ accountNum.substring(accountNum.length() - 5, accountNum.length());
				logger.info("accountBal(); Account Number is : " + maskAccNum);
				log.info("accountBal(); Account Number is : " + maskAccNum);
			} else {
				logger.info("accountBal(); Account Number is less than 12 digits.");

				log.info("accountBal(); Account Number is less than 12 digits.");
			}
			logger.info("accountBal(); Calling the getDateTime function ..");

			log.info("accountBal(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("accountBal(); DateTimeStamp is : " + dateTimeStampInStr);
			logger.info("accountBal(); Calling the getAuditSequence function ..");

			log.info("accountBal(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("accountBal(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("accountBal(); Audit Sequence is : " + auditSeqInStr);

			logger.info("accountBal(); Created all the required parameters to prepare the xml ..");
			log.info("accountBal(); Audit Sequence is : " + auditSeqInStr);

			log.info("accountBal(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("AccountNumber", accNum);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			// xmlMap.put("SSO", sso);
			// xmlMap.put("MessageLength", mqc.getproperties("AccountBalance.MsgLength"));
			xmlMap.put("MessageId", MsgId_AccBal);
			xmlMap.put("SysID", mqc.getproperties("AccountBalance.SysID"));
			logger.info("accountBal(); Sending values to form proper format of xml request .. ");

			log.info("accountBal(); Sending values to form proper format of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "AccountBalance");
			logger.info("accountBal(); Received xml in proper format ..");

			log.info("accountBal(); Received xml in proper format ..");
			// log.info("accountBal(); XML is : " + xmlReq);
			// Added to encrypt account number when display request in log file
			MQCommon.maskAccNumber("accountBal(); XML is : ", xmlReq);
			logger.info("accountBal(); Sending the prepared xml to MQ .. ");

			log.info("accountBal(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("accountBal(); Response received from MQ .. ");

			log.info("accountBal(); Response received from MQ .. ");
			// log.info("accountBal(); Received response from MQ is : " + replyMsg);
			// Added to encrypt account number when display response in log file
			MQCommon.maskAccNumber("accountBal(); Received response from MQ is : ", replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("accountBal(); Sending the received response from MQ to the parser ..");

				log.info("accountBal(); Sending the received response from MQ to the parser ..");
				// log.info("accountBal(); XML sent for parsing is :"+ replyMsg);
				map = respParser.XmlParser(replyMsg);
				logger.info("accountBal(); Received Hash map after parsing of response.");

				log.info("accountBal(); Received Hash map after parsing of response.");

				accBalRtn.errorCode = (String) map.get("errCode");
				accBalRtn.errorDescription = (String) map.get("errDesc");

				if (accBalRtn.errorCode.equalsIgnoreCase("0") || accBalRtn.errorCode.equalsIgnoreCase("00")
						|| accBalRtn.errorCode.equalsIgnoreCase("000")
						|| accBalRtn.errorCode.equalsIgnoreCase("0000")) {
					logger.info("accountBal(); Response from MQ is 'SUCCESS'.. ");

					log.info("accountBal(); Response from MQ is 'SUCCESS'.. ");
					accountNum = (String) map.get("accountNum");
					dateTimeStampOutStr = (String) map.get("dateTimeStampOutStr");
					auditSeqOutStr = (String) map.get("auditSeqOutStr");

					// accInfo.AccountNumber = (String)map.get("accountNum");

					if ((String) map.get("curBal") != null)
						accInfo.CurrentBalance = (String) map.get("curBal");
					// accInfo.CardType = (String) map.get("cardtype");

					if ((String) map.get("amntDue") != null)
						accInfo.AmountDue = (String) map.get("amntDue");
					if ((String) map.get("dueDate") != null)
						accInfo.DueDate = (String) map.get("dueDate");
					if ((String) map.get("otb") != null)
						accInfo.OTB = (String) map.get("otb");
					if ((String) map.get("dueLastStat") != null)
						accInfo.DateLastStatement = (String) map.get("dueLastStat");
					if ((String) map.get("lastStmtBal") != null)
						accInfo.LastStatBalance = (String) map.get("lastStmtBal");
					if ((String) map.get("cashAvail") != null)
						accInfo.CashAvailable = (String) map.get("cashAvail");
					if ((String) map.get("totCreLimit") != null)
						accInfo.TotalCreditLimit = (String) map.get("totCreLimit");
					if ((String) map.get("bgnBal") != null)
						accInfo.BeginBalance = (String) map.get("bgnBal");
					if ((String) map.get("dateLastPay") != null)
						accInfo.DateLastPayment = (String) map.get("dateLastPay");
					if ((String) map.get("amountCashCTD") != null)
						accInfo.AmountCashCTD = (String) map.get("amountCashCTD");
					if ((String) map.get("amountCashLTD") != null)
						accInfo.AmountCashLTD = (String) map.get("amountCashLTD");
					if ((String) map.get("amountCashYTD") != null)
						accInfo.AmountCashYTD = (String) map.get("amountCashYTD");
					if ((String) map.get("amountPurchCTD") != null)
						accInfo.AmountPurchCTD = (String) map.get("amountPurchCTD");
					if ((String) map.get("amountPurchLTD") != null)
						accInfo.AmountPurchLTD = (String) map.get("amountPurchLTD");
					if ((String) map.get("amountPurchYTD") != null)
						accInfo.AmountPurchYTD = (String) map.get("amountPurchYTD");
					if ((String) map.get("cashBal") != null)
						accInfo.CashBalance = (String) map.get("cashBal");
					if ((String) map.get("cashCreLimit") != null)
						accInfo.CashCreditLimit = (String) map.get("cashCreLimit");
					if ((String) map.get("lastPur") != null)
						accInfo.LastPurchase = (String) map.get("lastPur");
					if ((String) map.get("billCycle") != null)
						accInfo.BillingCycle = (String) map.get("billCycle");
					if ((String) map.get("status") != null)
						accInfo.Status = (String) map.get("status");
					if ((String) map.get("dateOpened") != null)
						accInfo.DateOpened = (String) map.get("dateOpened");
					if ((String) map.get("pastDue") != null)
						accInfo.PastDue = (String) map.get("pastDue");
					if ((String) map.get("memberSince") != null)
						accInfo.MemberSince = (String) map.get("memberSince");
					if ((String) map.get("blCode") != null)
						accInfo.BlockCode = (String) map.get("blCode");
					if ((String) map.get("blCode2") != null)
						accInfo.BlockCode2 = (String) map.get("blCode2");
					if ((String) map.get("overdueFlag") != null)
						accInfo.OverdueFlag = (String) map.get("overdueFlag");
					if ((String) map.get("ctaReason") != null)
						accInfo.CTAReason = (String) map.get("ctaReason");
					if ((String) map.get("memoBal") != null)
						accInfo.MemoBalance = (String) map.get("memoBal");
					if ((String) map.get("dateCardFee") != null)
						accInfo.DateCardFee = (String) map.get("dateCardFee");

					accBalRtn.status = validStr;
				} else {
					logger.info("accountBal(); Response from MQ is 'FAILURE'.. ");

					log.info("accountBal(); Response from MQ is 'FAILURE'.. ");
					accBalRtn.status = invalidStr;
				}
				accBalRtn.accInfo = accInfo;
			} else {
				logger.info("accountBal(); Since the response from MQ is not proper .. ");
				logger.info("accountBal(); Setting error values.");
				log.info("accountBal(); Since the response from MQ is not proper .. ");
				log.info("accountBal(); Setting error values.");
				accBalRtn.errorCode = errorCode;
				accBalRtn.errorDescription = errorDesc;
				accBalRtn.status = invalidStr;
				accBalRtn.accInfo = accInfo;
			}
		} catch (Exception e) {
			logger.error("accountBal(); Exception is raised." + e.toString());

			log.severe("accountBal(); Exception is raised." + e.toString());
			accBalRtn.accInfo = accInfo;
			accBalRtn.errorCode = errorCode;
			accBalRtn.errorDescription = errorDesc;
			accBalRtn.status = invalidStr;
			logger.error("accountBal(); Reason : " + e.getStackTrace());

			log.severe("accountBal(); Reason : " + e.getStackTrace());
		} finally {
			xmlReq = emptyStr;
			replyMsg = emptyStr;
			accountNum = emptyStr;
			dateTimeStampOutStr = emptyStr;
			auditSeqOutStr = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;

			maskAccNum = emptyStr;

			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			accInfo = null;
			xmlMap = null;
			map = null;
		}
		logger.info("accountBal(); Response is returned to the IVR. Response : " + accBalRtn.toString());
		logger.info("accountBal(); Exit ");
		log.info("accountBal(); Response is returned to the IVR. Response : " + accBalRtn.toString());
		log.info("accountBal(); Exit ");
		return accBalRtn;
	}

}

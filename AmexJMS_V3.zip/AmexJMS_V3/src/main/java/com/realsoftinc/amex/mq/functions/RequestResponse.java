package com.realsoftinc.amex.mq.functions;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import java.util.HashMap;
import java.util.Map;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import java.util.logging.Logger;

public class RequestResponse {
	private static final long serialVersionUID = 1L;
	Logger log = Utility.getLogger();
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(RequestResponse.class);

	QueueConnection conn;
	QueueConnectionFactory qcf;
	Queue vpIn;
	Queue vpOut;
	String vpIn_St;
	String vpOut_St;

	public RequestResponse() {
		MQCommon mqc = null;
		Map map = null;

		try {
			mqc = new MQCommon();
			map = mqc.openQueues();
			this.qcf = (QueueConnectionFactory) map.get("qcf");
			this.vpIn_St = (String) map.get("vpIn");
			this.vpOut_St = (String) map.get("vpOut");
			this.log.info(" vpin: " + this.vpIn_St + " vpout: " + this.vpOut_St);
			logger.info(" vpin: " + this.vpIn_St + " vpout: " + this.vpOut_St);
		} catch (JMSException var4) {
			logger.error("Exception is raised. Reason :" + var4.getLocalizedMessage() + "\nat "
					+ var4.getStackTrace()[0].toString());
			this.log.severe("Exception is raised. Reason :" + var4.getLocalizedMessage() + "\nat "
					+ var4.getStackTrace()[0].toString());
			System.out.println("JMS Exception is raised. Reason :" + var4);
		}

	}

	public String MessageSender(String XML) {
		logger.info("MessageSender(); Enter");
		this.log.info("MessageSender(); Enter");
		String replyText = null;
		QueueSender queueSender = null;
		QueueReceiver queueReceiver = null;
		QueueSession queueSession = null;
		Map map = null;
		MQCommon mqc = null;

		try {
			new MQCommon();
			MQCommon.maskAccNumber("XML received to be sent as a request to MQ is : ", XML.toString());
			logger.info("Creating Connection ..");
			this.log.info("Creating Connection ..");
			this.conn = this.qcf.createQueueConnection();
			this.conn.start();
			logger.info("Creating Session ..");
			logger.info("Getting Connection .." + this.conn.toString());
			this.log.info("Creating Session ..");
			this.log.info("Getting Connection .." + this.conn.toString());
			queueSession = this.conn.createQueueSession(false, 1);
			logger.info("Session created successfully.");
			logger.info("Value of vpIn_St is :" + this.vpIn_St);
			logger.info("Creating Input Queue");
			this.log.info("Session created successfully.");
			this.log.info("Value of vpIn_St is :" + this.vpIn_St);
			this.log.info("Creating Input Queue");
			this.vpIn = queueSession.createQueue("queue:///" + this.vpIn_St + "?targetClient=1");
			logger.info("Input Queue Created Successfully");
			logger.info("Value of vpOut_St is :" + this.vpOut_St);
			logger.info("Creating Output Queue");
			this.log.info("Input Queue Created Successfully");
			this.log.info("Value of vpOut_St is :" + this.vpOut_St);
			this.log.info("Creating Output Queue");
			this.vpOut = queueSession.createQueue("queue:///" + this.vpOut_St + "?targetClient=1");
			logger.info("Output Queue Created Successfully");
			logger.info("Creating Sender");
			this.log.info("Output Queue Created Successfully");
			this.log.info("Creating Sender");
			queueSender = queueSession.createSender(this.vpIn);
			logger.info("MessageSender(); Creating MQ Message for sending ..");
			this.log.info("MessageSender(); Creating MQ Message for sending ..");
			TextMessage msg = queueSession.createTextMessage(XML);
			queueSender.setDeliveryMode(1);
			queueSender.setTimeToLive(Long.valueOf(MQCommon.getproperties("Request.Interval")));
			queueSender.send(msg);
			logger.info("MessageSender(); XML message sent");
			logger.info("MessageSender(); Correlation id is : " + msg.getJMSMessageID().toString());
			this.log.info("MessageSender(); XML message sent");
			this.log.info("MessageSender(); Correlation id is : " + msg.getJMSMessageID().toString());
			queueReceiver = queueSession.createReceiver(this.vpOut, "JMSCorrelationID='" + msg.getJMSMessageID() + "'");
			logger.info("MessageSender(); Queue receiver created successfully.");
			this.log.info("MessageSender(); Queue receiver created successfully.");
			TextMessage mqReply = (TextMessage) queueReceiver
					.receive(Long.valueOf(MQCommon.getproperties("Response.Interval")));
			if (mqReply != null && !mqReply.equals("")) {
				MQCommon.maskAccNumber("MessageSender(); Reply received from MQ is : ", mqReply.toString());
				replyText = mqReply.getText();
			} else {
				logger.info("MessageSender; mqReply is null.");
				this.log.info("MessageSender; mqReply is null.");
				replyText = "";
			}
		} catch (Exception var18) {
			logger.error("MessageSender(); Exception is raised. Reason : " + var18.getLocalizedMessage() + "\nat "
					+ var18.getStackTrace()[0].toString());
			this.log.severe("MessageSender(); Exception is raised. Reason : " + var18.getLocalizedMessage() + "\nat "
					+ var18.getStackTrace()[0].toString());
		} finally {
			try {
				queueSender.close();
				queueReceiver.close();
				queueSession.close();
				this.conn.close();
				this.conn = null;
				queueReceiver = null;
				queueSender = null;
				queueSession = null;
			} catch (Exception var17) {
				logger.error("MessageSender(); Exception is raised. Reason : " + var17.getLocalizedMessage()
				+ "\nat " + var17.getStackTrace()[0].toString());
				this.log.severe("MessageSender(); Exception is raised. Reason : " + var17.getLocalizedMessage()
						+ "\nat " + var17.getStackTrace()[0].toString());
			}

		}
		logger.info("MessageSender(); Exit");
		this.log.info("MessageSender(); Exit");
		return replyText;
	}

	public TextMessage MessageSenderAck(String XML) {
		logger.info("MessageSenderAck(); Enter");
		this.log.info("MessageSenderAck(); Enter");
		TextMessage mqReply = null;
		QueueSender queueSender = null;
		QueueReceiver queueReceiver = null;
		QueueSession queueSession = null;
		Map map = null;
		MQCommon mqc = null;

		try {
			new MQCommon();
			logger.info("Creating Connection ..");
			this.log.info("Creating Connection ..");
			this.conn = this.qcf.createQueueConnection();
			this.conn.start();
			logger.info("Creating Session ..");
			logger.info("Getting Connection .." + this.conn.toString());
			this.log.info("Creating Session ..");
			this.log.info("Getting Connection .." + this.conn.toString());
			queueSession = this.conn.createQueueSession(false, 1);
			logger.info("Session created successfully.");
			logger.info("Value of vpIn_St is :" + this.vpIn_St);
			logger.info("Creating Input Queue");
			this.log.info("Session created successfully.");
			this.log.info("Value of vpIn_St is :" + this.vpIn_St);
			this.log.info("Creating Input Queue");
			this.vpIn = queueSession.createQueue("queue:///" + this.vpIn_St + "?targetClient=1");
			logger.info("Input Queue Created Successfully");
			logger.info("Value of vpOut_St is :" + this.vpOut_St);
			logger.info("Creating Output Queue");
			this.log.info("Input Queue Created Successfully");
			this.log.info("Value of vpOut_St is :" + this.vpOut_St);
			this.log.info("Creating Output Queue");
			this.vpOut = queueSession.createQueue("queue:///" + this.vpOut_St + "?targetClient=1");
			logger.info("Output Queue Created Successfully");
			logger.info("MessageSenderAck(); Value of vpIn is :" + this.vpIn.toString());
			this.log.info("Output Queue Created Successfully");
			this.log.info("MessageSenderAck(); Value of vpIn is :" + this.vpIn.toString());
			queueSender = queueSession.createSender(this.vpIn);
			logger.info("MessageSenderAck(); Creating MQ Message for sending ..");
			this.log.info("MessageSenderAck(); Creating MQ Message for sending ..");
			TextMessage msg = queueSession.createTextMessage(XML);
			queueSender.setDeliveryMode(1);
			queueSender.setTimeToLive(Long.valueOf(MQCommon.getproperties("Request.Interval")));
			queueSender.send(msg);
			logger.info("MessageSenderAck(); XML message sent");
			logger.info("MessageSenderAck(); Correlation id is : " + msg.getJMSMessageID().toString());
			this.log.info("MessageSenderAck(); XML message sent");
			this.log.info("MessageSenderAck(); Correlation id is : " + msg.getJMSMessageID().toString());
			queueReceiver = queueSession.createReceiver(this.vpOut, "JMSCorrelationID='" + msg.getJMSMessageID() + "'");
			logger.info("MessageSenderAck(); Queue receiver created successfully.");

			this.log.info("MessageSenderAck(); Queue receiver created successfully.");
			mqReply = (TextMessage) queueReceiver.receive(Long.valueOf(MQCommon.getproperties("Response.Interval")));
			logger.info("MessageSenderAck(); Reply received from MQ is : " + mqReply.toString());
			this.log.info("MessageSenderAck(); Reply received from MQ is : " + mqReply.toString());
		} catch (Exception var17) {
			logger.error("MessageSenderAck(); Exception is raised. Reason : " + var17.getLocalizedMessage() + "\nat "
					+ var17.getStackTrace()[0].toString());
			this.log.severe("MessageSenderAck(); Exception is raised. Reason : " + var17.getLocalizedMessage() + "\nat "
					+ var17.getStackTrace()[0].toString());
		} finally {
			try {
				queueSender.close();
				queueReceiver.close();
				queueSession.close();
				this.conn.close();
				this.conn = null;
				queueReceiver = null;
				queueSender = null;
				queueSession = null;
			} catch (Exception var16) {
				logger.error("MessageSenderAck(); Exception is raised. Reason : " + var16.getLocalizedMessage()
				+ "\nat " + var16.getStackTrace()[0].toString());
				this.log.severe("MessageSenderAck(); Exception is raised. Reason : " + var16.getLocalizedMessage()
						+ "\nat " + var16.getStackTrace()[0].toString());
			}

		}
		logger.info("MessageSenderAck(); Exit");
		this.log.info("MessageSenderAck(); Exit");
		return mqReply;
	}

	public void sendAck(String xml, Destination destQ) {
		logger.info("sendAck(); Enter");
		this.log.info("sendAck(); Enter");
		QueueSender queueSender = null;
		QueueSession queueSession = null;
		Map map = null;
		MQCommon mqc = null;

		try {
			new MQCommon();
			new HashMap();
			logger.info("XML received to be sent as a request to MQ is : " + xml.toString());
			logger.info("Creating Connection ..");
			this.log.info("XML received to be sent as a request to MQ is : " + xml.toString());
			this.log.info("Creating Connection ..");
			this.conn = this.qcf.createQueueConnection();
			this.conn.start();
			logger.info("Creating Session ..");
			logger.info("Getting Connection .." + this.conn.toString());
			this.log.info("Creating Session ..");
			this.log.info("Getting Connection .." + this.conn.toString());
			queueSession = this.conn.createQueueSession(false, 1);
			logger.info("Session created successfully.");
			logger.info("sendAck(); Value of Destination queue is :" + destQ.toString());
			this.log.info("Session created successfully.");
			this.log.info("sendAck(); Value of Destination queue is :" + destQ.toString());
			queueSender = queueSession.createSender((Queue) destQ);
			logger.info("sendAck(); Creating MQ Message for sending ..");
			this.log.info("sendAck(); Creating MQ Message for sending ..");
			TextMessage msg = queueSession.createTextMessage(xml);
			queueSender.setDeliveryMode(1);
			queueSender.setPriority(9);
			queueSender.setTimeToLive(Long.valueOf(MQCommon.getproperties("Request.Interval")));
			queueSender.send(msg);
			logger.info("sendAck(); XML message sent");
			this.log.info("sendAck(); XML message sent");
		} catch (Exception var16) {
			logger.error("sendAck(); Exception is raised. Reason : " + var16.getLocalizedMessage() + "\nat "
					+ var16.getStackTrace()[0].toString());
			this.log.severe("sendAck(); Exception is raised. Reason : " + var16.getLocalizedMessage() + "\nat "
					+ var16.getStackTrace()[0].toString());
		} finally {
			try {
				queueSender.close();
				queueSession.close();
				this.conn.close();
				this.conn = null;
				queueSender = null;
				queueSession = null;
			} catch (Exception var15) {
				logger.error("sendAck(); Exception is raised. Reason : " + var15.getLocalizedMessage() + "\nat "
						+ var15.getStackTrace()[0].toString());
				this.log.severe("sendAck(); Exception is raised. Reason : " + var15.getLocalizedMessage() + "\nat "
						+ var15.getStackTrace()[0].toString());
			}

		}
		logger.info("sendAck(); Exit");

		this.log.info("sendAck(); Exit");
	}
}

package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class CardNoValidationReturn 
{
	public String errorCode = emptyStr;
	public String errorDesc = emptyStr;
	public String status = emptyStr;
	public String accountNum = emptyStr;
	public String branchCode = emptyStr;
	public String primSupFlag = emptyStr;
	public String currencyName = emptyStr;
	public String currencySymbol = emptyStr;
	public String productCode= emptyStr;
	public String maskAccNum = emptyStr;
	public String powercardID = emptyStr;
	
	public String toString()
	{
		if (!(accountNum.equalsIgnoreCase(emptyStr)))
		 maskAccNum=accountNum.substring(0,4)+"******"+accountNum.substring(accountNum.length()-5,accountNum.length());
		
		String returnStr = newLine +
				resErrorCode + errorCode  + newLine +
				resErrorDesc + errorDesc  + newLine +
				resStatus + status     + newLine +
				resAccNum + maskAccNum + newLine +
				resBranchCode + branchCode + newLine +
				resPrimarySuppFlag + primSupFlag + newLine +
				resProductCode + productCode + newLine +
				resCurrencyName + currencyName + newLine +
		        resPowercardID + powercardID + newLine ;
		return returnStr;
	}
}

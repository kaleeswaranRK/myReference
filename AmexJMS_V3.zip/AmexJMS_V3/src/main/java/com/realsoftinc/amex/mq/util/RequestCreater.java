/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */

package com.realsoftinc.amex.mq.util;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;

/**
 * This class creates the XML file and with respect to the function and returns
 * the string to the respective function
 * 
 * @name ResponseParser
 * @author Purvi Lad
 * @version 1.0 Date 11 Mar 2010
 */
public class RequestCreater {
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(RequestCreater.class);

	Logger log = Utility.getLogger();
	// final static Logger log = Logger.getLogger(RequestCreater.class);

	@SuppressWarnings({ "unchecked" })
	public String XmlRequest(Map xmlMap, String func) {
		logger.info("Inside Request Creator || Function: " + func);
		log.info("Inside Request Creator || Function: " + func);
		String reqXml = emptyStr;

		String genXml = emptyStr;
		String genXml0 = emptyStr;
		String genXml1 = emptyStr;
		String genXml2 = emptyStr;
		String genXml3 = emptyStr;
		String genxml4 = emptyStr;
		String genXml5 = emptyStr;
		String genXml6 = emptyStr;

		String msgId = emptyStr;
		String sso = emptyStr;
		String cardNum = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String msgLength = emptyStr;
		String accNum = emptyStr;
		String desc1 = emptyStr;
		String revDate = emptyStr;
		String revTime = emptyStr;
		String currFlag = emptyStr;
		String lastFlag = emptyStr;
		String note = emptyStr;
		String repId = emptyStr;
		String hpr = emptyStr;
		String caseNo = emptyStr;
		String rackFlag = emptyStr;
		String errCode = emptyStr;
		String errDesc = emptyStr;
		String username = emptyStr;
		String password = emptyStr;
		String sourceApp = emptyStr;
		String uniqueId = emptyStr;
		String acctnCode = emptyStr;
		String cardSeqNo = emptyStr;
		String acctn = emptyStr;
		String pinNum = emptyStr;
		String cardExpDate = emptyStr;
		String prodID = emptyStr;
		String channelStr = emptyStr;
		String sysID = emptyStr;
		String homeNoCC = emptyStr;
		String homeNo = emptyStr;
		String workNoCC = emptyStr;
		String workNo = emptyStr;
		String mobNoCC = emptyStr;
		String mobNo = emptyStr;
		String emailID = emptyStr;
		String eStatOptFlag = emptyStr;
		String smsOptFlag = emptyStr;
		String language = emptyStr;
		String email = emptyStr;
		String campaignName = emptyStr;
		String startDate = emptyStr;
		String endDate = emptyStr;
		String campaignDetail = emptyStr;
		String uci = emptyStr;
		String firstName = emptyStr;
		String familyName = emptyStr;
		String campaignStatus = emptyStr;
		String origineFlag = emptyStr;
		String ClientCode = emptyStr;
		String LegalId = emptyStr;

		try {
			accNum = (String) xmlMap.get("AccountNumber");
			acctnCode = (String) xmlMap.get("ActionCode");
			acctn = (String) xmlMap.get("Action");
			auditSeqInStr = (String) xmlMap.get("AuditSeq");
			msgLength = (String) xmlMap.get("MessageLength");
			msgId = (String) xmlMap.get("MessageId");
			cardNum = (String) xmlMap.get("CardNumber");
			cardExpDate = (String) xmlMap.get("CardExpiryDate");
			cardSeqNo = (String) xmlMap.get("cardSeqNo");
			caseNo = (String) xmlMap.get("CaseNo");
			currFlag = (String) xmlMap.get("CurrFlag");
			dateTimeStampInStr = (String) xmlMap.get("DateTimeStamp");
			desc1 = (String) xmlMap.get("Description");
			errCode = (String) xmlMap.get("errorCode");
			errDesc = (String) xmlMap.get("errorDescription");
			hpr = (String) xmlMap.get("Hpr");
			lastFlag = (String) xmlMap.get("LastFlag");
			password = (String) xmlMap.get("password");
			pinNum = (String) xmlMap.get("PinNumber");
			note = (String) xmlMap.get("Note");
			revDate = (String) xmlMap.get("ReviewDate");
			revTime = (String) xmlMap.get("ReviewTime");
			repId = (String) xmlMap.get("RepId");
			rackFlag = (String) xmlMap.get("RackFlag");
			sso = (String) xmlMap.get("SSO");
			sourceApp = (String) xmlMap.get("sourceApp");
			uniqueId = (String) xmlMap.get("UniqueId");
			username = (String) xmlMap.get("username");
			prodID = (String) xmlMap.get("ProductId");
			channelStr = (String) xmlMap.get("Channel");
			sysID = (String) xmlMap.get("SysID");
			homeNoCC = (String) xmlMap.get("HomeNOCountryCode");
			homeNo = (String) xmlMap.get("HomeNO");
			workNoCC = (String) xmlMap.get("WorkNOCountryCode");
			workNo = (String) xmlMap.get("WorkNO");
			mobNoCC = (String) xmlMap.get("MobileNOCountryCode");
			mobNo = (String) xmlMap.get("MobileNO");
			emailID = (String) xmlMap.get("EmailID");
			eStatOptFlag = (String) xmlMap.get("EStatementOptionFlag");
			smsOptFlag = (String) xmlMap.get("SMSOptionFlag");
			language = (String) xmlMap.get("Language");
			email = (String) xmlMap.get("Email");
			campaignName = (String) xmlMap.get("CampaignName");
			startDate = (String) xmlMap.get("StartDate");
			endDate = (String) xmlMap.get("EndDate");
			campaignDetail = (String) xmlMap.get("CampaignDetail");
			uci = (String) xmlMap.get("UCI");
			firstName = (String) xmlMap.get("FirstName");
			familyName = (String) xmlMap.get("FamilyName");
			campaignStatus = (String) xmlMap.get("CampaignStatus");
			origineFlag = (String) xmlMap.get("OrigineFlag");
			ClientCode = (String) xmlMap.get("ClientCode");
			LegalId = (String) xmlMap.get("LegalId");

			// Creating General XML - genXml
			StringBuffer msgString = new StringBuffer();

			msgString.append(msgId_s).append(msgId).append(msgId_e).append(audSeq_s).append(auditSeqInStr)
					.append(audSeq_e).append(dateTimeStamp_s).append(dateTimeStampInStr).append(dateTimeStamp_e)
					.append(accNo_s).append(accNum).append(accNo_e).append(sysID_s).append(sysID).append(sysID_e);

			genXml = msgString.toString();

			// log.info("XmlRequest(); Function is " + func );

			// Creating General XML - genXml0
			StringBuffer msgString0 = new StringBuffer();

			msgString0.append(msgId_s).append(msgId).append(msgId_e).append(desc_s).append(desc1).append(desc_e)
					.append(audSeq_s).append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s)
					.append(dateTimeStampInStr).append(dateTimeStamp_e).append(cardNo_s).append(cardNum)
					.append(cardNo_e);

			genXml0 = msgString0.toString();

			// Creating General XML - genXml1
			StringBuffer msgString1 = new StringBuffer();

			msgString1.append(len_s).append(msgLength).append(len_e).append(msgId_s).append(msgId).append(msgId_e)
					.append(audSeq_s).append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s)
					.append(dateTimeStampInStr).append(dateTimeStamp_e).append(accNo_s).append(accNum).append(accNo_e)
					.append(sso_s).append(sso).append(sso_e);

			genXml1 = msgString1.toString();

			// Creating General XML - genXml2
			StringBuffer msgString2 = new StringBuffer();

			msgString2.append(len_s).append(msgLength).append(len_e).append(msgId_s).append(msgId).append(msgId_e)
					.append(audSeq_s).append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s)
					.append(dateTimeStampInStr).append(dateTimeStamp_e);

			genXml2 = msgString2.toString();

			// Creating General XML - genXml3
			StringBuffer msgString3 = new StringBuffer();

			msgString3.append(eaiHead_s).append(msgId_s).append(msgId).append(msgId_e).append(desc_s).append(desc1)
					.append(desc_e).append(eaiHead_e);

			genXml3 = msgString3.toString();

			// Creating General XML - genXml4
			StringBuffer msgString4 = new StringBuffer();

			msgString4.append(xmlHead).append(msg_s).append(msgId_s).append(msgId).append(msgId_e).append(msgTyp)
					.append(sessionId).append(checkSum).append(clientIP).append(accNo_s).append(accNum).append(accNo_e)
					.append(sourceApp_s).append(sourceApp).append(sourceApp_e).append(user1).append(user2).append(user3)
					.append(user4).append(user5).append(msg_e);

			genxml4 = msgString4.toString();

			// Creating General XML - genXml5
			StringBuffer msgString5 = new StringBuffer();

			msgString5.append(msgId_s).append(msgId).append(msgId_e).append(audSeq_s).append(auditSeqInStr)
					.append(audSeq_e).append(dateTimeStamp_s).append(dateTimeStampInStr).append(dateTimeStamp_e)
					.append(accNo_s).append(cardNum).append(accNo_e).append(sysID_s).append(sysID).append(sysID_e);

			genXml5 = msgString5.toString();

			// log.info("XmlRequest(); Function is " + func );

			// Creating General XML - genXml6
			StringBuffer msgString6 = new StringBuffer();

			msgString6.append(msgId_s).append(msgId).append(msgId_e).append(dateTimeStamp_s).append(dateTimeStampInStr)
					.append(dateTimeStamp_e).append(sysID_s).append(sysID).append(sysID_e).append(accNo_s)
					.append(cardNum).append(accNo_e);

			genXml6 = msgString6.toString();

			// log.info("XmlRequest(); Function is " + func );

			// Creating XML according to the function Name
			if (func.equalsIgnoreCase("LoginRequest")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func );

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(eaiReq_s).append(eaiHead_s).append(msgId_s).append(msgId).append(msgId_e)
						.append(desc_s).append(desc1).append(desc_e).append(eaiHead_e).append(eaiBody_s)
						.append(msgReq_s).append(genXml2).append(user_s).append(username).append(user_e)
						.append(msgReq_e).append(eaiBody_e).append(eaiReq_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("CardNoValidation")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func );

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(genXml5).append(msgReq_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("CheckCSIEnrolled")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func );

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(len_s).append(msgLength).append(len_e).append(msgId_s)
						.append(msgId).append(msgId_e).append(audSeq_s).append(auditSeqInStr).append(audSeq_e)
						.append(dateTimeStamp_s).append(dateTimeStampInStr).append(dateTimeStamp_e).append(accNo_s)
						.append(accNum).append(accNo_e).append(prodID_s).append(prodID).append(prodID_e).append(sso_s)
						.append(sso).append(sso_e).append(usrName_s).append(username).append(usrName_e)
						.append(msgReq_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("ConfirmeCSIEnrollment")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func );

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(len_s).append(msgLength).append(len_e).append(msgId_s)
						.append(msgId).append(msgId_e).append(audSeq_s).append(auditSeqInStr).append(audSeq_e)
						.append(dateTimeStamp_s).append(dateTimeStampInStr).append(dateTimeStamp_e).append(accNo_s)
						.append(accNum).append(accNo_e).append(prodID_s).append(prodID).append(prodID_e)
						.append(channel_s).append(channelStr).append(channel_e).append(sso_s).append(sso).append(sso_e)
						.append(usrName_s).append(username).append(usrName_e).append(msgReq_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("DateOfBirthValidation")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func);

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(eaiReq_s).append(genXml3).append(eaiBody_s).append(msgReq_s)
						.append(genXml1).append(msgReq_e).append(eaiBody_e).append(eaiReq_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("CardActivation")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func );

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(eaiReq_s).append(genXml3).append(eaiBody_s).append(msgReq_s)
						.append(genXml2).append(accNo_s).append(accNum).append(accNo_e).append(actCode_s).append("ACTV")
						.append(actCode_e).append(revDate_s).append(revDate).append(revDate_e).append(revTime_s)
						.append(revTime).append(revTime_e).append(cardSeqNo_s).append(1).append(cardSeqNo_e)
						.append(cardNo_s).append(cardNum).append(cardNo_e).append(currFlag_s).append(currFlag)
						.append(currFlag_e).append(lasFlag_s).append(lastFlag).append(lasFlag_e).append(note_s)
						.append(note).append(note_e).append(repId_s).append(repId).append(repId_e).append(hpr_s)
						.append(hpr).append(hpr_e).append(caseNo_s).append(caseNo).append(caseNo_e).append(sso_s)
						.append(sso).append(sso_e).append(msgReq_e).append(rackFlag_s).append(rackFlag)
						.append(rackFlag_e).append(eaiBody_e).append(eaiReq_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("CardActivation_Ack")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func );

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(eaiRes_s).append(genXml3).append(eaiBody_s).append(msgRes_s)
						.append(respCode_s).append(errCode).append(respCode_e).append(respDesc_s).append(errDesc)
						.append(respDesc_e).append(msgRes_e).append(eaiBody_e).append(eaiRes_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("AccountBalance")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func);

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(genXml).append(msgReq_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("ContactDetails")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func);

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(genXml).append(msgReq_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("MREnrollment")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func);

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(eaiReq_s).append(genXml3).append(eaiBody_s).append(msgReq_s)
						.append(cardNum_s).append(cardNum).append(cardNum_e).append(msgReq_e).append(eaiBody_e)
						.append(eaiReq_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("SendMail")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func);

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(eaiReq_s).append(genXml3).append(eaiBody_s).append(msgReq_s).append(lang_s)
						.append(language).append(lang_e).append(email_s).append(email).append(email_e).append(msgReq_e)
						.append(eaiBody_e).append(eaiReq_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("EmbosserDetail")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func );

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(genXml6).append(msgReq_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("PaymentHistory")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func);

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(genXml).append(msgReq_e);
				// func1.append(xmlHead).append(msg_s).append(msgId_s).append("2005").append(msgId_e).append(audSeq_s).append(auditSeqInStr).append(audSeq_e).
				// append(dateTimeStamp_s).append(dateTimeStampInStr).append(dateTimeStamp_e).append(accNo_s).append(accNum).append(accNo_e).
				// append(sso_s).append(sso).append(sso_e).append(usrName_s).append(username).append(usrName_e).append(pwd_s).append(emptyStr).append(pwd_e).append(msg_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("CurrencyCode")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func);

				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(eaiReq_s).append(genXml3).append(eaiBody_s).append(msgReq_s)
						.append(genXml2).append(cardNo_s).append(cardNum).append(cardNo_e).append(msgReq_e)
						.append(rackFlag_s).append(rackFlag).append(rackFlag_e).append(usrName_s).append(username)
						.append(usrName_e).append(pwd_s).append(emptyStr).append(pwd_e).append(eaiBody_e)
						.append(eaiReq_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("ChargeCardNoValidation")) {
				reqXml = genxml4;
			} else if (func.equalsIgnoreCase("ChargeCardDueDate")) {
				reqXml = genxml4;
			} else if (func.equalsIgnoreCase("ChargeCardAccountBalance")) {
				reqXml = genxml4;
			} else if (func.equalsIgnoreCase("UniqueId")) {
				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(eaiReq_s).append(genXml3).append(eaiBody_s).append(msgReq_s).append(len_s)
						.append(msgLength).append(len_e).append(msgId_s).append(msgId).append(msgId_e).append(audSeq_s)
						.append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s).append(dateTimeStampInStr)
						.append(dateTimeStamp_e).append(uniqId_s).append(uniqueId).append(uniqId_e).append(dob_s)
						.append(dob_e).append(mob_s).append(mob_e).append(cprno_s).append(cprno_e).append(sso_s)
						.append(sso).append(sso_e).append(msgReq_e).append(rackFlag_s).append(rackFlag)
						.append(rackFlag_e).append(usrName_s).append(username).append(usrName_e).append(pwd_s)
						.append(password).append(pwd_e).append(eaiBody_e).append(eaiReq_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("PinSetup")) {
				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(eaiReq_s).append(genXml3).append(eaiBody_s).append(msgReq_s).append(len_s)
						.append(msgLength).append(len_e).append(msgId_s).append(msgId).append(msgId_e).append(audSeq_s)
						.append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s).append(dateTimeStampInStr)
						.append(dateTimeStamp_e).append(accNo_s).append(accNum).append(accNo_e).append(actCode_s)
						.append(acctnCode).append(actCode_e).append(revDate_s).append(revDate).append(revDate_e)
						.append(revTime_s).append(revTime).append(revTime_e).append(cardSqNo_s).append(cardSeqNo)
						.append(cardSqNo_e).append(cardNo_s).append(cardNum).append(cardNo_e).append(act_s)
						.append(acctn).append(act_e).append(note_s).append(note).append(note_e).append(repId_s)
						.append(repId).append(repId_e).append(hpr_s).append(hpr).append(hpr_e).append(caseNo_s)
						.append(caseNo).append(caseNo_e).append(pinNo_s).append(pinNum).append(pinNo_e).append(sso_s)
						.append(sso).append(sso_e).append(msgReq_e).append(rackFlag_s).append(rackFlag)
						.append(rackFlag_e).append(usrName_s).append(username).append(usrName_e).append(pwd_s)
						.append(password).append(pwd_e).append(eaiBody_e).append(eaiReq_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("UpdateConDet")) {
				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(genXml0).append(homeNoCC_s).append(homeNoCC)
						.append(homeNoCC_e).append(homeNo_s).append(homeNo).append(homeNo_e).append(mobNoCC_s)
						.append(mobNoCC).append(mobNoCC_e).append(mobNo_s).append(mobNo).append(mobNo_e)
						.append(workNoCC_s).append(workNoCC).append(workNoCC_e).append(workNo_s).append(workNo)
						.append(workNo_e).append(emailID_s).append(emailID).append(emailID_e).append(smsOptFlag_s)
						.append(smsOptFlag).append(smsOptFlag_e).append(eStatOptFlag_s).append(eStatOptFlag)
						.append(eStatOptFlag_e).append(rackFlag_s).append(rackFlag).append(rackFlag_e).append(usrName_s)
						.append(username).append(usrName_e).append(msgReq_e);

				reqXml = func1.toString();
			}

			else if (func.equalsIgnoreCase("PinSetup_Ack")) {
				// log.info("XmlRequest(); Creating XML string for function : " + func );
				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(eaiRes_s).append(genXml3).append(eaiBody_s).append(msgRes_s)
						.append(respCode_s).append(errCode).append(respCode_e).append(respDesc_s).append(errDesc)
						.append(respDesc_e).append(msgRes_e).append(eaiBody_e).append(eaiRes_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("PinUnblock")) {
				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(eaiReq_s).append(genXml3).append(eaiBody_s).append(msgReq_s).append(len_s)
						.append(msgLength).append(len_e).append(msgId_s).append(msgId).append(msgId_e).append(audSeq_s)
						.append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s).append(dateTimeStampInStr)
						.append(dateTimeStamp_e).append(cardNo_s).append(cardNum).append(cardNo_e).append(cardExpDt_s)
						.append(cardExpDate).append(cardExpDt_e).append(sso_s).append(sso).append(sso_e)
						.append(msgReq_e).append(rackFlag_s).append(rackFlag).append(rackFlag_e).append(usrName_s)
						.append(username).append(usrName_e).append(pwd_s).append(password).append(pwd_e)
						.append(eaiBody_e).append(eaiReq_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("CardList")) {
				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(msgId_s).append(msgId).append(msgId_e).append(audSeq_s)
						.append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s).append(dateTimeStampInStr)
						.append(dateTimeStamp_e).append(sysID_s).append(sysID).append(sysID_e).append(firstName_s)
						.append(firstName).append(firstName_e).append(familyName_s).append(familyName)
						.append(familyName_e).append(clientCode_s).append(ClientCode).append(clientCode_e)
						.append(cardNo_s).append(cardNum).append(cardNo_e).append(uci_s).append(uci_e).append(dob_s)
						.append(dob_e).append(email_s).append(email_e).append(legal_s).append(LegalId).append(legal_e)
						.append(mobNumb_s).append(mobNo).append(mobNumb_e).append(msgReq_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("CardDetails")) {
				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(msgId_s).append(msgId).append(msgId_e).append(audSeq_s)
						.append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s).append(dateTimeStampInStr)
						.append(dateTimeStamp_e).append(sysID_s).append(sysID).append(sysID_e).append(cardNo_s)
						.append(cardNum).append(cardNo_e).append(uci_s).append(uci).append(uci_e).append(msgReq_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("AccountDetail")) {
				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(msgId_s).append(msgId).append(msgId_e).append(audSeq_s)
						.append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s).append(dateTimeStampInStr)
						.append(dateTimeStamp_e).append(sysID_s).append(sysID).append(sysID_e).append(accNo_s)
						.append(accNum).append(accNo_e).append(msgReq_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("AccountOffers")) {
				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(msgId_s).append(msgId).append(msgId_e).append(audSeq_s)
						.append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s).append(dateTimeStampInStr)
						.append(dateTimeStamp_e).append(sysID_s).append("IVR").append(sysID_e).append(accNo_s)
						.append(accNum).append(accNo_e).append(campaignName_s).append(campaignName)
						.append(campaignName_e).append(startDate_s).append(startDate).append(startDate_e)
						.append(endDate_s).append(endDate).append(endDate_e).append(campaignDetail_s)
						.append(campaignDetail).append(campaignDetail_e).append(campaignStatus_s).append(campaignStatus)
						.append(campaignStatus_e).append(origineFlag_s).append(origineFlag).append(origineFlag_e)
						.append(msgReq_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("PinMailer")) {
				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(msgId_s).append(msgId).append(msgId_e).append(audSeq_s)
						.append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s).append(dateTimeStampInStr)
						.append(dateTimeStamp_e).append(sysID_s).append(sysID).append(sysID_e).append(accNo_s)
						.append(accNum).append(accNo_e).append(ctiUser_s).append(ctiUser_e).append(caseReasonCode_s)
						.append(caseReasonCode_e).append(revDate_s).append(revDate_e).append(revTime_s)
						.append(revTime_e).append(cardSqNo_s).append("1").append(cardSqNo_e).append(cardNo_s)
						.append(cardNum).append(cardNo_e).append(note_s).append(note_e).append(representativeId_s)
						.append(representativeId_e).append(holdProcessRefer_s).append(holdProcessRefer_e)
						.append(caseNumber_s).append(caseNumber_e).append(msgReq_e);

				reqXml = func1.toString();
			} else if (func.equalsIgnoreCase("GetClientCode")) {
				StringBuffer func1 = new StringBuffer();

				func1.append(xmlHead).append(msgReq_s).append(msgId_s).append(msgId).append(msgId_e).append(audSeq_s)
						.append(auditSeqInStr).append(audSeq_e).append(dateTimeStamp_s).append(dateTimeStampInStr)
						.append(dateTimeStamp_e).append(mobNumb_s).append(mobNo).append(mobNumb_e).append(msgReq_e);

				reqXml = func1.toString();
			}

			else {
				// log.info("XmlRequest(); Function name is invalid.");
				reqXml = emptyStr;
			}

		} catch (Exception e) {
			logger.error("XmlRequest(); Exception is raised. Reason : " +e);
			
					
			// log.severe("XmlRequest(); Exception is raised. Reason : " +
			// e.getStackTrace());
		}
		// log.info("XmlRequest(); Exit");
		return reqXml;
	}
}

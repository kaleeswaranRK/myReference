/*
* (C) Copyright 2013 Geomant Kft. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

import com.realsoftinc.amex.mq.returnObjs.SendMailReturn;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function Send Mail
 * 
 * @author Marijana Dujovic / Geomant Kft.
 */

public class SendMail {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(SendMail.class);

	@SuppressWarnings({ "unchecked" })
	public SendMailReturn sendMailAttachment(String language, String emailAddress) {
		logger.info("sendMailAttachment(); Send Mail function is called by IVR .. ");
		logger.info("sendMailAttachment(); Enter ");
		log.info("sendMailAttachment(); Send Mail function is called by IVR .. ");
		log.info("sendMailAttachment(); Enter ");

		Map<String, String> xmlMap = null;
		MQCommon mqc = null;
		RequestCreater rc = null;
		RequestResponse rr = null;

		ResponseParser respParser = null;
		SendMailReturn sendMailRtn = null;
		Map<String, String> map = null;

		String replyMsg = emptyStr;
		String xmlReq = emptyStr;

//		@SuppressWarnings("unused")
		String errorDescription = emptyStr;

		try {
			xmlMap = new HashMap<String, String>();

			mqc = new MQCommon();
			rc = new RequestCreater();
			rr = new RequestResponse();
			respParser = new ResponseParser();
			sendMailRtn = new SendMailReturn();

			/*
			 * if(CardNum.length() == 15){ //maskAccNum =
			 * AccNum.replace(AccNum.subSequence(4, AccNum.length()-5),maskString2);
			 * maskCardNum=CardNum.substring(0,4)+"******"+CardNum.substring(CardNum.length(
			 * )-5,CardNum.length()); log.info("sendMREnrollment(); Card Number is : " +
			 * maskCardNum); } else{
			 * log.info("sendMREnrollment(); Card Number is less than 12 digits."); }
			 * 
			 * log.info("getPaymentHistory(); Calling the getDateTime function ..");
			 * dateTimeStampInStr = mqc.getDateTime();
			 * log.info("getPaymentHistory(); DateTimeStamp is : " + dateTimeStampInStr);
			 * 
			 * log.info("getPaymentHistory(); Calling the getAuditSequence function ..");
			 * auditSeqInStr = mqc.getAuditSequence();
			 * log.info("getPaymentHistory(); Audit Sequence is : " + auditSeqInStr);
			 */
			logger.info("sendMailAttachment(); Created all the required parameters to prepare the xml ..");

			log.info("sendMailAttachment(); Created all the required parameters to prepare the xml ..");
			// xmlMap.put("CardNumber", CardNum);
			// xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			// xmlMap.put("AuditSeq", auditSeqInStr);

			// xmlMap.put("MessageLength", mqc.getproperties("PaymentHistory.MsgLength"));
			xmlMap.put("MessageId", MsgId_SendMail);
			xmlMap.put("Description", SendMail_Desc);
			xmlMap.put("Language", language);
			xmlMap.put("Email", emailAddress);
			// xmlMap.put("SysID", mqc.getproperties("PaymentHistory.SysID"));

			logger.info("sendMailAttachment(); Sending values to form proper form of xml request .. ");

			log.info("sendMailAttachment(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "SendMail");
			logger.info("sendMailAttachment(); Received xml in proper format ..");

			log.info("sendMailAttachment(); Received xml in proper format ..");

			// Added to encrypt account number when display request in log file
			MQCommon.maskAccNumber("sendMailAttachment(); XML is : ", xmlReq);
			logger.info("sendMailAttachment(); Sending the prepared xml to MQ .. ");

			log.info("sendMailAttachment(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("sendMailAttachment(); Response received from MQ .. ");
			logger.info("sendMailAttachment(); Received response from MQ is : " + replyMsg);

			log.info("sendMailAttachment(); Response received from MQ .. ");
			log.info("sendMailAttachment(); Received response from MQ is : " + replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("sendMailAttachment(); Sending the received response from MQ to the parser ..");

				log.info("sendMailAttachment(); Sending the received response from MQ to the parser ..");
				// log.info("getPaymentHistory(); XML sent for parsing is :"+ replyMsg);
				map = respParser.XmlParser(replyMsg);

				sendMailRtn.errorCode = (String) map.get("errCode");
				sendMailRtn.errorDesc = (String) map.get("errorMsg");

				if (sendMailRtn.errorCode.equalsIgnoreCase("0") || sendMailRtn.errorCode.equalsIgnoreCase("00")
						|| sendMailRtn.errorCode.equalsIgnoreCase("000")
						|| sendMailRtn.errorCode.equalsIgnoreCase("0000")) {
					logger.info("sendMailAttachment(); Response from MQ is 'SUCCESS'.. ");

					log.info("sendMailAttachment(); Response from MQ is 'SUCCESS'.. ");

				} else {
					logger.info("sendMailAttachment(); Response from MQ is 'FAILURE'.. ");

					log.info("sendMailAttachment(); Response from MQ is 'FAILURE'.. ");
					// payHistRtn.status = invalidStr;
				}

			} else {
				logger.info("sendMailAttachment(); Since the response from MQ is not proper .. ");
				logger.info("sendMailAttachment(); Setting error values.");
				log.info("sendMailAttachment(); Since the response from MQ is not proper .. ");
				log.info("sendMailAttachment(); Setting error values.");
				sendMailRtn.errorCode = MQConstants.errorCode;
				sendMailRtn.errorDesc = errorDesc;
				// payHistRtn.status = invalidStr;
			}
		} catch (Exception e) {
			logger.info("sendMailAttachment(); Exception is raised." + e.toString());

			log.info("sendMailAttachment(); Exception is raised." + e.toString());

			sendMailRtn.errorCode = MQConstants.errorCode;
			sendMailRtn.errorDesc = errorDesc;
			// payHistRtn.status = invalidStr;
			logger.error("sendMailAttachment(); Reason : " + e.getStackTrace());

			log.severe("sendMailAttachment(); Reason : " + e.getStackTrace());
		} finally {
			xmlMap = null;
			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			map = null;

			replyMsg = emptyStr;
			xmlReq = emptyStr;

			errorDescription = emptyStr;

		}
		logger.info("sendMailAttachment(); Response is returned to the IVR. Response : " + sendMailRtn.toString());
		logger.info("sendMailAttachment(); Exit");
		log.info("sendMailAttachment(); Response is returned to the IVR. Response : " + sendMailRtn.toString());
		log.info("sendMailAttachment(); Exit");
		return sendMailRtn;
	}
}
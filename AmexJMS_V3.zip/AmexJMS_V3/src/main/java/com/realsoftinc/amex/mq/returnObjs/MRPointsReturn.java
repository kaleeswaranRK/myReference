package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class MRPointsReturn 
{
	public String errorCode = emptyStr;
	public String errorDesc = emptyStr;	
	public MRInformation mrInfo= null;
	
	public String maskAccNum = emptyStr;
	

	public String toString()
	{
		//if (!(accountNum.equalsIgnoreCase(emptyStr)))
		// maskAccNum=accountNum.substring(0,4)+"******"+accountNum.substring(accountNum.length()-5,accountNum.length());
		
		String returnStr = emptyStr;
		if(mrInfo != null)
		{
		returnStr = newLine +
		   resAdjPoints + mrInfo.adjustedPoints    + newLine +
		   resAvailPoints + mrInfo.availablePoints        + newLine +
		   resBonusPoints + mrInfo.bonusPoints  + newLine +
		   resClosingBalance + mrInfo.closingBalance   + newLine +
		   resEarnedPoints + mrInfo.earnedPoints       + newLine +
		   resMembId + mrInfo.memberId     + newLine +
		   resOpenBalance + mrInfo.pointsOpeningBalance               + newLine +
		   resPrevBalance + mrInfo.previousBalance      + newLine +			
		   resReedemedPoints + mrInfo.redeemedPoints           + newLine +
		   resErrorCode + errorCode  + newLine +
		   resErrorDesc + errorDesc  + newLine ;
		
		}
		else
		{
			returnStr = newLine +
			resErrorCode + errorCode                 + newLine +
			resErrorDesc + errorDesc          + newLine;
			
		}	
		return returnStr;
	}
}

package com.realsoftinc.amex.mq.functions;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.AccountOffersReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

public class AccountOffers {

	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(AccountOffers.class);

	Logger log = Utility.getLogger();

	@SuppressWarnings({ "static-access", "unchecked" })
	public AccountOffersReturn accountOffers(String accNum, String campaignName, String startDate, String endDate, String campaignDetail, String campaignStatus, String origineFlag) {

		log.info("accountOffers(); Account Offers function is called by IVR .. ");
		log.info("accountOffers(); Enter ");
		log.info("accountOffers(); Input From IVR | CAMPAIGNNAME: "+campaignName);
		log.info("accountOffers(); Input From IVR | STARTDATE: "+startDate);
		log.info("accountOffers(); Input From IVR | ENDDATE: "+endDate);
		log.info("accountOffers(); Input From IVR | CAMPAIGNDETAIL: "+campaignDetail);
		log.info("accountOffers(); Input From IVR | CAMPAIGNSTATUS: "+campaignStatus);
		logger.info("accountOffers(); Account Offers function is called by IVR .. ");
		logger.info("accountOffers(); Enter ");
		logger.info("accountOffers(); Input From IVR | CAMPAIGNNAME: "+campaignName);
		logger.info("accountOffers(); Input From IVR | STARTDATE: "+startDate);
		logger.info("accountOffers(); Input From IVR | ENDDATE: "+endDate);
		logger.info("accountOffers(); Input From IVR | CAMPAIGNDETAIL: "+campaignDetail);
		logger.info("accountOffers(); Input From IVR | CAMPAIGNSTATUS: "+campaignStatus);
		
		MQCommon mqc = new MQCommon();

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		//String dateTimeStampOutStr = emptyStr;
		//String auditSeqOutStr = emptyStr;
		//String accountNum = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String maskAccNum = emptyStr;

		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;
		AccountOffersReturn acctDetRtn = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		try {
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			acctDetRtn = new AccountOffersReturn();
			respParser = new ResponseParser();
			logger.info("accountOffers(); Calling the getDateTime function ..");

			log.info("accountOffers(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("accountOffers(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("accountOffers(); Calling the getAuditSequence function ..");
			log.info("accountOffers(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("accountOffers(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("accountOffers(); Audit Sequence is : " + auditSeqInStr);
			log.info("accountOffers(); Audit Sequence is : " + auditSeqInStr);
			
			if(accNum.length() == 12){
				maskAccNum=accNum.substring(0,4)+"******"+accNum.substring(accNum.length()-5,accNum.length());
				logger.info("accountOffers(); Account Number is : " + maskAccNum);

				log.info("accountOffers(); Account Number is : " + maskAccNum);
				}
				else{
					logger.info("accountOffers(); Account Number is less than 12 digits.");

					log.info("accountOffers(); Account Number is less than 12 digits.");
				}
			logger.info("accountOffers(); Created all the required parameters to prepare the xml ..");

			log.info("accountOffers(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("AccountNumber", accNum);
			xmlMap.put("CampaignName", campaignName);
			xmlMap.put("StartDate", startDate);
			xmlMap.put("EndDate", endDate);
			xmlMap.put("CampaignDetail", campaignDetail);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("MessageId", MsgId_AccountOffers);
			xmlMap.put("CampaignStatus",campaignStatus);
			xmlMap.put("OrigineFlag",origineFlag);
			
			logger.info("accountOffers(); Sending values to form proper format of xml request .. ");

			log.info("accountOffers(); Sending values to form proper format of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "AccountOffers");
			logger.info("accountOffers(); Received xml in proper format ..");

			log.info("accountOffers(); Received xml in proper format ..");
			MQCommon.maskAccNumber("accountOffers(); XML is : ", xmlReq);
			logger.info("accountOffers(); Sending the prepared xml to MQ .. ");

			log.info("accountOffers(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("accountOffers(); Response received from MQ .. ");

			log.info("accountOffers(); Response received from MQ .. ");
			MQCommon.maskAccNumber("accountOffers(); Received response from MQ is : ", replyMsg);
			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("accountOffers(); Sending the received response from MQ to the parser ..");

				log.info("accountOffers(); Sending the received response from MQ to the parser ..");
				// log.info("accountOffers(); XML sent for parsing is :"+ replyMsg);
				map = respParser.XmlParser(replyMsg);
				logger.info("accountOffers(); Received Hash map after parsing of response.");

				log.info("accountOffers(); Received Hash map after parsing of response.");

				acctDetRtn.errorCode = (String) map.get("errCode");
				acctDetRtn.errorDesc = (String) map.get("errDesc");

				if (acctDetRtn.errorCode.equalsIgnoreCase("0") 
						|| acctDetRtn.errorCode.equalsIgnoreCase("00")
						|| acctDetRtn.errorCode.equalsIgnoreCase("000")
						|| acctDetRtn.errorCode.equalsIgnoreCase("0000")) {
					logger.info("accountOffers(); Response from MQ is 'SUCCESS'.. ");

					log.info("accountOffers(); Response from MQ is 'SUCCESS'.. ");

					if ((String) map.get("msgIdActualStr")!= null) {
						acctDetRtn.msgId = (String) map.get("msgIdActualStr");
					}
					if ((String) map.get("dateTimeStampStr")!= null) {
						acctDetRtn.dateTimeStampOutStr = (String) map.get("dateTimeStampStr");
					}
					if ((String) map.get("auditSeqStr")!= null) {
						acctDetRtn.auditSeqOutStr = (String) map.get("auditSeqStr");
					}
					if ((String) map.get("description")!= null) {
						acctDetRtn.description = (String) map.get("description");
					}
					acctDetRtn.status = validStr;

				} else {
					logger.info("accountOffers(); Response from MQ is 'FAILURE'.. ");

					log.info("accountOffers(); Response from MQ is 'FAILURE'.. ");
					acctDetRtn.status = invalidStr;
				}

			} else {
				logger.info("accountOffers(); Since the response from MQ is not proper .. ");
				logger.info("accountOffers(); Setting error values.");
				log.info("accountOffers(); Since the response from MQ is not proper .. ");
				log.info("accountOffers(); Setting error values.");
				acctDetRtn.errorCode = errorCode;
				acctDetRtn.errorDesc = errorDesc;
				acctDetRtn.status = invalidStr;
			}

		} catch (Exception e) {
			log.info("accountOffers(); Exception is raised." + e.toString());
			logger.info("accountOffers(); Exception is raised." + e.toString());

			acctDetRtn.errorCode = errorCode;
			acctDetRtn.errorDesc = errorDesc;
			acctDetRtn.status = invalidStr;
			logger.error("accountOffers(); Reason : "+ e.getStackTrace());

			log.severe("accountOffers(); Reason : "+ e.getStackTrace());

		} finally {
			xmlReq = emptyStr;
			replyMsg = emptyStr;
			//dateTimeStampOutStr = emptyStr;
			//auditSeqOutStr = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			//	maskAccNum = emptyStr;

			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			xmlMap = null;
			map = null;
		}
		logger.info("accountOffers(); Response is returned to the IVR. Response : " + acctDetRtn.toString());
		logger.info("accountOffers(); Exit ");
		log.info("accountOffers(); Response is returned to the IVR. Response : " + acctDetRtn.toString());
		log.info("accountOffers(); Exit ");
		return acctDetRtn;
	}



}

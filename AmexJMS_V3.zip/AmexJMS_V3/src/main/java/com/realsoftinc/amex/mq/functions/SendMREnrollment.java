/*
* (C) Copyright 2013 Geomant Kft. 
* All rights reserved. 
* 
*/

package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
import com.realsoftinc.amex.mq.returnObjs.MREnrollmentReturn;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function SendMREnrollment
 * 
 * @author Marijana Dujovic / Geomant Kft.
 */

public class SendMREnrollment {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(SendMREnrollment.class);

	@SuppressWarnings({ "unchecked" })
	public MREnrollmentReturn sendMREnrollment(String CardNum) {
		logger.info("sendMREnrollment(); Send MR Enrollment function is called by IVR .. ");
		logger.info("sendMREnrollment(); Enter ");
		log.info("sendMREnrollment(); Send MR Enrollment function is called by IVR .. ");
		log.info("sendMREnrollment(); Enter ");

		Map<String, String> xmlMap = null;
		MQCommon mqc = null;
		RequestCreater rc = null;
		RequestResponse rr = null;

		ResponseParser respParser = null;
		MREnrollmentReturn mrEnrolRtn = null;
		Map<String, String> map = null;

		String replyMsg = emptyStr;
		String xmlReq = emptyStr;

//		@SuppressWarnings("unused")
		String errorDescription = emptyStr;

		String maskCardNum = emptyStr;

		try {
			xmlMap = new HashMap<String, String>();

			mqc = new MQCommon();
			rc = new RequestCreater();
			rr = new RequestResponse();
			respParser = new ResponseParser();
			mrEnrolRtn = new MREnrollmentReturn();

			if (CardNum.length() == 15) {
				// maskAccNum = AccNum.replace(AccNum.subSequence(4,
				// AccNum.length()-5),maskString2);
				maskCardNum = CardNum.substring(0, 4) + "******"
						+ CardNum.substring(CardNum.length() - 5, CardNum.length());
				logger.info("sendMREnrollment(); Card Number is : " + maskCardNum);

				log.info("sendMREnrollment(); Card Number is : " + maskCardNum);
			} else {
				logger.info("sendMREnrollment(); Card Number is less than 12 digits.");

				log.info("sendMREnrollment(); Card Number is less than 12 digits.");
			}

			/*
			 * log.info("getPaymentHistory(); Calling the getDateTime function ..");
			 * dateTimeStampInStr = mqc.getDateTime();
			 * log.info("getPaymentHistory(); DateTimeStamp is : " + dateTimeStampInStr);
			 * 
			 * log.info("getPaymentHistory(); Calling the getAuditSequence function ..");
			 * auditSeqInStr = mqc.getAuditSequence();
			 * log.info("getPaymentHistory(); Audit Sequence is : " + auditSeqInStr);
			 */
			logger.info("sendMREnrollment(); Created all the required parameters to prepare the xml ..");

			log.info("sendMREnrollment(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("CardNumber", CardNum);
			// xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			// xmlMap.put("AuditSeq", auditSeqInStr);

			// xmlMap.put("MessageLength", mqc.getproperties("PaymentHistory.MsgLength"));
			xmlMap.put("MessageId", MsgId_MREnrollment);
			xmlMap.put("Description", MREnrollment_Desc);
			// xmlMap.put("SysID", mqc.getproperties("PaymentHistory.SysID"));

			logger.info("sendMREnrollment(); Sending values to form proper form of xml request .. ");

			log.info("sendMREnrollment(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "MREnrollment");
			logger.info("sendMREnrollment(); Received xml in proper format ..");

			log.info("sendMREnrollment(); Received xml in proper format ..");

			// Added to encrypt account number when display request in log file
			MQCommon.maskAccNumber("sendMREnrollment(); XML is : ", xmlReq);
			logger.info("sendMREnrollment(); Sending the prepared xml to MQ .. ");

			log.info("sendMREnrollment(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("sendMREnrollment(); Response received from MQ .. ");
			logger.info("sendMREnrollment(); Received response from MQ is : " + replyMsg);
			log.info("sendMREnrollment(); Response received from MQ .. ");
			log.info("sendMREnrollment(); Received response from MQ is : " + replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("sendMREnrollment(); Sending the received response from MQ to the parser ..");

				log.info("sendMREnrollment(); Sending the received response from MQ to the parser ..");
				// log.info("getPaymentHistory(); XML sent for parsing is :"+ replyMsg);
				map = respParser.XmlParser(replyMsg);

				mrEnrolRtn.errorCode = (String) map.get("errCode");
				mrEnrolRtn.errorDesc = (String) map.get("errorMsg");

				if (mrEnrolRtn.errorCode.equalsIgnoreCase("0") || mrEnrolRtn.errorCode.equalsIgnoreCase("00")
						|| mrEnrolRtn.errorCode.equalsIgnoreCase("000")
						|| mrEnrolRtn.errorCode.equalsIgnoreCase("0000")) {
					logger.info("sendMREnrollment(); Response from MQ is 'SUCCESS'.. ");

					log.info("sendMREnrollment(); Response from MQ is 'SUCCESS'.. ");

				} else {
					logger.info("sendMREnrollment(); Response from MQ is 'FAILURE'.. ");

					log.info("sendMREnrollment(); Response from MQ is 'FAILURE'.. ");
					// payHistRtn.status = invalidStr;
				}

			} else {
				logger.info("sendMREnrollment(); Since the response from MQ is not proper .. ");
				logger.info("sendMREnrollment(); Setting error values.");
				log.info("sendMREnrollment(); Since the response from MQ is not proper .. ");
				log.info("sendMREnrollment(); Setting error values.");
				mrEnrolRtn.errorCode = MQConstants.errorCode;
				mrEnrolRtn.errorDesc = errorDesc;
				// payHistRtn.status = invalidStr;
			}
		} catch (Exception e) {
			logger.info("sendMREnrollment(); Exception is raised." + e.toString());

			log.info("sendMREnrollment(); Exception is raised." + e.toString());

			mrEnrolRtn.errorCode = MQConstants.errorCode;
			mrEnrolRtn.errorDesc = errorDesc;
			// payHistRtn.status = invalidStr;
			logger.error("sendMREnrollment(); Reason : " + e.getStackTrace());

			log.severe("sendMREnrollment(); Reason : " + e.getStackTrace());
		} finally {
			xmlMap = null;
			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			map = null;

			replyMsg = emptyStr;
			xmlReq = emptyStr;

			errorDescription = emptyStr;

			maskCardNum = emptyStr;
		}
		logger.info("sendMREnrollment(); Response is returned to the IVR. Response : " + mrEnrolRtn.toString());
		logger.info("sendMREnrollment(); Exit");
		log.info("sendMREnrollment(); Response is returned to the IVR. Response : " + mrEnrolRtn.toString());
		log.info("sendMREnrollment(); Exit");
		return mrEnrolRtn;
	}
}
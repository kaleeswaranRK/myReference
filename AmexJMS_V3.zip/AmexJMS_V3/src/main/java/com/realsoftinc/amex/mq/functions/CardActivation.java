/*
* (C) Copyright 2013 Geomant Kft. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import javax.jms.TextMessage;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
import com.realsoftinc.amex.mq.returnObjs.EmbosserDetailReturn;
import com.realsoftinc.amex.mq.returnObjs.CardActivationReturn;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function CardActivation
 * 
 * @author Marijana Dujovic / Geomant Kft.
 */
public class CardActivation {
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(CardActivation.class);

	Logger log = Utility.getLogger();

	@SuppressWarnings({ "unchecked", "static-access" })
	public CardActivationReturn cardActivate(String cardNum, String accNum) {
		log.info("cardActivate(); Card Activation function is called by IVR .. ");
		log.info("cardActivate(); Enter");
		logger.info("cardActivate(); Card Activation function is called by IVR .. ");
		logger.info("cardActivate(); Enter");

		MQCommon mqc = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser cardnoparser = null;
		CardActivationReturn cardActivation = null;
		TextMessage mqReply = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		String dateTimeStampInStr = emptyStr;
		String date = emptyStr;
		String time = emptyStr;
		String auditSeqInStr = emptyStr;
		String currentFlag = emptyStr;
		String lastFlag = emptyStr;
		String xmlReq = emptyStr;
		String replyMsg = emptyStr;

		// String sso = emptyStr;
		String maskAccNum = emptyStr;
		String maskCardNum = emptyStr;

		EmbosserDetail embosserDtl = null;
		EmbosserDetailReturn embosserDetailRtObj = null;
		try {
			logger.info("cardActivate(); Calling Embosser Detail function ..");

			log.info("cardActivate(); Calling Embosser Detail function ..");
			embosserDtl = new EmbosserDetail();
			embosserDetailRtObj = embosserDtl.getEmbosserDetail(cardNum);
			cardActivation = new CardActivationReturn();
		}

		catch (Exception e) {
			logger.error("cardActivate(); Exception is raised. Reason : " + e.getStackTrace());

			log.severe("cardActivate(); Exception is raised. Reason : " + e.getStackTrace());
		}

		// log.info("cardActivate(); " + resCurrentUsageFlag +
		// embosserDetailRtObj.firstUsageFlag);
		// log.info("cardActivate(); " + resLastUsageFlag +
		// embosserDetailRtObj.priorUsageFlag);
		logger.info("cardActivate(); " + resErrorCode + embosserDetailRtObj.ErrorCode);

		log.info("cardActivate(); " + resErrorCode + embosserDetailRtObj.ErrorCode);

		if (embosserDetailRtObj.ErrorCode.equalsIgnoreCase("0") || embosserDetailRtObj.ErrorCode.equalsIgnoreCase("00")
				|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("000")
				|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("0000")) {
			// && (embosserDetailRtObj.firstUsageFlag.equalsIgnoreCase("Y"))
			// && (embosserDetailRtObj.priorUsageFlag.equalsIgnoreCase("N")))

			try {
				mqc = new MQCommon();
				rc = new RequestCreater();
				rr = new RequestResponse();
				cardnoparser = new ResponseParser();
				map = new HashMap<String, String>();
				xmlMap = new HashMap<String, String>();
				// sso = MQCommon.SSO;

				/*
				 * if(sso == null) { log.info("cardActivate(); sso is null");
				 * log.info("cardActivate(); Calling getSSO() function ..."); sso =
				 * mqc.getSSO(); } else if(sso.equalsIgnoreCase(emptyStr)) {
				 * log.info("cardActivate(); sso is an empty string");
				 * log.info("cardActivate(); Calling getSSO() function ..."); sso =
				 * mqc.getSSO(); }
				 */

				currentFlag = currentFlagN;
				lastFlag = CardActv_Hpr;

				if (accNum.length() == 12) {
					maskAccNum = accNum.substring(0, 4) + "******"
							+ accNum.substring(accNum.length() - 5, accNum.length());
					logger.info("cardActivate(); Account Number is : " + maskAccNum);

					log.info("cardActivate(); Account Number is : " + maskAccNum);
				} else {
					logger.info("cardActivate(); Account Number is less than 12 digits.");

					log.info("cardActivate(); Account Number is less than 12 digits.");
				}

				if (cardNum.length() == 15) {
					maskCardNum = cardNum.substring(0, 4) + "******"
							+ cardNum.substring(cardNum.length() - 5, cardNum.length());
					logger.info("cardActivate(); Card Number is : " + maskCardNum);
					log.info("cardActivate(); Card Number is : " + maskCardNum);
				} else {
					logger.info("cardActivate(); Card Number is less than 15 digits.");

					log.info("cardActivate(); Card Number is less than 15 digits.");
				}
				logger.info("cardActivate(); Calling the getDateTime function ..");

				log.info("cardActivate(); Calling the getDateTime function ..");
				dateTimeStampInStr = mqc.getDateTime();
				logger.info("cardActivate(); DateTimeStamp is : " + dateTimeStampInStr);

				logger.info("cardActivate(); Calling the getAuditSequence function ..");
				log.info("cardActivate(); DateTimeStamp is : " + dateTimeStampInStr);

				log.info("cardActivate(); Calling the getAuditSequence function ..");
				auditSeqInStr = mqc.getAuditSequence();
				logger.info("cardActivate(); Audit Sequence is : " + auditSeqInStr);

				logger.info("cardActivate(); Calling the getDate function ..");
				log.info("cardActivate(); Audit Sequence is : " + auditSeqInStr);

				log.info("cardActivate(); Calling the getDate function ..");
				date = mqc.getDate();
				logger.info("cardActivate(); Date is : " + date);

				logger.info("cardActivate(); Calling the getTime function ..");
				log.info("cardActivate(); Date is : " + date);

				log.info("cardActivate(); Calling the getTime function ..");
				time = mqc.getTime();
				logger.info("cardActivate(); Time is : " + time);

				logger.info("cardActivate(); Created all the required parameters to prepare the xml ..");
				log.info("cardActivate(); Time is : " + time);

				log.info("cardActivate(); Created all the required parameters to prepare the xml ..");
				xmlMap.put("CardNumber", cardNum);
				xmlMap.put("AccountNumber", accNum);
				xmlMap.put("DateTimeStamp", dateTimeStampInStr);
				xmlMap.put("AuditSeq", auditSeqInStr);
				xmlMap.put("MessageLength", mqc.getproperties("CardActivation.MsgLength"));
				xmlMap.put("MessageId", MsgId_CardActv);
				xmlMap.put("Description", CardActv_Desc);
				xmlMap.put("ReviewDate", date);
				xmlMap.put("ReviewTime", time);
				xmlMap.put("SSO", mqc.getproperties("CardActivation.SSO"));
				xmlMap.put("CardSeqNo", CardActv_CardSeqNo);
				xmlMap.put("CurrFlag", currentFlag);
				xmlMap.put("LastFlag", lastFlag);
				xmlMap.put("Note", CardActv_note);
				xmlMap.put("RepId", CardActv_RepId);
				xmlMap.put("Hpr", CardActv_Hpr);
				xmlMap.put("CaseNo", CardActv_CaseNo);
				xmlMap.put("RackFlag", mqc.getproperties("CardActivation.RackFlag"));
				logger.info("cardActivate(); Sending values to form proper format of xml request .. ");

				log.info("cardActivate(); Sending values to form proper format of xml request .. ");
				xmlReq = rc.XmlRequest(xmlMap, "CardActivation");
				logger.info("cardActivate(); Received xml in proper format ..");
				logger.info("cardActivate(); XML is : " + xmlReq);

				logger.info("cardActivate(); Sending the prepared xml to MQ .. ");
				log.info("cardActivate(); Received xml in proper format ..");
				log.info("cardActivate(); XML is : " + xmlReq);

				log.info("cardActivate(); Sending the prepared xml to MQ .. ");
				mqReply = rr.MessageSenderAck(xmlReq);
				replyMsg = mqReply.getText();
				logger.info("cardActivate(); Response received from MQ .. ");
				logger.info("cardActivate(); Received response from MQ is : " + replyMsg);

				logger.info("cardActivate(); Received response from MQ : " + replyMsg);
				log.info("cardActivate(); Response received from MQ .. ");
				log.info("cardActivate(); Received response from MQ is : " + replyMsg);

				log.info("cardActivate(); Received response from MQ : " + replyMsg);

				if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
					logger.info("cardActivate(); Sending the received response from MQ to the parser ..");
					logger.info("cardActivate(); XML sent for parsing is :" + replyMsg);
					log.info("cardActivate(); Sending the received response from MQ to the parser ..");
					log.info("cardActivate(); XML sent for parsing is :" + replyMsg);
					map = cardnoparser.XmlParser(replyMsg);
					cardActivation.ErrorCode = (String) map.get("errCode");
					cardActivation.ErrorDescription = (String) map.get("errDes");

					if (cardActivation.ErrorCode.equalsIgnoreCase("0")
							|| cardActivation.ErrorCode.equalsIgnoreCase("00")
							|| cardActivation.ErrorCode.equalsIgnoreCase("000")
							|| cardActivation.ErrorCode.equalsIgnoreCase("0000")) {
						logger.info("cardActivate(); Response from MQ is 'SUCCESS'.. ");

						log.info("cardActivate(); Response from MQ is 'SUCCESS'.. ");
						cardActivation.Status = validStr;
					} else {
						logger.info("cardActivate(); Response from MQ is 'FAILURE'.. ");

						log.info("cardActivate(); Response from MQ is 'FAILURE'.. ");
						cardActivation.Status = invalidStr;
					}

//acknowledge sending removed 27.03.2013.
					/*
					 * log.info("cardActivate(); Sending acknowledge string for xml formation.. :");
					 * respMap.put("MessageId", MsgId_CardActvAck); respMap.put("Description",
					 * CardActv_DescAck); respMap.put("errorCode", cardActivation.ErrorCode);
					 * respMap.put("errorDescription", cardActivation.ErrorDescription);
					 * 
					 * cardActivation.Status = status;
					 * 
					 * 
					 * xmlResp = rc.XmlRequest(respMap, "CardActivation_Ack");
					 * 
					 * Destination destQ = mqReply.getJMSReplyTo();
					 * log.info("cardActivate(); Destination Q is : " + destQ.toString());
					 * 
					 * log.info("cardActivate(); Sending acknowledgment .. ");
					 * rr.sendAck(xmlResp,destQ);
					 * log.info("cardActivate(); Acknowledgment sent to MQ ."); }
					 */
				} else {
					logger.info("cardActivate(); Since the response from MQ is not proper .. ");
					logger.info("cardActivate(); Setting error values.");
					log.info("cardActivate(); Since the response from MQ is not proper .. ");
					log.info("cardActivate(); Setting error values.");
					cardActivation.ErrorCode = errorCode;
					cardActivation.ErrorDescription = errorDesc;
					cardActivation.Status = invalidStr;
				}

			} catch (Exception e) {
				logger.error("cardActivate(); Exception is raised. Reason : " + e.getStackTrace());

				log.severe("cardActivate(); Exception is raised. Reason : " + e.getStackTrace());
			} finally {
				mqc = null;
				rc = null;
				rr = null;
				cardnoparser = null;
				mqReply = null;
				xmlMap = null;
				map = null;

				dateTimeStampInStr = emptyStr;
				date = emptyStr;
				time = emptyStr;
				auditSeqInStr = emptyStr;
				currentFlag = emptyStr;
				lastFlag = emptyStr;
				xmlReq = emptyStr;
				replyMsg = emptyStr;

				// sso = emptyStr;
				maskAccNum = emptyStr;
				maskCardNum = emptyStr;

			}
		} else {// Embosser detail returned error
			if (embosserDetailRtObj.ErrorCode.equalsIgnoreCase("0")
					|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("00")
					|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("000")
					|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("0000")) {
				// && (embosserDetailRtObj.firstUsageFlag
				// .equalsIgnoreCase("Y") && embosserDetailRtObj.priorUsageFlag
				// .equalsIgnoreCase("Y"))) {
				cardActivation.isNewCardRequest = true;
			} else {
				cardActivation.isNewCardRequest = false;
			}
			logger.info("cardActivate(); The Embosser Detail Message Failed.");
			logger.info("cardActivate(); Setting the ErrorCode and ErrorDescription inside CardActivation Return Object.");
			log.info("cardActivate(); The Embosser Detail Message Failed.");
			log.info("cardActivate(); Setting the ErrorCode and ErrorDescription inside CardActivation Return Object.");
			cardActivation.ErrorCode = errorCode;
			cardActivation.ErrorDescription = errorDesc;
			cardActivation.Status = invalidStr;
		}
		logger.info("cardActivate(); Response is returned to the IVR. Response : " + cardActivation.toString());
		logger.info("cardActivate(); Exit");
		log.info("cardActivate(); Response is returned to the IVR. Response : " + cardActivation.toString());
		log.info("cardActivate(); Exit");
		return cardActivation;
	}
}

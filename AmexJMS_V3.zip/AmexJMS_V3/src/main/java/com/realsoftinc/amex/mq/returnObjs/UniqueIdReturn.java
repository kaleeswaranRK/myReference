package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class UniqueIdReturn 
{
	public String errorCode 	= emptyStr;
	public String errorDesc 	= emptyStr;
	public String status 		= emptyStr;
	public String accountNum 	= emptyStr;
	public String cardNum		= emptyStr;
	public String cardType		= emptyStr;
	public String maskAccNum    = emptyStr;
	public String maskCardNum    = emptyStr;
	
	public String toString()
	{
		//maskAccNum = accountNum.replace(accountNum.subSequence(4, accountNum.length()-5),maskString1);
		if (!(accountNum.equalsIgnoreCase(emptyStr)))
		 maskAccNum=accountNum.substring(0,4)+"******"+accountNum.substring(accountNum.length()-5,accountNum.length());
		if (!(cardNum.equalsIgnoreCase(emptyStr)))
		 maskCardNum=cardNum.substring(0,4)+"******"+cardNum.substring(cardNum.length()-5,cardNum.length());
		String returnStr = newLine +
				resErrorCode + errorCode  			+ newLine  +
				resErrorDesc + errorDesc  			+ newLine  +
				resStatus + status     			+ newLine  +
				resAccNum + maskAccNum 			+ newLine  +
				resCardNumber + maskCardNum 			+ newLine +
				resCardType + cardType			 	+ newLine ; 
			return returnStr;
	}
}
/*
* (C) Copyright 2013 Geomant Kft. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.EmbosserDetailReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function Emboser Detail
 * 
 * @author Marijana Dujovic / Geomant Kft.
 */

public class EmbosserDetail {

	Logger log = Utility.getLogger();
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(EmbosserDetail.class);

	@SuppressWarnings({ "unchecked", "static-access" })
	public EmbosserDetailReturn getEmbosserDetail(String cardNum) {
		logger.info("getEmbosserDetail(); Embosser Detail function is called by IVR .. ");
		logger.info("getEmbosserDetail(); Enter ");
		log.info("getEmbosserDetail(); Embosser Detail function is called by IVR .. ");
		log.info("getEmbosserDetail(); Enter ");

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		MQCommon mqc = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		EmbosserDetailReturn embosserDtlRtrn = null;
		ResponseParser cardnoparser = null;

		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		String errorCode = emptyStr;
		String errorDescription = emptyStr;
		// String firstUsageFlag = emptyStr;
		// String priorUsageFlag = emptyStr;
		// String cardExpiryDate = emptyStr;

		String maskCardNum = emptyStr;

		try {
			mqc = new MQCommon();
			xmlMap = new HashMap<String, String>();
			xmlMap = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			cardnoparser = new ResponseParser();
			embosserDtlRtrn = new EmbosserDetailReturn();

			/*
			 * sso = MQCommon.SSO; if(sso == null) {
			 * log.info("getEmbosserDetail(); sso is null");
			 * log.info("getEmbosserDetail(); Calling getSSO() function .. "); sso =
			 * mqc.getSSO(); } else if(sso.equalsIgnoreCase(emptyStr)) {
			 * log.info("getEmbosserDetail(); sso is empty string");
			 * log.info("getEmbosserDetail(); Calling getSSO() function .. "); sso =
			 * mqc.getSSO(); }
			 */
			if (cardNum.length() == 15) {

				maskCardNum = cardNum.substring(0, 4) + "******"
						+ cardNum.substring(cardNum.length() - 5, cardNum.length());
				logger.info("getEmbosserDetail(); Card Number is : " + maskCardNum);

				log.info("getEmbosserDetail(); Card Number is : " + maskCardNum);
			} else {
				logger.info("getEmbosserDetail(); Card Number is less than 15 digits.");

				log.info("getEmbosserDetail(); Card Number is less than 15 digits.");
			}
			logger.info("getEmbosserDetail(); Calling the getDateTime function ..");

			log.info("getEmbosserDetail(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("getEmbosserDetail(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("getEmbosserDetail(); Calling the getAuditSequence function ..");
			log.info("getEmbosserDetail(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("getEmbosserDetail(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("getEmbosserDetail(); Audit Sequence is : " + auditSeqInStr);

			logger.info("getEmbosserDetail(); Created all the required parameters to prepare the xml ..");
			log.info("getEmbosserDetail(); Audit Sequence is : " + auditSeqInStr);

			log.info("getEmbosserDetail(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("CardNumber", cardNum);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			// xmlMap.put("AuditSeq", auditSeqInStr);
			// xmlMap.put("SSO", sso);
			// xmlMap.put("MessageLength", mqc.getproperties("EmbosserDetail.MsgLength"));
			xmlMap.put("MessageId", MsgId_EmbsrDtl);
			xmlMap.put("SysID", mqc.getproperties("CardNoValidation.SysID"));
			logger.info("getEmbosserDetail(); Sending values to form proper format of xml request .. ");

			log.info("getEmbosserDetail(); Sending values to form proper format of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "EmbosserDetail");
			logger.info("getEmbosserDetail(); Received xml in proper format ..");

			log.info("getEmbosserDetail(); Received xml in proper format ..");
			// log.info("getEmbosserDetail(); XML is : " + xmlReq);
			// Added to encrypt account number when display response in log file
			MQCommon.maskAccNumber("getEmbosserDetail(); XML is : ", xmlReq);
			logger.info("getEmbosserDetail(); Sending the prepared xml to MQ .. ");

			log.info("getEmbosserDetail(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("getEmbosserDetail(); Response received from MQ .. ");
			logger.info("getEmbosserDetail(); Received response from MQ is : " + replyMsg);

			log.info("getEmbosserDetail(); Response received from MQ .. ");
			log.info("getEmbosserDetail(); Received response from MQ is : " + replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("getEmbosserDetail(); Sending the received response from MQ to the parser ..");

				log.info("getEmbosserDetail(); Sending the received response from MQ to the parser ..");
				// log.info("getEmbosserDetail(); XML sent for parsing is :"+ replyMsg);
				map = cardnoparser.XmlParser(replyMsg);
				logger.info("getEmbosserDetail(); Received Hash map after parsing of response.");

				log.info("getEmbosserDetail(); Received Hash map after parsing of response.");

				errorCode = (String) map.get("errCode");
				errorDescription = (String) map.get("errDesc");

				if (errorCode.equalsIgnoreCase("0") || errorCode.equalsIgnoreCase("00")
						|| errorCode.equalsIgnoreCase("000") || errorCode.equalsIgnoreCase("0000")) {
					logger.info("getEmbosserDetail(); Response from MQ is 'SUCCESS'.. ");

					log.info("getEmbosserDetail(); Response from MQ is 'SUCCESS'.. ");
					// firstUsageFlag = (String) map.get("firstUsageFlag");
					// priorUsageFlag = (String) map.get("priorUsageFlag");
					// cardExpiryDate = (String) map.get("expiryDate");
				}

				embosserDtlRtrn.ErrorCode = errorCode;
				embosserDtlRtrn.ErrorDescription = errorDescription;
				// embosserDtlRtrn.firstUsageFlag = firstUsageFlag;
				// embosserDtlRtrn.priorUsageFlag = priorUsageFlag;
				if ((String) map.get("expiryDate") != null)
					embosserDtlRtrn.cardExpiryDate = (String) map.get("expiryDate");
				if ((String) map.get("embossName") != null)
					embosserDtlRtrn.embossName = (String) map.get("embossName");
				if ((String) map.get("dbc") != null)
					embosserDtlRtrn.DBC = (String) map.get("dbc");

			} else {
				logger.info("getEmbosserDetail(); Since the response from MQ is not proper .. ");
				logger.info("getEmbosserDetail(); Setting error values.");
				log.info("getEmbosserDetail(); Since the response from MQ is not proper .. ");
				log.info("getEmbosserDetail(); Setting error values.");
				embosserDtlRtrn.ErrorCode = MQConstants.errorCode;
				embosserDtlRtrn.ErrorDescription = errorDesc;
			}
		} catch (Exception e) {
			logger.info("getEmbosserDetail(); Exception is raised." + e.toString());

			log.info("getEmbosserDetail(); Exception is raised." + e.toString());
			embosserDtlRtrn.ErrorCode = MQConstants.errorCode;
			embosserDtlRtrn.ErrorDescription = errorDesc;
			logger.error("getEmbosserDetail(); Reason : " + e.getStackTrace());

			log.severe("getEmbosserDetail(); Reason : " + e.getStackTrace());
		} finally {
			xmlMap = null;
			map = null;
			mqc = null;
			rc = null;
			rr = null;
			cardnoparser = null;

			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			xmlReq = emptyStr;
			replyMsg = emptyStr;
			errorCode = emptyStr;
			errorDescription = emptyStr;
			// firstUsageFlag = emptyStr;
			// priorUsageFlag = emptyStr;
			// cardExpiryDate = emptyStr;

			maskCardNum = emptyStr;
		}
		logger.info("getEmbosserDetail(); Response is returned to the IVR. Response : " + embosserDtlRtrn.toString());
		logger.info("getEmbosserDetail(); Exit");
		log.info("getEmbosserDetail(); Response is returned to the IVR. Response : " + embosserDtlRtrn.toString());
		log.info("getEmbosserDetail(); Exit");
		return embosserDtlRtrn;
	}
}

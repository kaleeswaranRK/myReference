package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class GetClientCodeReturn {

	public String errorCode = emptyStr;
	public String errorDesc = emptyStr;
	public String msgId = emptyStr;
	public String dateTimeStampOutStr = emptyStr;
	public String auditSeqOutStr = emptyStr;
	public String description = emptyStr;
	public String clientCode = emptyStr;
	public String status = emptyStr;
		
	public String toString()
	{
		String returnStr = newLine +
				resErrorCode + errorCode  + newLine +
				resErrorDesc + errorDesc  + newLine +
				resStatus + status     + newLine +
				resMsgId + msgId + newLine +
				resDateTimeStampLog + dateTimeStampOutStr + newLine +
				resAuditSeq + auditSeqOutStr + newLine +
				resDesc + description + newLine +
				resClientCode + clientCode + newLine;
	
		return returnStr;
	}
}
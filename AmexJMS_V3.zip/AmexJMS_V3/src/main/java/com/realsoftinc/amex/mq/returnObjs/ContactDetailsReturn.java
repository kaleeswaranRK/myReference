package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class ContactDetailsReturn 
{
	public String ErrorCode = emptyStr;
	public String ErrorDescription = emptyStr;
	public String Status = emptyStr;
	public String maskAccNum = emptyStr;
	
	public ContDetails cntDetails = null;
	
	public String toString ()
	{
		String returnStr = emptyStr;
		if(cntDetails != null)
		{
			//maskAccNum = cntDetails.AccountNum.replace(cntDetails.AccountNum.subSequence(4,cntDetails.AccountNum.length()-5),maskString1);
			if (!(cntDetails.AccountNum.equalsIgnoreCase(emptyStr)))
			 maskAccNum=cntDetails.AccountNum.substring(0,4)+"******"+cntDetails.AccountNum.substring(cntDetails.AccountNum.length()-5,cntDetails.AccountNum.length());
			returnStr = newLine +
			resErrorCode + ErrorCode + newLine +
			resErrorDesc + ErrorDescription + newLine +
			resStatus + Status + newLine +	
			resAccNum + maskAccNum + newLine +
			resOrg + cntDetails.Org + newLine +
			resLogo + cntDetails.Logo + newLine +
			resCurrencyName + cntDetails.CurrencyName + newLine +
			resPrimarySuppFlag + cntDetails.PrimSupplFlag + newLine +
			resTitle + cntDetails.Title + newLine +
			resName + cntDetails.Name1 + newLine +
			resStatementAddr1 + cntDetails.StatementAddress1 + newLine +
			resDOB + cntDetails.DateOfBirth + newLine +
			resHomePhone + cntDetails.HomeNO + newLine +
			resHomeCountrySel + cntDetails.HomeCountrySel     + newLine +
			resMobilePhone + cntDetails.MobileNO    + newLine +
			resMobileCountrySel + cntDetails.MobileNOCountySel   + newLine +
			resEmail + cntDetails.EmailID + newLine +
			resMemo1 + cntDetails.Memo1 + newLine +
			resMemo2 + cntDetails.Memo2 + newLine +
			resWorkPhone + cntDetails.WorkNO + newLine +
			resWorkCountrySel + cntDetails.WorkNoCountrySel + newLine +
			resSMSFlag + cntDetails.SMSFlag + newLine +
			resEStatementFlag + cntDetails.eStatementFlag + newLine +	
			resProductCode + cntDetails.productCode + newLine +
			resOTB+ cntDetails.OTB + newLine +
			resBranchCode + cntDetails.BranchCode + newLine +
			resPowercardID + cntDetails.powercardID + newLine;			
			
		}
		else
		{
			returnStr = newLine +
			"Error Code           : " + ErrorCode                 + newLine +
			"Error Description    : " + ErrorDescription          + newLine +
			"Status               : " + Status                    + newLine ;
		}		
		return returnStr;
	}
}

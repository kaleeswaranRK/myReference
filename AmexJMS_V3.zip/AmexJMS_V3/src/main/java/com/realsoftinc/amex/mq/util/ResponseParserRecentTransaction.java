package com.realsoftinc.amex.mq.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import java.util.logging.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;

public class ResponseParserRecentTransaction {
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(ResponseParserRecentTransaction.class);

	Logger log = Utility.getLogger();
	//final static Logger log = Logger.getLogger(RequestCreater.class);
	
	@SuppressWarnings("unchecked")
	public String[] responseParserRecentTransaction(String replyText)
    {
		logger.info("XmlParser(); Enter");
		log.info("XmlParser(); Enter");
		
		String[] transaction = null;

        Map<String, String> xmlmap = null;
        try
        {
        	StringTokenizer st = new StringTokenizer(replyText ,"|");
        	if(st.hasMoreTokens()){
        		replyText = st.nextToken();
        		//log.info("XmlParser(); XMl string is : " + replyText);
        		//MQCommon.maskAccNumber("XmlParser(); XMl string is : " , replyText);
        	}
        	else{
        		logger.info("XmlParser(); 1st Condition not satisfied");

        		log.info("XmlParser(); 1st Condition not satisfied");
        	}        	
        
        	xmlmap = new HashMap<String , String>();
            Document document = DocumentHelper.parseText(replyText);
            
            List list7 = document.selectNodes("//Message_Res/RecentTransactions/Message_Req/transaction");
			
			/**GetCard Detail**/
			Iterator iter7 = list7.iterator();
			logger.info("XmlParser(); Node is : //Message_Res/RecentTransactions/Message_Req/transaction");
			logger.info("Number Of CardDetails: "+list7.size());
			log.info("XmlParser(); Node is : //Message_Res/RecentTransactions/Message_Req/transaction");
			log.info("Number Of CardDetails: "+list7.size());
			
			transaction = new String[list7.size()];
			int i =0;
			
			while(iter7.hasNext())
			{	
				Element element = (Element)iter7.next();
				String trans = new String();

	            trans = element.getText().trim();
	            logger.info("XmlParser(); transaction : " + trans );

	            log.info("XmlParser(); transaction : " + trans );
	            transaction[i] = trans;
	         
				transaction[i] = trans;
						i++;
			}
			
        }
        catch(DocumentException e)
        {
            logger.error((new StringBuilder("TransactionOffers Parser(); Document Exception is raised. Reason :")).append(e.getMessage()).toString());

            log.severe((new StringBuilder("TransactionOffers Parser(); Document Exception is raised. Reason :")).append(e.getMessage()).toString());
        }
        return transaction;
    }

	
}

/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.ChargeCardDueDateReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for having the main business logic for Charge Card
 * Due Date Function
 * 
 * @name ChargeCardDueDate
 * @author Purvi Lad
 * @version 1.0 Date 11 Mar 2010
 */
public class ChargeCardDueDate {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(ChargeCardDueDate.class);

	@SuppressWarnings({ "unchecked", "static-access" })
	public ChargeCardDueDateReturn chargeCardDueDate(String cardNum) {
		logger.info("chargeCardDueDate(); Charge Card Due Date function is called by IVR .. ");
		logger.info("chargeCardDueDate(); Enter ");
		log.info("chargeCardDueDate(); Charge Card Due Date function is called by IVR .. ");
		log.info("chargeCardDueDate(); Enter ");

		MQCommon mqc = null;
		ChargeCardDueDateReturn chrgCardDueRtn = null;
		Map<String, String> xmlMap = null;
		Map<String, String> map = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser cardnoparser = null;

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		String returnMsgIdActualStr = emptyStr;
		String errorCode = emptyStr;
		String dueDate = emptyStr;
		String maskCardNum = emptyStr;

		try {
			mqc = new MQCommon();
			chrgCardDueRtn = new ChargeCardDueDateReturn();
			mqc = new MQCommon();
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			cardnoparser = new ResponseParser();

			if (cardNum.length() == 15) {

				maskCardNum = cardNum.substring(0, 4) + "******"
						+ cardNum.substring(cardNum.length() - 5, cardNum.length());
				logger.info("chargeCardDueDate(); Card Number is : " + maskCardNum);

				log.info("chargeCardDueDate(); Card Number is : " + maskCardNum);
			} else {
				logger.info("chargeCardDueDate(); Card Number is less than 15 digits.");

				log.info("chargeCardDueDate(); Card Number is less than 15 digits.");
			}
			logger.info("chargeCardDueDate(); Created all the required parameters to prepare the xml ..");

			log.info("chargeCardDueDate(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("AccountNumber", cardNum);
			xmlMap.put("MessageId", MsgId_ChrgCrdDueDt);
			xmlMap.put("sourceApp", ChrgCrdSrcApp1);
			logger.info("chargeCardDueDate(); Sending values to form proper form of xml request .. ");

			log.info("chargeCardDueDate(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "ChargeCardDueDate");
			logger.info("chargeCardDueDate(); Received xml in proper format ..");
			logger.info("chargeCardDueDate(); XML is : " + xmlReq);

			logger.info("chargeCardDueDate(); Sending this xml as the request to MQ ..");
			log.info("chargeCardDueDate(); Received xml in proper format ..");
			log.info("chargeCardDueDate(); XML is : " + xmlReq);

			log.info("chargeCardDueDate(); Sending this xml as the request to MQ ..");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("chargeCardDueDate(); Response received from MQ .. ");
			logger.info("chargeCardDueDate(); Received response from MQ is : " + replyMsg);
			log.info("chargeCardDueDate(); Response received from MQ .. ");
			log.info("chargeCardDueDate(); Received response from MQ is : " + replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("chargeCardDueDate(); Sending the received response from MQ to the parser ..");
				logger.info("chargeCardDueDate(); XML sent for parsing is :" + replyMsg);
				log.info("chargeCardDueDate(); Sending the received response from MQ to the parser ..");
				log.info("chargeCardDueDate(); XML sent for parsing is :" + replyMsg);
				map = cardnoparser.XmlParser(replyMsg);
				logger.info("chargeCardDueDate(); Received Hash map after parsing of response.");

				log.info("chargeCardDueDate(); Received Hash map after parsing of response.");

				errorCode = (String) map.get("errorCode");
				dueDate = (String) map.get("date");
				returnMsgIdActualStr = (String) map.get("returnMsgIdActualStr");
				chrgCardDueRtn.errorCode = errorCode;

				String currentYear = mqc.getCurrentYear();
				String currentMonth = mqc.getCurrentMonth();

				int curYearInt = Integer.parseInt(currentYear);

				String dd = emptyStr;
				String mm = emptyStr;

				if (dueDate != null) {
					if (!emptyStr.equalsIgnoreCase(dueDate)) {
						dd = dueDate.substring(0, 2);
						mm = dueDate.substring(2, 4);

						if (currentMonth.equalsIgnoreCase("12") && mm.equalsIgnoreCase("01")) {
							curYearInt++;
							currentYear = emptyStr + curYearInt;
						}
					}
				}

				dueDate = dd + mm + currentYear;
				if (dueDate.length() == 4) // we are not getting due date from host.
				{
					dueDate = "0";
				}
				chrgCardDueRtn.dueDate = dueDate;

				if (errorCode.equalsIgnoreCase("0") || errorCode.equalsIgnoreCase("00")
						|| errorCode.equalsIgnoreCase("000") || errorCode.equalsIgnoreCase("0000")) {
					logger.info("chargeCardDueDate(); Response from MQ is 'SUCCESS'.. ");

					log.info("chargeCardDueDate(); Response from MQ is 'SUCCESS'.. ");
					chrgCardDueRtn.status = validStr;
				} else {
					logger.info("chargeCardDueDate(); Response from MQ is 'FAILURE'.. ");

					log.info("chargeCardDueDate(); Response from MQ is 'FAILURE'.. ");
					chrgCardDueRtn.status = invalidStr;
				}

				if (returnMsgIdActualStr.equalsIgnoreCase(MsgId_ChrgCrdDueDtResp)) {
					logger.info("chargeCardDueDate(); Getting valid msg id from the response.");

					log.info("chargeCardDueDate(); Getting valid msg id from the response.");
				} else {
					logger.info("chargeCardDueDate(); Since the response from MQ is not proper .. ");
					logger.info("chargeCardDueDate(); Setting error values.");
					log.info("chargeCardDueDate(); Since the response from MQ is not proper .. ");
					log.info("chargeCardDueDate(); Setting error values.");
					chrgCardDueRtn.errorCode = MQConstants.errorCode;
					chrgCardDueRtn.status = invalidStr;
				}
			} else {
				logger.info("chargeCardDueDate(); Since the response from MQ is not proper .. ");
				logger.info("chargeCardDueDate(); Setting error values.");
				log.info("chargeCardDueDate(); Since the response from MQ is not proper .. ");
				log.info("chargeCardDueDate(); Setting error values.");
				chrgCardDueRtn.errorCode = MQConstants.errorCode;
				chrgCardDueRtn.status = invalidStr;
			}
		} catch (Exception e) {
			logger.info("chargeCardDueDate(); Exception is raised." + e.toString());

			log.info("chargeCardDueDate(); Exception is raised." + e.toString());
			chrgCardDueRtn.errorCode = MQConstants.errorCode;
			chrgCardDueRtn.status = invalidStr;
			logger.error("chargeCardDueDate(); Reason :" + e.getStackTrace());

			log.severe("chargeCardDueDate(); Reason :" + e.getStackTrace());
		} finally {
			mqc = null;
			xmlMap = null;
			map = null;
			rc = null;
			rr = null;
			cardnoparser = null;

			xmlReq = emptyStr;
			replyMsg = emptyStr;
			returnMsgIdActualStr = emptyStr;
			errorCode = emptyStr;
			dueDate = emptyStr;
			maskCardNum = emptyStr;
		}
		logger.info("chargeCardDueDate(); Response is returned to the IVR. Response : " + chrgCardDueRtn.toString());
		logger.info("chargeCardDueDate(); Exit");
		log.info("chargeCardDueDate(); Response is returned to the IVR. Response : " + chrgCardDueRtn.toString());
		log.info("chargeCardDueDate(); Exit");
		return chrgCardDueRtn;

	}

}

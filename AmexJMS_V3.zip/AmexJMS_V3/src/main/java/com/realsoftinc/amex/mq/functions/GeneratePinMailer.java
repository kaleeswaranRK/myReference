package com.realsoftinc.amex.mq.functions;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.GeneratePinMailerReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

public class GeneratePinMailer {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(GeneratePinMailer.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public GeneratePinMailerReturn generatePinMailer(String accNum, String CardNum) {
		logger.info("GeneratePinMailer(); Generate PinMailer function is called by IVR .. ");
		logger.info("accountGeneratePinMailerOffers(); Enter ");
		log.info("GeneratePinMailer(); Generate PinMailer function is called by IVR .. ");
		log.info("accountGeneratePinMailerOffers(); Enter ");

		MQCommon mqc = new MQCommon();

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		//String dateTimeStampOutStr = emptyStr;
		//String auditSeqOutStr = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String maskAccNum = emptyStr;
		String maskCardNum = emptyStr;

		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;
		GeneratePinMailerReturn pinMailerRtn = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		try {
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			pinMailerRtn = new GeneratePinMailerReturn();
			respParser = new ResponseParser();
			logger.info("GeneratePinMailer(); Calling the getDateTime function ..");

			log.info("GeneratePinMailer(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("GeneratePinMailer(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("GeneratePinMailer(); Calling the getAuditSequence function ..");
			log.info("GeneratePinMailer(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("GeneratePinMailer(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("GeneratePinMailer(); Audit Sequence is : " + auditSeqInStr);

			log.info("GeneratePinMailer(); Audit Sequence is : " + auditSeqInStr);
			
			if(accNum.length() == 12){
				maskAccNum=accNum.substring(0,4)+"******"+accNum.substring(accNum.length()-5,accNum.length());
				logger.info("GeneratePinMailer(); Account Number is : " + maskAccNum);

				log.info("GeneratePinMailer(); Account Number is : " + maskAccNum);
				}
				else{
					logger.info("GeneratePinMailer(); Account Number is less than 12 digits.");

					log.info("GeneratePinMailer(); Account Number is less than 12 digits.");
				}
			
			if (CardNum.length() == 15) {
				maskCardNum = CardNum.substring(0,4)+"******"+CardNum.substring(CardNum.length()-5,CardNum.length());
				logger.info("GeneratePinMailer(); Card Number is : " + maskCardNum);

				log.info("GeneratePinMailer(); Card Number is : " + maskCardNum);
			
			} else {
				logger.info("GeneratePinMailer(); Card Number is less than 15 digits.");

				log.info("GeneratePinMailer(); Card Number is less than 15 digits.");
			}
			logger.info("GeneratePinMailer(); Created all the required parameters to prepare the xml ..");

			log.info("GeneratePinMailer(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("AccountNumber", accNum);
			xmlMap.put("CardNumber", CardNum);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("MessageId", MsgId_PinMailer);
			xmlMap.put("SysID", mqc.getproperties("GeneratePinMailer.SysID"));
			logger.info("GeneratePinMailer(); Sending values to form proper format of xml request .. ");

			log.info("GeneratePinMailer(); Sending values to form proper format of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "PinMailer");
			logger.info("GeneratePinMailer(); Received xml in proper format ..");

			log.info("GeneratePinMailer(); Received xml in proper format ..");
			MQCommon.maskAccNumber("GeneratePinMailer(); XML is : ", xmlReq);
			logger.info("GeneratePinMailer(); Sending the prepared xml to MQ .. ");

			log.info("GeneratePinMailer(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("GeneratePinMailer(); Response received from MQ .. ");

			log.info("GeneratePinMailer(); Response received from MQ .. ");
			MQCommon.maskAccNumber("GeneratePinMailer(); Received response from MQ is : ", replyMsg);
			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("GeneratePinMailer(); Sending the received response from MQ to the parser ..");

				log.info("GeneratePinMailer(); Sending the received response from MQ to the parser ..");
				// log.info("accountOffers(); XML sent for parsing is :"+ replyMsg);
				map = respParser.XmlParser(replyMsg);
				logger.info("GeneratePinMailer(); Received Hash map after parsing of response.");

				log.info("GeneratePinMailer(); Received Hash map after parsing of response.");

				pinMailerRtn.errorCode = (String) map.get("errCode");
				pinMailerRtn.errorDesc = (String) map.get("errDesc");

				if (pinMailerRtn.errorCode.equalsIgnoreCase("0") 
						|| pinMailerRtn.errorCode.equalsIgnoreCase("00")
						|| pinMailerRtn.errorCode.equalsIgnoreCase("000")
						|| pinMailerRtn.errorCode.equalsIgnoreCase("0000")) {
					logger.info("GeneratePinMailer(); Response from MQ is 'SUCCESS'.. ");

					log.info("GeneratePinMailer(); Response from MQ is 'SUCCESS'.. ");

					if ((String) map.get("msgIdActualStr")!= null) {
						pinMailerRtn.msgId = (String) map.get("msgIdActualStr");
					}
					if ((String) map.get("dateTimeStampStr")!= null) {
						pinMailerRtn.dateTimeStampOutStr = (String) map.get("dateTimeStampStr");
					}
					if ((String) map.get("auditSeqStr")!= null) {
						pinMailerRtn.auditSeqOutStr = (String) map.get("auditSeqStr");
					}
					if ((String) map.get("description")!= null) {
						pinMailerRtn.description = (String) map.get("description");
					}
					if ((String) map.get("CaseNumber")!= null) {
						pinMailerRtn.caseNumber = (String) map.get("CaseNumber");
					}
					
					pinMailerRtn.status = validStr;

				} else {
					logger.info("GeneratePinMailer(); Response from MQ is 'FAILURE'.. ");

					log.info("GeneratePinMailer(); Response from MQ is 'FAILURE'.. ");
					pinMailerRtn.status = invalidStr;
				}

			} else {
				logger.info("GeneratePinMailer(); Since the response from MQ is not proper .. ");
				logger.info("GeneratePinMailer(); Setting error values.");
				log.info("GeneratePinMailer(); Since the response from MQ is not proper .. ");
				log.info("GeneratePinMailer(); Setting error values.");
				pinMailerRtn.errorCode = errorCode;
				pinMailerRtn.errorDesc = errorDesc;
				pinMailerRtn.status = invalidStr;
			}

		} catch (Exception e) {
			logger.info("GeneratePinMailer(); Exception is raised." + e.toString());

			log.info("GeneratePinMailer(); Exception is raised." + e.toString());
			pinMailerRtn.errorCode = errorCode;
			pinMailerRtn.errorDesc = errorDesc;
			pinMailerRtn.status = invalidStr;
			logger.error("GeneratePinMailer(); Reason : "+ e.getStackTrace());

			log.severe("GeneratePinMailer(); Reason : "+ e.getStackTrace());

		} finally {
			xmlReq = emptyStr;
			replyMsg = emptyStr;
			//dateTimeStampOutStr = emptyStr;
			//auditSeqOutStr = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			//	maskAccNum = emptyStr;

			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			xmlMap = null;
			map = null;
		}
		logger.info("GeneratePinMailer(); Response is returned to the IVR. Response : " + pinMailerRtn.toString());
		logger.info("GeneratePinMailer(); Exit ");
		log.info("GeneratePinMailer(); Response is returned to the IVR. Response : " + pinMailerRtn.toString());
		log.info("GeneratePinMailer(); Exit ");
		return pinMailerRtn;
	}

}

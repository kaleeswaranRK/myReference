/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.common;

import java.util.logging.Logger;

/**
 * This class is responsible for setting the log4j properties file path
 * 
 * @author Purvi Lad / Real Soft (Intl) Pvt. Ltd.
 * @version $Revision: 1.6 $ $Date: 2010/07/12 10:40:13 $
 */

public class Utility {

	public static String log4jpath = "";

	public static Logger getLogger() {
		return Logger.getLogger("SOA");
	}
}
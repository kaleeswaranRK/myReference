package com.realsoftinc.amex.mq.returnObjs;


import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class ScreenPopDetailsReturn 
{
	public String ErrorCode = emptyStr;
	public String ErrorDescription = emptyStr;
	public String Status = emptyStr;
	
	public AccountInformation accinfo = null;
	public ContDetails contactDet = null;
	public PaymentHist pmtHistory = null;
	public MRInformation mrInfo= null;
	
	public String toString()
	{
		String returnStr = newLine +
				resErrorCode + ErrorCode + newLine  +
				resErrorDesc + ErrorDescription	+ newLine  +
				resStatus + Status + newLine + " Payment History details : " +pmtHistory.toString() + newLine
				+ " Contact Details " + contactDet.toString() + newLine +  "Account Info : " + accinfo.toString() + newLine;
			
		return returnStr;
	}
	
}

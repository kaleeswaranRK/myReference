/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function LoginRequest to get SSO
 * 
 * @author Purvi Lad / Real Soft (Intl) Pvt. Ltd.
 * @version $Revision: 1.7 $ $Date: 2010/07/12 10:40:55 $
 */

public class LoginRequest {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(LoginRequest.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public String loginReq() {
		logger.info("loginReq(); Login Request function is called .. ");
		logger.info("loginReq(); Enter ");
		log.info("loginReq(); Login Request function is called .. ");
		log.info("loginReq(); Enter ");

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		MQCommon mqc = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;
		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;

		String ssoStr = emptyStr;
//		@SuppressWarnings("unused")
		String dateTimeStampStr = emptyStr;
//		@SuppressWarnings("unused")
		String auditSeqStr = emptyStr;
		String msgIdActualStr = emptyStr;
		String SSO = emptyStr;

		try {
			xmlMap = new HashMap<String, String>();

			mqc = new MQCommon();
			rc = new RequestCreater();
			rr = new RequestResponse();
			respParser = new ResponseParser();
			logger.info("loginReq(); Calling the getDateTime function ..");

			log.info("loginReq(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("loginReq(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("loginReq(); Calling the getAuditSequence function ..");
			log.info("loginReq(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("loginReq(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("loginReq(); Audit Sequence is : " + auditSeqInStr);

			logger.info("loginReq(); Created all the required parameters to prepare the xml ..");
			log.info("loginReq(); Audit Sequence is : " + auditSeqInStr);

			log.info("loginReq(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("MessageLength", mqc.getproperties("Login.MsgLength"));
			xmlMap.put("MessageId", MsgId_LoginReq);
			xmlMap.put("Description", Login_Desc);
			xmlMap.put("username", mqc.getproperties("Login.UserName"));
			logger.info("loginReq(); Sending values to form proper format of xml request .. ");

			log.info("loginReq(); Sending values to form proper format of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "LoginRequest".trim());
			logger.info("loginReq(); Received xml in proper format ..");
			logger.info("loginReq(); XML is : " + xmlReq);

			logger.info("loginReq(); Sending this xml as the request to MQ ..");
			log.info("loginReq(); Received xml in proper format ..");
			log.info("loginReq(); XML is : " + xmlReq);

			log.info("loginReq(); Sending this xml as the request to MQ ..");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("loginReq(); Response received from MQ .. ");
			logger.info("loginReq(); Received response from MQ is : " + replyMsg);
			log.info("loginReq(); Response received from MQ .. ");
			log.info("loginReq(); Received response from MQ is : " + replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("loginReq(); Sending the received response from MQ to the parser ..");
				logger.info("loginReq(); XML sent for parsing is :" + replyMsg);
				log.info("loginReq(); Sending the received response from MQ to the parser ..");
				log.info("loginReq(); XML sent for parsing is :" + replyMsg);
				map = respParser.XmlParser(replyMsg);
				logger.info("loginReq(); Received Hash map after parsing of response.");

				log.info("loginReq(); Received Hash map after parsing of response.");

				ssoStr = (String) map.get("ssoStr");
				dateTimeStampStr = (String) map.get("dateTimeStampStr");
				auditSeqStr = (String) map.get("auditSeqStr");
				msgIdActualStr = (String) map.get("msgIdActualStr");

				if (MsgId_LoginResp.equalsIgnoreCase(msgIdActualStr)) {
					log.info("loginReq(); Response MsgId is as per Request MsgId");
					SSO = ssoStr;
					log.info("loginReq(); SSO is set as : " + SSO);
				}
			} else {
				logger.info("loginReq(); Since the response from MQ is not proper .. ");
				logger.info("loginReq(); Setting empty value for SSO.");
				log.info("loginReq(); Since the response from MQ is not proper .. ");
				log.info("loginReq(); Setting empty value for SSO.");
				ssoStr = emptyStr;
			}
		} catch (Exception e) {
			logger.info("loginReq(); Exception is raised." + e.toString());

			log.info("loginReq(); Exception is raised." + e.toString());
			ssoStr = emptyStr;
			logger.error("loginReq(); Reason : " + e.getStackTrace());

			log.severe("loginReq(); Reason : " + e.getStackTrace());

		} finally {
			xmlMap = null;
			map = null;
			mqc = null;
			rc = null;
			rr = null;
			respParser = null;

			xmlReq = emptyStr;
			replyMsg = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			dateTimeStampStr = emptyStr;
			auditSeqStr = emptyStr;
			msgIdActualStr = emptyStr;
			SSO = emptyStr;
		}
		logger.info("loginReq(); SSO String returned is : " + ssoStr);
		logger.info("loginReq(); Exit");
		log.info("loginReq(); SSO String returned is : " + ssoStr);
		log.info("loginReq(); Exit");
		return ssoStr;
	}
}

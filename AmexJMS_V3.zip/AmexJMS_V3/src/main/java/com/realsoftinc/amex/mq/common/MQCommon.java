/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.common;

import static com.realsoftinc.amex.mq.common.MQConstants.emptyStr;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Logger;

import javax.jms.JMSException;
import javax.jms.QueueConnectionFactory;
import javax.naming.InitialContext;
import javax.naming.NamingException;


import com.realsoftinc.amex.mq.functions.LoginRequest;

/**
 * This class is responsible for having common methods that are used across the
 * projects by various functions
 * 
 * @author Purvi Lad / Real Soft (Intl) Pvt. Ltd.
 * @version $Revision: 1.7 $ $Date: 2010/07/12 10:40:13 $
 */

public class MQCommon {
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(MQCommon.class);

	Logger log = Utility.getLogger();
	// final static Logger log = Logger.getLogger(MQCommon.class);

	public MQCommon() {
		// BasicConfigurator.configure();
	}

	public static String SSO;

	private static String configFilePath = "";

	public static String getConfigFilePath() {
		return configFilePath;
	}

	public static void setConfigFilePath(String inputFilePath) {
		configFilePath = inputFilePath;
	}

	// @SuppressWarnings("static-access")
	public Map<String, Object> openQueues() throws JMSException {
		logger.info("openQueues(); Enter");
		log.info("openQueues(); Enter");

		Map<String, Object> qMap = null;

		try {

			qMap = new HashMap<String, Object>();
			logger.info("InitialContext; Enter");
			log.info("InitialContext; Enter");
			// System.out.println("InitialContext; Enter");
			InitialContext ctx = new InitialContext();
			logger.info("ConnectionFactory; Enter");

			log.info("ConnectionFactory; Enter");
			// System.out.println("ConnectionFactory; Enter");
			QueueConnectionFactory qcf = (QueueConnectionFactory) ctx.lookup((getproperties("jndiName")).trim());
			logger.info("Context Lookup: Success");

			log.info("Context Lookup: Success");

			// System.out.println("CreateConnection; Enter");
			// Connection conn = qcf.createConnection();
			// QueueConnection conn = (QueueConnection) qcf.createQueueConnection();

			// Queue vpIn = (Queue) ctx.lookup((getproperties("inputQueue")).trim());
			// Queue vpOut = (Queue) ctx.lookup((getproperties("outputQueue")).trim());

			String vpIn_St = (getproperties("inputQueue")).trim();
			String vpOut_St = (getproperties("outputQueue")).trim();

			Object vpIn = vpIn_St;
			Object vpOut = vpOut_St;
			logger.info("Reading Queue: Success");

			log.info("Reading Queue: Success");
			// log.info("openQueues(); Values - QCF : " + qcf.toString() + newLine + "vpin
			// : " + vpIn.toString() + newLine + "vpout: " + vpOut.toString() + newLine);

			qMap.put("vpIn", vpIn);
			qMap.put("vpOut", vpOut);
			qMap.put("qcf", qcf);
			// conn.start();

		} catch (NamingException e1) {
			logger.error("openQueues(); NamingException is raised. Reason : " + e1.getExplanation());

			log.severe("openQueues(); NamingException is raised. Reason : " + e1.getExplanation());
		} finally {

		}
		logger.info("openQueues(); Exit");

		log.info("openQueues(); Exit");
		return qMap;
	}

	public static String getDateTime() {
		DateFormat dateFormat2 = new SimpleDateFormat("ddMMyyyyHHmmss");
		Date date = new Date();
		String retStr = dateFormat2.format(date);
		return retStr;
	}

	public static String getDate() {
		DateFormat dateFormat2 = new SimpleDateFormat("ddMMyyyy");
		Date date = new Date();
		String retStr = dateFormat2.format(date);
		return retStr;
	}

	public static String getTime() {
		DateFormat dateFormat2 = new SimpleDateFormat("HHmm");
		Date date = new Date();
		String retStr = dateFormat2.format(date);
		return retStr;
	}

	public static String getAuditSequence() {
		String auditSeq = emptyStr;
		// Generates random number in between 10000000 to 99999999
		Random rand = new Random();
		int min, max;

		min = 10000000;
		max = 99999999;
		// nextInt is normally exclusive of the top value,
		// so add 1 to make it inclusive
		int randomNum = rand.nextInt(max - min + 1) + min;
		auditSeq = emptyStr + randomNum;
		return auditSeq;
	}

	public static String getproperties(String key) {
		String configFilePath1 = configFilePath;
		Properties prop = null;
		String value = emptyStr;
		FileInputStream fin = null;
		try {
			prop = new Properties();
			fin = new FileInputStream(configFilePath1);
			prop.load(fin);
			value = prop.getProperty(key);
		} catch (Exception e) {
			value = emptyStr;
			logger.error("Exception"+e);
			

		} finally {
			try {
				fin.close();
			} catch (IOException e1) {
				logger.error("fin close "+e1);
			}
		}
		return value;
	}

	public static String getCurrentYear() {
		DateFormat yearFormat = new SimpleDateFormat("yyyy");
		Date date = new Date();
		String currentYear = yearFormat.format(date);
		return currentYear;
	}

	public static String getCurrentMonth() {
		DateFormat monthFormat = new SimpleDateFormat("MM");
		Date date = new Date();
		String currentMonth = monthFormat.format(date);
		return currentMonth;
	}

	public static String getCurrentDay() {
		DateFormat dayFormat = new SimpleDateFormat("dd");
		Date date = new Date();
		String currentDay = dayFormat.format(date);
		return currentDay;
	}

	public String getSSO() {
		logger.info("getSSO(); Enter");

		log.info("getSSO(); Enter");
		LoginRequest lr = new LoginRequest();
		SSO = lr.loginReq();
		logger.info("getSSO(); SSO value returned : " + SSO);
		logger.info("getSSO(); Exit");

		log.info("getSSO(); SSO value returned : " + SSO);
		log.info("getSSO(); Exit");
		return SSO;
	}

	public static void maskAccNumber(String description, String content) {
		// This function replace account number digits by * in SOA log files
		Logger log = Utility.getLogger();
		//
		int start = -1;
		int end = -1;
		start = content.indexOf("<AccountNumber>");
		end = content.indexOf("</AccountNumber>");

		if ((start != -1) && (end != -1) && (end - start) > 24)
			content = content.substring(0, start + 19) + "******" + content.substring(end - 5, content.length());

		start = content.indexOf("<CardNumber>");
		end = content.indexOf("</CardNumber>");

		if ((start != -1) && (end != -1) && (end - start) > 21)
			content = content.substring(0, start + 16) + "******" + content.substring(end - 5, content.length());

		start = content.indexOf("<XRef1>");
		end = content.indexOf("</XRef1>");

		if ((start != -1) && (end != -1) && (end - start) > 16)
			content = content.substring(0, start + 11) + "******" + content.substring(end - 5, content.length());

		start = content.indexOf("<XRef2>");
		end = content.indexOf("</XRef2>");

		if ((start != -1) && (end != -1) && (end - start) > 16)
			content = content.substring(0, start + 11) + "******" + content.substring(end - 5, content.length());
		logger.info(description + content);

		log.info(description + content);

	}

	public static void maskCardNumber(String description, String content) {
		// This function replace account number digits by * in log files
		Logger log = Utility.getLogger();
		int start = -1;
		int end = -1;
		start = content.indexOf("<CardNumber>");
		end = content.indexOf("</CardNumber>");
		if ((start != -1) && (end != -1) && (end - start) > 24)
			content = content.substring(0, start + 16) + "******" + content.substring(end - 5, content.length());
		logger.info(description + content);

		log.info(description + content);
	}
}

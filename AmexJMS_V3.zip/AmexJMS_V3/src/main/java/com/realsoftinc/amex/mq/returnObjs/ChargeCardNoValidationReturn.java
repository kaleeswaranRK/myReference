package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class ChargeCardNoValidationReturn 
{
	public String errorCode = emptyStr;
	public String title = emptyStr;
	public String name = emptyStr;
	public String status = emptyStr;
	public String accountNum = emptyStr;
	
	public String toString()
	{
		String returnStr = newLine +
				resErrorCode + errorCode  + newLine +
				resTitle + title      + newLine  +
				resName + name       + newLine  +
				resStatus + status     + newLine +
				resAccNum + accountNum + newLine ;
		return returnStr;
	}
}

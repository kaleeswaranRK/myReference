/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.ChargeCardAccountBalanceReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for having the main business logic for Charge Card
 * AccountBalance Function
 * 
 * @name ChargeCardAccountBalance
 * @author Purvi Lad
 * @version 1.0 Date 11 Mar 2010
 */
public class ChargeCardAccountBalance {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(ChargeCardAccountBalance.class);

	@SuppressWarnings({ "unchecked" })
	public ChargeCardAccountBalanceReturn chargeCardAccountBal(String cardNum) {
		logger.info("chargeCardAccountBal(); Charge Card Account Balance function is called by IVR .. ");
		logger.info("chargeCardAccountBal(); Enter ");
		log.info("chargeCardAccountBal(); Charge Card Account Balance function is called by IVR .. ");
		log.info("chargeCardAccountBal(); Enter ");

		ChargeCardAccountBalanceReturn ccAccBalRtn = null;
		Map<String, String> xmlMap = null;
		Map<String, String> map = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser cardnoparser = null;

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		String errorCode = emptyStr;
		String returnMsgIdActualStr = emptyStr;
		String maskCardNum = emptyStr;

		try {
			ccAccBalRtn = new ChargeCardAccountBalanceReturn();
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			cardnoparser = new ResponseParser();

			if (cardNum.length() == 15) {

				maskCardNum = cardNum.substring(0, 4) + "******"
						+ cardNum.substring(cardNum.length() - 5, cardNum.length());
				logger.info("chargeCardAccountBal(); Card Number is : " + maskCardNum);

				log.info("chargeCardAccountBal(); Card Number is : " + maskCardNum);
			} else {
				logger.info("chargeCardAccountBal(); Card Number is less than 15 digits.");

				log.info("chargeCardAccountBal(); Card Number is less than 15 digits.");
			}
			logger.info("chargeCardAccountBal(); Created all the required parameters to prepare the xml ..");

			log.info("chargeCardAccountBal(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("AccountNumber", cardNum);
			xmlMap.put("MessageId", MsgId_ChrgCrdAccBal);
			xmlMap.put("sourceApp", ChrgCrdSrcApp);
			logger.info("chargeCardAccountBal(); Sending values to form proper form of xml request .. ");

			log.info("chargeCardAccountBal(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "ChargeCardAccountBalance");
			logger.info("chargeCardAccountBal(); Received xml in proper format ..");
			logger.info("chargeCardAccountBal(); XML is : " + xmlReq);

			logger.info("chargeCardAccountBal(); Sending the prepared xml to MQ .. ");
			log.info("chargeCardAccountBal(); Received xml in proper format ..");
			log.info("chargeCardAccountBal(); XML is : " + xmlReq);

			log.info("chargeCardAccountBal(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("chargeCardAccountBal(); Response received from MQ .. ");
			logger.info("chargeCardAccountBal(); Received response from MQ is : " + replyMsg);
			log.info("chargeCardAccountBal(); Response received from MQ .. ");
			log.info("chargeCardAccountBal(); Received response from MQ is : " + replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("chargeCardAccountBal(); Sending the received response from MQ to the parser ..");
				logger.info("chargeCardAccountBal(); XML sent for parsing is :" + replyMsg);
				log.info("chargeCardAccountBal(); Sending the received response from MQ to the parser ..");
				log.info("chargeCardAccountBal(); XML sent for parsing is :" + replyMsg);
				map = cardnoparser.XmlParser(replyMsg);
				logger.info("chargeCardAccountBal(); Received Hash map after parsing of response.");

				log.info("chargeCardAccountBal(); Received Hash map after parsing of response.");

				errorCode = (String) map.get("errorCode");

				ccAccBalRtn.errorCode = errorCode;
				returnMsgIdActualStr = (String) map.get("returnMsgIdActualStr");

				// 10th Digit of Charge Card Number indicates the Billing Cycle.
				// Step-1 : Collecting last 15 digits
				cardNum = cardNum.substring(cardNum.length() - 15, cardNum.length());
				// Step-2 : Getting 10th digit
				ccAccBalRtn.billingCycle = cardNum.substring(9, 10);

				if (errorCode.equalsIgnoreCase("0") || errorCode.equalsIgnoreCase("00")
						|| errorCode.equalsIgnoreCase("000") || errorCode.equalsIgnoreCase("0000")) {
					logger.info("chargeCardAccountBal(); Response from MQ is 'SUCCESS'.. ");

					log.info("chargeCardAccountBal(); Response from MQ is 'SUCCESS'.. ");
					ccAccBalRtn.amountDue = (String) map.get("billBal");
					ccAccBalRtn.currentBalance = (String) map.get("toDateBal");
					ccAccBalRtn.dateLastStatement = (String) map.get("billDt");
					ccAccBalRtn.accountStatusMessage = (String) map.get("statusMsg");
					ccAccBalRtn.errorCode = errorCode;
					ccAccBalRtn.status = validStr;
				} else {
					logger.info("chargeCardAccountBal(); Response from MQ is 'FAILURE'.. ");

					log.info("chargeCardAccountBal(); Response from MQ is 'FAILURE'.. ");
					ccAccBalRtn.errorCode = errorCode;
					ccAccBalRtn.status = invalidStr;
				}
				if (MsgId_ChrgCrdAccBalResp.equalsIgnoreCase(returnMsgIdActualStr)) {
					logger.info("Getting valid msg id from the response.");

					log.info("Getting valid msg id from the response.");
				} else {
					logger.info("chargeCardAccountBal(); Since the response from MQ is not proper .. ");
					logger.info("chargeCardAccountBal(); Setting error values.");
					log.info("chargeCardAccountBal(); Since the response from MQ is not proper .. ");
					log.info("chargeCardAccountBal(); Setting error values.");
					ccAccBalRtn.errorCode = MQConstants.errorCode;
					ccAccBalRtn.status = invalidStr;
				}
			} else {
				logger.info("chargeCardAccountBal(); Since the response from MQ is not proper .. ");
				logger.info("chargeCardAccountBal(); Setting error values.");
				log.info("chargeCardAccountBal(); Since the response from MQ is not proper .. ");
				log.info("chargeCardAccountBal(); Setting error values.");
				ccAccBalRtn.errorCode = MQConstants.errorCode;
				ccAccBalRtn.status = invalidStr;
			}
		} catch (Exception e) {
			logger.info("chargeCardAccountBal(); Exception is raised." + e.toString());

			log.info("chargeCardAccountBal(); Exception is raised." + e.toString());
			ccAccBalRtn.errorCode = MQConstants.errorCode;
			ccAccBalRtn.status = invalidStr;
			logger.error("chargeCardAccountBal(); Reason : " + e.getStackTrace());

			log.severe("chargeCardAccountBal(); Reason : " + e.getStackTrace());
		} finally {
			xmlMap = null;
			map = null;
			rc = null;
			rr = null;
			cardnoparser = null;

			xmlReq = emptyStr;
			replyMsg = emptyStr;
			errorCode = emptyStr;
			returnMsgIdActualStr = emptyStr;
		}
		logger.info("chargeCardAccountBal(); Response is returned to the IVR. Response : " + ccAccBalRtn.toString());
		logger.info("chargeCardAccountBal(); Exit");
		log.info("chargeCardAccountBal(); Response is returned to the IVR. Response : " + ccAccBalRtn.toString());
		log.info("chargeCardAccountBal(); Exit");
		return ccAccBalRtn;
	}
}

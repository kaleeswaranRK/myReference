package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class AccountDetailReturn {

	public String errorCode = emptyStr;
	public String errorDescription = emptyStr;
	public String status = emptyStr;

	public AccountDtl accuntDtl = null;

	public String toString() {
		String returnStr = emptyStr;

		returnStr = newLine +
				resErrorCode + errorCode + newLine +
				resErrorDesc + errorDescription + newLine +
				resStatus + status + newLine ;

		if (accuntDtl != null) {
			returnStr = returnStr +
					accuntDtl.toString() +
					newLine ;
		} 

		return returnStr;
	}

}

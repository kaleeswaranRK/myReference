package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class AccountBalanceReturn 
{
	public String errorCode = emptyStr;
	public String errorDescription = emptyStr;
	public String status = emptyStr;
	//public String maskAccNum = emptyStr;
	public AccountInformation accInfo= null;
	
	public String toString()
	{
		String returnStr = emptyStr;
		if(accInfo != null)
		{
			//maskAccNum = accInfo.AccountNumber.replace(accInfo.AccountNumber.subSequence(4, accInfo.AccountNumber.length()-5),maskString1);
			returnStr = newLine +
			resErrorCode + errorCode  + newLine +
			resErrorDesc + errorDescription + newLine +
			resStatus + status + newLine +			
			//resAccNum + maskAccNum + newLine +			
			resCurrentBalance + accInfo.CurrentBalance + newLine +
			resAmountDue + accInfo.AmountDue + newLine +
			resTotalCreditLimit + accInfo.TotalCreditLimit + newLine +
			resCashCreditLimit + accInfo.CashCreditLimit + newLine +
			resCashBalance + accInfo.CashBalance + newLine +
			resCashAvailable + accInfo.CashAvailable + newLine +
			resOTB + accInfo.OTB + newLine +
			resBeginBalance + accInfo.BeginBalance + newLine +			
			resStatus + accInfo.Status + newLine +
			resPastDue + accInfo.PastDue + newLine +
			resLastPurchase + accInfo.LastPurchase + newLine +
			resBillingCycle + accInfo.BillingCycle + newLine +
			resDateOpened + accInfo.DateOpened + newLine +
			resDueDate + accInfo.DueDate + newLine +
			resDateLastPayment + accInfo.DateLastPayment + newLine +
			resDateLastStatement + accInfo.DateLastStatement + newLine +
			resLastStatBal + accInfo.LastStatBalance + newLine +
			resAmountPurchCTD + accInfo.AmountPurchCTD + newLine +
			resAmountPurchYTD + accInfo.AmountPurchYTD + newLine +
			resAmountPurchLTD + accInfo.AmountPurchLTD + newLine +
			resAmountCashCTD + accInfo.AmountCashCTD + newLine +
			resAmountCashYTD + accInfo.AmountCashYTD + newLine +
			resAmountCashLTD + accInfo.AmountCashLTD + newLine +
			resBlockCode + accInfo.BlockCode + newLine +
			resBlockCode2+ accInfo.BlockCode2 + newLine +
			resOverdueFlag + accInfo.OverdueFlag + newLine +
			resMemoBalance + accInfo.MemoBalance + newLine +
			resDateCardFee + accInfo.DateCardFee + newLine +
			resCTAReason + accInfo.CTAReason + newLine +
			resMemberSince + accInfo.MemberSince + newLine ;
			
		}
		else
		{
			returnStr = newLine +
			resErrorCode + errorCode                 + newLine +
			resErrorDesc + errorDescription          + newLine +
			resStatus + status                    + newLine ;
		}		
		return returnStr;
	}
}
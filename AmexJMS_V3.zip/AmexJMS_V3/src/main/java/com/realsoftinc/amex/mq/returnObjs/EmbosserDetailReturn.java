package com.realsoftinc.amex.mq.returnObjs;


import static com.realsoftinc.amex.mq.common.MQConstants.*;


public class EmbosserDetailReturn 
{
	public String ErrorCode = emptyStr;
	public String ErrorDescription = emptyStr;
	public String firstUsageFlag = emptyStr;	// Current flag
	public String priorUsageFlag = emptyStr;  // Last flag
	public String cardExpiryDate = emptyStr;
	public String DBC = emptyStr;
	public String embossName = emptyStr;

	public String toString()
	{
		String returnStr = newLine +
			resErrorCode + ErrorCode + newLine +
			resErrorDesc + ErrorDescription + newLine +
			//"firstUsageFlag :" + firstUsageFlag + newLine +
			//"priorUsageFlag :" + priorUsageFlag + newLine + 
			//"cardExpiryDate : " + cardExpiryDate + newLine +
			resDBC + DBC + newLine +
			resExpiryDate + cardExpiryDate + newLine +
			resEmbossName + embossName + newLine;
		return returnStr;
	}
}



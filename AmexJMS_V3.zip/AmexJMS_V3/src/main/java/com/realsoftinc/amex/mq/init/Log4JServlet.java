package com.realsoftinc.amex.mq.init;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

@SuppressWarnings("serial")
public class Log4JServlet extends HttpServlet {

   public void init() throws ServletException{

      String log4jfile = getInitParameter("log4j-init-file");
      if (log4jfile != null) {
         String propfile = getServletContext().getRealPath(log4jfile);
         //PropertyConfigurator.configure(propfile); 	
      }
   }
}
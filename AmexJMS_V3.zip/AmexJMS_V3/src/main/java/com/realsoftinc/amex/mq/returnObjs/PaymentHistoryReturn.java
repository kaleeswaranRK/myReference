package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class PaymentHistoryReturn 
{
	public String errorCode = emptyStr;
	public String errorDescription = emptyStr;
	public String status = emptyStr;
	
	public PaymentHist pmtHistory = null;
	
	public String toString()
	{
		String returnStr = emptyStr;
		if(pmtHistory != null)
		{
			returnStr = newLine +
			resErrorCode + errorCode                      + newLine +
			resErrorDesc + errorDescription               + newLine +
			resStatus + status                         + newLine +			
			resAmountLastPayment + pmtHistory.AmountLastPayment   + newLine +
			resDateLastPayment + pmtHistory.DateLastPayment     + newLine +
			resDelqTPD + pmtHistory.DelqTPD             + newLine +
			resDelqXdayNumber + pmtHistory.DelqXdayNumber      + newLine +
			resDelqXdayAmount + pmtHistory.DelqXdayAmount      + newLine ;
		}
		else
		{
			returnStr = newLine +
			resErrorCode + errorCode                      + newLine +
			resErrorDesc + errorDescription               + newLine +
			resStatus + status                         + newLine ;
		}
		return returnStr;
	}
}
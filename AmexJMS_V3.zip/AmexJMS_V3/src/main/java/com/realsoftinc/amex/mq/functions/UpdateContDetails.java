/*
* (C) Copyright 2013 Geomant Kft. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.UpdateContDetailsReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function Update Contact Details
 * 
 * @author Marijana Dujovic / Geomant Kft.
 */
public class UpdateContDetails {

	Logger log = Utility.getLogger();
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(UpdateContDetails.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public UpdateContDetailsReturn updateDetails(String CardNum, String WorkNoCC, String WorkNo, String HomeNoCC,
			String HomeNo, String MobNoCC, String MobNo) {
		logger.info("updateDetails(); Update Details function is called by IVR .. ");
		logger.info("updateDetails(); Enter ");

		log.info("updateDetails(); Update Details function is called by IVR .. ");
		log.info("updateDetails(); Enter ");

		MQCommon mqc = null;
		UpdateContDetailsReturn ucdRtn = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		String xmlReq = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String replyMsg = emptyStr;
		String msgId = emptyStr;
		String errorDescription = emptyStr;
		String errCode = emptyStr;

		String maskCardNum = emptyStr;

		try {
			mqc = new MQCommon();
			rc = new RequestCreater();
			rr = new RequestResponse();
			respParser = new ResponseParser();
			ucdRtn = new UpdateContDetailsReturn();
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();

			if (CardNum.length() == 15) {
				// maskCardNum = CardNum.replace(CardNum.subSequence(4,
				// CardNum.length()-5),maskString1);
				maskCardNum = CardNum.substring(0, 4) + "******"
						+ CardNum.substring(CardNum.length() - 5, CardNum.length());
				logger.info("updateDetails(); Card Number is : " + maskCardNum);

				log.info("updateDetails(); Card Number is : " + maskCardNum);
			} else {
				logger.info("updateDetails(); Card Number is less than 15 digits.");

				log.info("updateDetails(); Card Number is less than 15 digits.");
			}
			logger.info("updateDetails(); Calling the getDateTime function ..");

			log.info("updateDetails(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("updateDetails(); DateTimeStamp is : " + dateTimeStampInStr);
			logger.info("updateDetails(); Calling the getAuditSequence function ..");

			log.info("updateDetails(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("updateDetails(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("updateDetails(); Audit Sequence is : " + auditSeqInStr);

			logger.info("updateDetails(); Created all the required parameters to prepare the xml ..");
			log.info("updateDetails(); Audit Sequence is : " + auditSeqInStr);

			log.info("updateDetails(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("MessageLength", mqc.getproperties("UpdateConDet.MsgLength"));
			xmlMap.put("Description", UpdateConDet_Desc);
			xmlMap.put("MessageId", MsgId_UpdateConDet);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("CardNumber", CardNum);
			xmlMap.put("HomeNOCountryCode", HomeNoCC);
			xmlMap.put("HomeNO", HomeNo);
			xmlMap.put("MobileNOCountryCode", MobNoCC);
			xmlMap.put("MobileNO", MobNo);
			xmlMap.put("WorkNOCountryCode", WorkNoCC);
			xmlMap.put("WorkNO", WorkNo);
			xmlMap.put("EmailID", emptyStr);
			xmlMap.put("SMSOptionFlag", mqc.getproperties("UpdateConDet.SMSOptionFlag"));
			xmlMap.put("EStatementOptionFlag", mqc.getproperties("UpdateConDet.EStatementOptionFlag"));
			xmlMap.put("RackFlag", mqc.getproperties("UpdateConDet.RackFlag"));
			xmlMap.put("username", mqc.getproperties("UpdateConDet.UserName"));
			xmlMap.put("password", mqc.getproperties("UpdateConDet.Password"));
			logger.info("updateDetails(); Sending values to form proper form of xml request .. ");

			log.info("updateDetails(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "UpdateConDet");
			logger.info("updateDetails(); Received xml in proper format ..");

			log.info("updateDetails(); Received xml in proper format ..");

			// Added to encrypt account and card number when display request in log file
			MQCommon.maskAccNumber("updateDetails(); XML is : ", xmlReq);
			logger.info("updateDetails(); Sending the prepared xml to MQ .. ");

			log.info("updateDetails(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("updateDetails(); Response received from MQ .. ");

			log.info("updateDetails(); Response received from MQ .. ");

			MQCommon.maskAccNumber("updateDetails(); Received response from MQ is : ", replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("updateDetails(); Sending the received response from MQ to the parser ..");

				log.info("updateDetails(); Sending the received response from MQ to the parser ..");
				// log.info("updateDetails(); XML sent for parsing is :"+ replyMsg);
				map = respParser.XmlParser(replyMsg);
				logger.info("updateDetails(); Received Hash map after parsing of response.");

				log.info("updateDetails(); Received Hash map after parsing of response.");

				errCode = (String) map.get("errCode");
				errorDescription = (String) map.get("errDesc");
				ucdRtn.errorCode = errCode;
				ucdRtn.errorDesc = errorDescription;

				if (ucdRtn.errorCode.equalsIgnoreCase("0") || ucdRtn.errorCode.equalsIgnoreCase("00")
						|| ucdRtn.errorCode.equalsIgnoreCase("000") || ucdRtn.errorCode.equalsIgnoreCase("0000")) {
					logger.info("updateDetails(); Response from MQ is 'SUCCESS'.. ");

					log.info("updateDetails(); Response from MQ is 'SUCCESS'.. ");
					msgId = (String) map.get("msgIdActualStr");

				} else {
					logger.info("updateDetails(); Response from MQ is 'FAILURE'.. ");

					log.info("updateDetails(); Response from MQ is 'FAILURE'.. ");

				}

				if (MsgId_UpdateConDetResp.equalsIgnoreCase(msgId)) {
					logger.info("updateDetails(); Getting valid msg id from the response.");

					log.info("updateDetails(); Getting valid msg id from the response.");
				} else {
					logger.info("updateDetails(); Since the response from MQ is not proper .. ");
					logger.info("updateDetails(); Setting error values.");
					log.info("updateDetails(); Since the response from MQ is not proper .. ");
					log.info("updateDetails(); Setting error values.");
					ucdRtn.errorCode = errorCode;
					ucdRtn.errorDesc = errorDesc;
				}
			}

			else {
				logger.info("updateDetails(); Since the response from MQ is not proper .. ");
				logger.info("updateDetails(); Setting error values.");
				log.info("updateDetails(); Since the response from MQ is not proper .. ");
				log.info("updateDetails(); Setting error values.");
				ucdRtn.errorCode = errorCode;
				ucdRtn.errorDesc = errorDesc;
			}

		} catch (Exception e) {
			logger.info("updateDetails(); Exception is raised." + e.toString());

			log.info("updateDetails(); Exception is raised." + e.toString());
			ucdRtn.errorCode = errorCode;
			ucdRtn.errorDesc = errorDesc;
			logger.error("updateDetails(); Reason : " + e.getStackTrace());

			log.severe("updateDetails(); Reason : " + e.getStackTrace());
		} finally {
			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			xmlMap = null;
			map = null;

			xmlReq = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			replyMsg = emptyStr;
			msgId = emptyStr;
			errorDescription = emptyStr;
			errCode = emptyStr;

			maskCardNum = emptyStr;

		}
		logger.info("updateDetails();  Response is returned to the IVR. Response : " + ucdRtn.toString());
		logger.info("updateDetails(); Exit");
		log.info("updateDetails();  Response is returned to the IVR. Response : " + ucdRtn.toString());
		log.info("updateDetails(); Exit");
		return ucdRtn;

	}

}

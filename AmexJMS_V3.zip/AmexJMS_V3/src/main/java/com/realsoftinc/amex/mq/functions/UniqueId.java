/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.UniqueIdReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function UniqueId
 * 
 * @author Purvi Lad / Real Soft (Intl) Pvt. Ltd.
 * @version $Revision: 1.7 $ $Date: 2010/07/12 10:40:55 $
 */

public class UniqueId {

	Logger log = Utility.getLogger();
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(UniqueId.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public UniqueIdReturn validateUniqueId(String uniqueId) {
		logger.info("validateUniqueId(); Validate Unique Id function is called by IVR .. ");
		logger.info("validateUniqueId(); Enter ");
		log.info("validateUniqueId(); Validate Unique Id function is called by IVR .. ");
		log.info("validateUniqueId(); Enter ");

		MQCommon mqc = null;
		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;
		UniqueIdReturn valUniqueIdRet = null;

		// String sso = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		String cardNum = emptyStr;
		String accNum = emptyStr;
		String cardType = emptyStr;
		String errorDescription = emptyStr;
		String msgId = emptyStr;

		try {
			mqc = new MQCommon();
			rc = new RequestCreater();
			rr = new RequestResponse();
			respParser = new ResponseParser();
			new UniqueIdReturn();
			xmlMap = new HashMap<String, String>();
			valUniqueIdRet = new UniqueIdReturn();

			/*
			 * sso = MQCommon.SSO; if (sso == null) {
			 * log.info("validateUniqueId(); sso is null");
			 * log.info("validateUniqueId(); Calling getSSO() function .. "); sso =
			 * mqc.getSSO(); } else { if (sso.equalsIgnoreCase(emptyStr)) {
			 * log.info("validateUniqueId(); sso is empty string");
			 * log.info("validateUniqueId(); Calling getSSO() function .. "); sso =
			 * mqc.getSSO(); } }
			 */
			logger.info("validateUniqueId(); Unique Id is : " + uniqueId);

			logger.info("validateUniqueId(); Calling the getDateTime function ..");
			log.info("validateUniqueId(); Unique Id is : " + uniqueId);

			log.info("validateUniqueId(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("validateUniqueId(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("validateUniqueId(); Calling the getAuditSequence function ..");
			log.info("validateUniqueId(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("validateUniqueId(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("validateUniqueId(); Audit Sequence is : " + auditSeqInStr);

			logger.info("validateUniqueId(); Created all the required parameters to prepare the xml ..");
			log.info("validateUniqueId(); Audit Sequence is : " + auditSeqInStr);

			log.info("validateUniqueId(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("SSO", mqc.getproperties("UniqueId.SSO"));
			xmlMap.put("UniqueId", uniqueId);
			xmlMap.put("MessageLength", mqc.getproperties("UniqueId.MsgLength"));
			xmlMap.put("MessageId", MsgId_UniqueId);
			xmlMap.put("Description", UniqueId_Desc);
			xmlMap.put("RackFlag", mqc.getproperties("UniqueId.RackFlag"));
			xmlMap.put("username", mqc.getproperties("UniqueId.UserName"));
			xmlMap.put("password", mqc.getproperties("UniqueId.Password"));
			logger.info("validateUniqueId(); Sending values to form proper form of xml request .. ");

			log.info("validateUniqueId(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "UniqueId");
			logger.info("validateUniqueId(); Received xml in proper format ..");
			logger.info("validateUniqueId(); XML is : " + xmlReq);
			logger.info("validateUniqueId(); Sending the prepared xml to MQ .. ");
			log.info("validateUniqueId(); Received xml in proper format ..");
			log.info("validateUniqueId(); XML is : " + xmlReq);

			log.info("validateUniqueId(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("validateUniqueId(); Response received from MQ .. ");

			log.info("validateUniqueId(); Response received from MQ .. ");
			MQCommon.maskAccNumber("validateUniqueId(); Received response from MQ is : ", replyMsg);
			// log.info("validateUniqueId(); Received response from MQ is : " + replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("validateUniqueId(); Sending the received response from MQ to the parser ..");

				log.info("validateUniqueId(); Sending the received response from MQ to the parser ..");
				// log.info("validateUniqueId(); XML sent for parsing is :"+ replyMsg);
				map = respParser.XmlParser(replyMsg);
				logger.info("validateUniqueId(); Received Hash map after parsing of response.");

				log.info("validateUniqueId(); Received Hash map after parsing of response.");

				valUniqueIdRet.errorCode = (String) map.get("errCode");

				if (valUniqueIdRet.errorCode.equalsIgnoreCase("0") || valUniqueIdRet.errorCode.equalsIgnoreCase("00")
						|| valUniqueIdRet.errorCode.equalsIgnoreCase("000")
						|| valUniqueIdRet.errorCode.equalsIgnoreCase("0000")
						|| valUniqueIdRet.errorCode.equalsIgnoreCase("218")
						|| valUniqueIdRet.errorCode.equalsIgnoreCase("219")) {
					logger.info("validateUniqueId(); Response from MQ is 'SUCCESS'.. ");

					log.info("validateUniqueId(); Response from MQ is 'SUCCESS'.. ");

					cardNum = (String) map.get("cardNum");
					accNum = (String) map.get("accountNum");
					cardType = (String) map.get("cardType");
					errorDescription = (String) map.get("errDes");
					msgId = (String) map.get("msgIdActualStr");
					valUniqueIdRet.status = validStr;
				} else {
					logger.info("validateUniqueId(); Response from MQ is 'FAILURE'.. ");

					log.info("validateUniqueId(); Response from MQ is 'FAILURE'.. ");
					valUniqueIdRet.status = invalidStr;
				}
				if (MsgId_UniqueIdResp.equalsIgnoreCase(msgId)) {
					logger.info("Getting valid msg id from the response.");

					log.info("Getting valid msg id from the response.");
				} else {
					if (valUniqueIdRet.errorCode.equals("218") || valUniqueIdRet.errorCode.equals("219")) {
						logger.info("validateUniqueId(); Since the error code is 218 or 219 , sending it as it is to IVR");

						log.info("validateUniqueId(); Since the error code is 218 or 219 , sending it as it is to IVR");

					} else {
						logger.info("validateUniqueId(); Since the response from MQ is not proper .. ");
						logger.info("validateUniqueId(); Setting error values.");
						log.info("validateUniqueId(); Since the response from MQ is not proper .. ");
						log.info("validateUniqueId(); Setting error values.");
						valUniqueIdRet.errorCode = errorCode;

					}
				}

				if (accNum != "") {
					if (accNum.length() < 19) {
						int lengthOfAccountNumber = accNum.length();
						for (int i = 0; i < 19 - lengthOfAccountNumber; i++) {
							accNum = digitZero + accNum;
						}
						logger.info("validateUniqueId(); Account Number after padding zero : " + accNum);

						log.info("validateUniqueId(); Account Number after padding zero : " + accNum);
					}
				}

				valUniqueIdRet.errorDesc = errorDescription;
				valUniqueIdRet.accountNum = accNum;
				valUniqueIdRet.cardNum = cardNum;
				valUniqueIdRet.cardType = cardType;

			} else {
				logger.info("validateUniqueId(); Since the response from MQ is not proper .. ");
				logger.info("validateUniqueId(); Setting error values.");
				log.info("validateUniqueId(); Since the response from MQ is not proper .. ");
				log.info("validateUniqueId(); Setting error values.");
				valUniqueIdRet.errorCode = errorCode;
				valUniqueIdRet.errorDesc = errorDesc;
				valUniqueIdRet.status = invalidStr;
			}
		} catch (Exception e) {
			logger.error("validateUniqueId(); Exception is raised. Reason. " + e.getStackTrace());
			log.severe("validateUniqueId(); Exception is raised. Reason. " + e.getStackTrace());
			valUniqueIdRet.errorCode = errorCode;
			valUniqueIdRet.errorDesc = errorDesc;
			valUniqueIdRet.status = invalidStr;
			logger.error("validateUniqueId(); Reason : " + e.getStackTrace());

			log.severe("validateUniqueId(); Reason : " + e.getStackTrace());
		} finally {
			mqc = null;
			xmlMap = null;
			map = null;
			rc = null;
			rr = null;
			respParser = null;

			// sso = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			xmlReq = emptyStr;
			replyMsg = emptyStr;
			cardNum = emptyStr;
			accNum = emptyStr;
			cardType = emptyStr;
			errorDescription = emptyStr;
			msgId = emptyStr;

		}
		logger.info("validateUniqueId(); Response is returned to the IVR. Response : " + valUniqueIdRet.toString());
		logger.info("validateUniqueId(); Exit");
		log.info("validateUniqueId(); Response is returned to the IVR. Response : " + valUniqueIdRet.toString());
		log.info("validateUniqueId(); Exit");
		return valUniqueIdRet;
	}
}

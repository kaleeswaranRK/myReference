package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class CurrencyReturn 
{
	public String errorCode = emptyStr;
	public String errorDescription = emptyStr;
	public String status = emptyStr;
	public String currencyName = emptyStr;
	public String currencySymbol = emptyStr;
	public String primarySuppFlag	=	emptyStr;
	
	public String toString() 
	{
		String returnStr = emptyStr;		
		returnStr = newLine+
		resErrorCode + errorCode          + newLine +
		resErrorDesc + errorDescription	  + newLine +
		resStatus + status             + newLine +
		resCurrencyName + currencyName       + newLine +
		resCurrencySymbol + currencySymbol     + newLine +
		resPrimarySuppFlag + primarySuppFlag    + newLine ;
		return returnStr;
	}
}
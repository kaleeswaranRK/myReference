/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.functions;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.ContDetails;
import com.realsoftinc.amex.mq.returnObjs.PaymentHist;
import com.realsoftinc.amex.mq.returnObjs.AccountInformation;
import com.realsoftinc.amex.mq.returnObjs.AccountBalanceReturn;
import com.realsoftinc.amex.mq.returnObjs.ContactDetailsReturn;
import com.realsoftinc.amex.mq.returnObjs.PaymentHistoryReturn;
import com.realsoftinc.amex.mq.returnObjs.ScreenPopDetailsReturn;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function Screen Pop
 * 
 * @author Purvi Lad / Real Soft (Intl) Pvt. Ltd.
 * @version $Revision: 1.7 $ $Date: 2010/07/12 10:40:55 $
 */

public class ScreePopUP {

	Logger log = Utility.getLogger();
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(ScreePopUP.class);

	public ScreenPopDetailsReturn screenPop(String accNum) {
		logger.info("screenPop(); Screen Pop Up function is called by IVR .. ");
		logger.info("screenPop(); Enter ");
		log.info("screenPop(); Screen Pop Up function is called by IVR .. ");
		log.info("screenPop(); Enter ");

		ScreenPopDetailsReturn scrnPopDtlRtObj = null;
		ContactDetails cntctDtls = null;
		ContDetails contactDet = null;
		AccountInformation accInfo = null;
		AccountBalance accBal = null;
		PaymentHistory pmtHistory = null;
		PaymentHistoryReturn pmtHtRt = null;
		PaymentHist pymntHist = null;

//		@SuppressWarnings("unused")
		String accInfoErrorCode = emptyStr;
//		@SuppressWarnings("unused")
		String accInfoErrorDescription = emptyStr;
//		@SuppressWarnings("unused")
		String accInfoStatus = emptyStr;
//		@SuppressWarnings("unused")
		String contactDetErrorCode = emptyStr;
//		@SuppressWarnings("unused")
		String contactDetErrorDescription = emptyStr;
//		@SuppressWarnings("unused")
		String contactDetStatus = emptyStr;

//		@SuppressWarnings("unused")
		String pmtHistoryErrorCode = emptyStr;
//		@SuppressWarnings("unused")
		String pmtHistoryErrorDescription = emptyStr;
//		@SuppressWarnings("unused")
		String pmtHistoryStatus = emptyStr;
		String maskAccNum = emptyStr;

		try {
			if (accNum.length() == 12) {
				// maskAccNum = accNum.replace(accNum.subSequence(4,
				// accNum.length()-5),maskString2);
				maskAccNum = accNum.substring(0, 4) + "***" + accNum.substring(accNum.length() - 5, accNum.length());
				logger.info("cardActivate(); Account Number is : " + maskAccNum);

				log.info("cardActivate(); Account Number is : " + maskAccNum);
			} else {
				logger.info("cardActivate(); Account Number is less than 12 digits.");

				log.info("cardActivate(); Account Number is less than 12 digits.");
			}

			scrnPopDtlRtObj = new ScreenPopDetailsReturn();
			logger.info("screenPop(); Calling account balance function ..");

			log.info("screenPop(); Calling account balance function ..");
			accBal = new AccountBalance();
			accInfo = new AccountInformation();
			AccountBalanceReturn accBalRetObj = null;
			accBalRetObj = accBal.accountBal(accNum);
			accInfo = accBalRetObj.accInfo;

			accInfoErrorCode = accBalRetObj.errorCode;
			accInfoErrorDescription = accBalRetObj.errorDescription;
			accInfoStatus = accBalRetObj.status;
			logger.info("screenPop(); Calling contact details function ..");

			log.info("screenPop(); Calling contact details function ..");
			contactDet = new ContDetails();
			cntctDtls = new ContactDetails();
			ContactDetailsReturn cntDtlRtObj = null;
			cntDtlRtObj = cntctDtls.getContactDetails(accNum);
			contactDet = cntDtlRtObj.cntDetails;

			contactDetErrorCode = cntDtlRtObj.ErrorCode;
			contactDetErrorDescription = cntDtlRtObj.ErrorDescription;
			contactDetStatus = cntDtlRtObj.Status;
			logger.info("screenPop(); Calling payment history function ..");

			log.info("screenPop(); Calling payment history function ..");
			pmtHtRt = new PaymentHistoryReturn();
			pmtHistory = new PaymentHistory();
			pmtHtRt = pmtHistory.getPaymentHistory(accNum);

			pymntHist = pmtHtRt.pmtHistory;

			pmtHistoryErrorCode = pmtHtRt.errorCode;
			pmtHistoryErrorDescription = pmtHtRt.errorDescription;
			pmtHistoryStatus = pmtHtRt.status;

			scrnPopDtlRtObj.accinfo = accInfo;
			scrnPopDtlRtObj.contactDet = contactDet;
			scrnPopDtlRtObj.pmtHistory = pymntHist;

			// This index will be used to identify the errorCode /
			// errorDescription / Status of which msg we need to use for the
			// return object.
			// index = 1 ==> AccountBalance
			// index = 2 ==> ContactDetails
			// index = 3 ==> PaymentHistory
			// index = 4 ==> MRPointRewards
			int index = 0;

			if (accBalRetObj.errorCode.equalsIgnoreCase("0") || accBalRetObj.errorCode.equalsIgnoreCase("00")
					|| accBalRetObj.errorCode.equalsIgnoreCase("000")
					|| accBalRetObj.errorCode.equalsIgnoreCase("0000")) {
				index = 1;
				logger.info("screenPop(); AccountBalance function returned error code as zero ");

				log.info("screenPop(); AccountBalance function returned error code as zero ");
			}
			if (cntDtlRtObj.ErrorCode.equalsIgnoreCase("0") || cntDtlRtObj.ErrorCode.equalsIgnoreCase("00")
					|| cntDtlRtObj.ErrorCode.equalsIgnoreCase("000")
					|| cntDtlRtObj.ErrorCode.equalsIgnoreCase("0000")) {
				index = 2;
				logger.info("screenPop(); Contact Details function returned error code as zero");

				log.info("screenPop(); Contact Details function returned error code as zero");
			}
			if (pmtHtRt.errorCode.equalsIgnoreCase("0") || pmtHtRt.errorCode.equalsIgnoreCase("00")
					|| pmtHtRt.errorCode.equalsIgnoreCase("000") || pmtHtRt.errorCode.equalsIgnoreCase("0000")) {
				index = 3;
				logger.info("screenPop(); Payment History function returned error code as zero ");

				log.info("screenPop(); Payment History function returned error code as zero ");
			}

			if (index == 0)// Account Balance returned error
			{
				scrnPopDtlRtObj.ErrorCode = accBalRetObj.errorCode;
				scrnPopDtlRtObj.ErrorDescription = accBalRetObj.errorDescription;
				scrnPopDtlRtObj.Status = accBalRetObj.status;
				logger.info("screenPop(); Account Balance failed.");

				log.info("screenPop(); Account Balance failed.");

			}

			else if (index == 1) {// Contact Details returned error
				scrnPopDtlRtObj.ErrorCode = cntDtlRtObj.ErrorCode;
				scrnPopDtlRtObj.ErrorDescription = cntDtlRtObj.ErrorDescription;
				scrnPopDtlRtObj.Status = cntDtlRtObj.Status;
				logger.info("screenPop(); Contact Details failed.");

				log.info("screenPop(); Contact Details failed.");

			} else if (index == 2) {// Payment History returned error
				scrnPopDtlRtObj.ErrorCode = pmtHtRt.errorCode;
				scrnPopDtlRtObj.ErrorDescription = pmtHtRt.errorDescription;
				scrnPopDtlRtObj.Status = pmtHtRt.status;
				logger.info("screenPop(); Payment History failed.");

				log.info("screenPop(); Payment History failed.");

			} else if (index == 3) {// Success
				logger.info("screenPop(); All three functions passed.");

				log.info("screenPop(); All three functions passed.");
				scrnPopDtlRtObj.ErrorCode = pmtHtRt.errorCode;
				scrnPopDtlRtObj.ErrorDescription = pmtHtRt.errorDescription;
				scrnPopDtlRtObj.Status = pmtHtRt.status;

			}

		} catch (Exception e) {
			logger.info("screenPop(); Exception is raised." + e.toString());
			logger.error("screenPop(); Reason : " + e.getStackTrace());

			log.info("screenPop(); Exception is raised." + e.toString());
			log.severe("screenPop(); Reason : " + e.getStackTrace());
		} finally {
			cntctDtls = null;
			contactDet = null;
			accInfo = null;
			accBal = null;
			pmtHistory = null;
			pmtHtRt = null;
			pymntHist = null;

			accInfoErrorCode = emptyStr;
			accInfoErrorDescription = emptyStr;
			accInfoStatus = emptyStr;
			contactDetErrorCode = emptyStr;
			contactDetErrorDescription = emptyStr;
			contactDetStatus = emptyStr;
			pmtHistoryErrorCode = emptyStr;
			pmtHistoryErrorDescription = emptyStr;
			pmtHistoryStatus = emptyStr;
			maskAccNum = emptyStr;

		}
		logger.info("screenPop();");
		logger.info("screenPop(); Response is returned to the IVR. Response : " + scrnPopDtlRtObj.toString());
		logger.info("screenPop(); Exit");
		log.info("screenPop();");
		log.info("screenPop(); Response is returned to the IVR. Response : " + scrnPopDtlRtObj.toString());
		log.info("screenPop(); Exit");
		return scrnPopDtlRtObj;
	}

}

package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class CheckCSIEnrolledReturn 
{
	public String Length	 			= emptyStr;
	public String MessageID 			= emptyStr;
	public String AuditSeq	 			= emptyStr;
	public String DateTimeStamp			= emptyStr;
	public String EnrolledStatus 		= emptyStr;
	public String ErrorCode 			= emptyStr;
	public String ErrorDescription 		= emptyStr;
	public String Status 				= emptyStr;
	
	public String toString()
	{
		String returnStr = newLine +
				resLength		 		+ Length        	+ newLine +
				resMsgId	 			+ MessageID        	+ newLine +
				resAuditSeq 			+ AuditSeq        	+ newLine +
				resDateTimeStampLog		+ DateTimeStamp    	+ newLine +
				resEnrolledStatus 		+ EnrolledStatus   	+ newLine +
				resErrorCode 			+ ErrorCode        	+ newLine +
				resErrorDesc 			+ ErrorDescription 	+ newLine +
				resStatus 				+ Status            + newLine;
		return returnStr;
	}
}
package com.realsoftinc.amex.mq.util;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import java.util.logging.Logger;
import com.realsoftinc.amex.mq.common.Utility;
import org.dom4j.*;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.returnObjs.AccountDtlAvailableOffers;

public class ResponseParserAvailableOffers {
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(ResponseParserAvailableOffers.class);
	Logger log = Utility.getLogger();
	//final static Logger log = Logger.getLogger(RequestCreater.class);
	
	@SuppressWarnings("unchecked")
	public AccountDtlAvailableOffers[] responseParserAvailableOffers(String replyText)
    {
		logger.info("XmlParser(); Enter");
		log.info("XmlParser(); Enter");
		
        String campaignname = emptyStr;
        String startdate = emptyStr;
        String enddate = emptyStr;
        String compaigndetail = emptyStr;
        String origineFlag = emptyStr;
        
        AccountDtlAvailableOffers[] avaOff = null;
        try
        {
        	StringTokenizer st = new StringTokenizer(replyText ,"|");
        	if(st.hasMoreTokens()){
        		replyText = st.nextToken();
        		//log.info("XmlParser(); XMl string is : " + replyText);
        		//MQCommon.maskAccNumber("XmlParser(); XMl string is : " , replyText);
        	}
        	else{
        		logger.info("XmlParser(); 1st Condition not satisfied");

        		log.info("XmlParser(); 1st Condition not satisfied");
        	}        	
        
        	//xmlmap = new HashMap<String , String>();
            Document document = DocumentHelper.parseText(replyText);
            
            List list8 = document.selectNodes("//Message_Res/AvailableOffers/Message_Req/Offer");
            
			/**Get Account Detail**/
			Iterator iter8 = list8.iterator();
			logger.info("XmlParser(); Node is : //Message_Res/AvailableOffers/Message_Req/Offer");
			logger.info("Number Of AvailableOffers: "+list8.size());
			log.info("XmlParser(); Node is : //Message_Res/AvailableOffers/Message_Req/Offer");
			log.info("Number Of AvailableOffers: "+list8.size());
			
			avaOff = new AccountDtlAvailableOffers[list8.size()];
			int i = 0;
			
			while(iter8.hasNext())
			{	
				Element element = (Element)iter8.next();
				AccountDtlAvailableOffers avaOff_ = new AccountDtlAvailableOffers();
				
				for(Iterator iterator = element.elementIterator("CampaignName"); iterator.hasNext();)
	            {
	                 Element titleElement = (Element)iterator.next();
	                 campaignname = titleElement.getText().trim();
	                 logger.info("XmlParser(); CampaignName : " + campaignname );

	                 log.info("XmlParser(); CampaignName : " + campaignname );
	                 avaOff_.CampaignName = campaignname;
	            }
				for(Iterator iterator = element.elementIterator("StartDate"); iterator.hasNext();)
	            {
	                 Element titleElement = (Element)iterator.next();
	                 startdate = titleElement.getText().trim();
	                 logger.info("XmlParser(); StartDate : " + startdate );

	                 log.info("XmlParser(); StartDate : " + startdate );
	                 avaOff_.StartDate = startdate;
	            }
				for(Iterator iterator = element.elementIterator("EndDate"); iterator.hasNext();)
	            {
	                 Element titleElement = (Element)iterator.next();
	                 enddate = titleElement.getText().trim();
	                 logger.info("XmlParser(); EndDate : " + enddate );

	                 log.info("XmlParser(); EndDate : " + enddate );
	                 avaOff_.EndDate = enddate;
	            }
				for(Iterator iterator = element.elementIterator("CompaignDetail"); iterator.hasNext();)
	            {
	                 Element titleElement = (Element)iterator.next();
	                 compaigndetail = titleElement.getText().trim();
	                 logger.info("XmlParser(); CompaignDetail : " + compaigndetail );

	                 log.info("XmlParser(); CompaignDetail : " + compaigndetail );
	                 avaOff_.CampaignDetail = compaigndetail;
	            }
				for(Iterator iterator = element.elementIterator("OrigineFlag"); iterator.hasNext();)
	            {
	                 Element titleElement = (Element)iterator.next();
	                 origineFlag = titleElement.getText().trim();
	                 logger.info("XmlParser(); OrigineFlag : " + origineFlag );

	                 log.info("XmlParser(); OrigineFlag : " + origineFlag );
	                 avaOff_.OrigineFlag = origineFlag;
	            }
				
				avaOff[i] = avaOff_;
				i++;
			}
        }
        catch(DocumentException e)
        {
            logger.error((new StringBuilder("AvailableOffers In AccountDetails ValidationParser(); Document Exception is raised. Reason :")).append(e.getMessage()).toString());

            log.severe((new StringBuilder("AvailableOffers In AccountDetails ValidationParser(); Document Exception is raised. Reason :")).append(e.getMessage()).toString());
        }
        return avaOff;
    }


}

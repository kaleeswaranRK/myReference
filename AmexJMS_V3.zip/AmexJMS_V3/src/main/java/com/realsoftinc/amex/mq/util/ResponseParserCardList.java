package com.realsoftinc.amex.mq.util;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import java.util.logging.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.CardLst;

public class ResponseParserCardList {
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(ResponseParserCardList.class);

	Logger log = Utility.getLogger();
	// final static Logger log = Logger.getLogger(RequestCreater.class);

	@SuppressWarnings("unchecked")
	public CardLst[] responseParserCardList(String replyText) {
		logger.info("XmlParser(); Enter");
		log.info("XmlParser(); Enter");

		String uci = emptyStr;
		String cardnumber = emptyStr;
		String cardseq = emptyStr;
		String cmtitle = emptyStr;
		String cmfirstname = emptyStr;
		String cmfamilyname = emptyStr;
		String cmdateofbirth = emptyStr;
		String cmemail = emptyStr;
		String legalid = emptyStr;
		String mobilenumber = emptyStr;
		String clientcode = emptyStr;
		String accountnumber = emptyStr;
		String productcode = emptyStr;

		CardLst[] list = null;
		try {
			StringTokenizer st = new StringTokenizer(replyText, "|");
			if (st.hasMoreTokens()) {
				replyText = st.nextToken();
				// log.info("XmlParser(); XMl string is : " + replyText);
				// MQCommon.maskAccNumber("XmlParser(); XMl string is : " , replyText);
			} else {
				logger.info("XmlParser(); 1st Condition not satisfied");

				log.info("XmlParser(); 1st Condition not satisfied");
			}

			Document document = DocumentHelper.parseText(replyText);

			List list6 = document.selectNodes("//Message_Res/CardList/CardDetails");

			/** GetCard List **/
			Iterator iter6 = list6.iterator();
			logger.info("XmlParser(); Node is : //Message_Res/CardList/CardDetails");
			logger.info("Number Of CardDetails: " + list6.size());

			log.info("XmlParser(); Node is : //Message_Res/CardList/CardDetails");
			log.info("Number Of CardDetails: " + list6.size());

			list = new CardLst[list6.size()];
			int i = 0;

			while (iter6.hasNext()) {
				Element element = (Element) iter6.next();
				CardLst list_ = new CardLst();

				for (Iterator iterator = element.elementIterator("CardNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardnumber = titleElement.getText().trim();
					// log.info("XmlParser(); Card Number : " + cardnumber );
					list_.CardNumber = cardnumber;
				}
				for (Iterator iterator = element.elementIterator("CardSeq"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cardseq = titleElement.getText().trim();
					// log.info("XmlParser(); Card Seq is : " + cardseq );
					list_.CardSeq = cardseq;
				}
				for (Iterator iterator = element.elementIterator("UCI"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					uci = titleElement.getText().trim();
					// log.info("XmlParser(); UCI is : " + uci );
					list_.UCI = uci;
				}
				for (Iterator iterator = element.elementIterator("CMTitle"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmtitle = titleElement.getText().trim();
					// log.info("XmlParser(); CM Title is : " + cmtitle );
					list_.CMTitle = cmtitle;
				}
				for (Iterator iterator = element.elementIterator("CMFirstName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmfirstname = titleElement.getText().trim();
					// log.info("XmlParser(); CM First Name is : " + cmfirstname );
					list_.CMFirstName = cmfirstname;
				}
				for (Iterator iterator = element.elementIterator("CMFamilyName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmfamilyname = titleElement.getText().trim();
					// log.info("XmlParser(); CM Family Name is : " + cmfamilyname );
					list_.CMFamilyName = cmfamilyname;
				}
				for (Iterator iterator = element.elementIterator("CMDateOfBirth"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmdateofbirth = titleElement.getText().trim();
					// log.info("XmlParser(); CM Date Of Birth is : " + cmdateofbirth );
					list_.CMDateOfBirth = cmdateofbirth;
				}
				for (Iterator iterator = element.elementIterator("CMEmail"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					cmemail = titleElement.getText().trim();
					// log.info("XmlParser(); CM Email is : " + cmemail );
					list_.CMEmailID = cmemail;
				}
				for (Iterator iterator = element.elementIterator("LegalID"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					legalid = titleElement.getText().trim();
					// log.info("XmlParser(); Legal ID is : " + legalid );
					list_.LegalId = legalid;
				}
				for (Iterator iterator = element.elementIterator("MobileNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					mobilenumber = titleElement.getText().trim();
					// log.info("XmlParser(); Mobile Number is : " + mobilenumber );
					list_.MobileNO = mobilenumber;
				}
				for (Iterator iterator = element.elementIterator("ClientCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					clientcode = titleElement.getText().trim();
					// log.info("XmlParser(); Client Code is : " + clientcode );
					list_.ClientCode = clientcode;
				}
				for (Iterator iterator = element.elementIterator("AccountNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					accountnumber = titleElement.getText().trim();
					// log.info("XmlParser(); Account Number is : " + accountnumber );
					list_.AccountNum = accountnumber;
				}
				for (Iterator iterator = element.elementIterator("ProductCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					productcode = titleElement.getText().trim();
					// log.info("XmlParser(); Product Code is : " + productcode );
					list_.ProductCode = productcode;
				}

				list[i] = list_;
				i++;
			}

		} catch (DocumentException e) {
			logger.error((new StringBuilder("CardList Parser(); Document Exception is raised. Reason :"))
					.append(e.getMessage()).toString());
			log.severe((new StringBuilder("CardList Parser(); Document Exception is raised. Reason :"))
					.append(e.getMessage()).toString());
		}
		return list;
	}

}

package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class CardActivationReturn 
{
	public String ErrorCode 			= emptyStr;
	public String ErrorDescription 		= emptyStr;
	public String Status 				= emptyStr;
	public boolean isNewCardRequest 	= false;
	
	public String toString()
	{
		String returnStr = newLine +
				resErrorCode 			+ ErrorCode        	+ newLine +
				resErrorDesc 			+ ErrorDescription 	+ newLine +
				resStatus 				+ Status        	+ newLine +
				resIsNewCardActivation + isNewCardRequest	+ newLine ;
		return returnStr;
	}
}
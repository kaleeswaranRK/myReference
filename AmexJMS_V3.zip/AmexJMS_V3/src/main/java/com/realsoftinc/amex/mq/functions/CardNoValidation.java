/*
* (C) Copyright 2013 Geomant Kft. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.CardNoValidationReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function CardNoValidation
 * 
 * @author Marijana Dujovic / Geomant Kft.
 */

public class CardNoValidation {

	Logger log = Utility.getLogger();
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(CardNoValidation.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public CardNoValidationReturn cardValidation(String CardNum) {
		logger.info("cardValidation(); Card No Validation function is called by IVR .. ");
		logger.info("cardValidation(); Enter");

		log.info("cardValidation(); Card No Validation function is called by IVR .. ");
		log.info("cardValidation(); Enter");

		MQCommon mqc = null;
		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser cardnoparser = null;
		CardNoValidationReturn cnvr = null;

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;

		String returnMsgIdActualStr = emptyStr;
		String errorCode = emptyStr;
		String errorDescription = emptyStr;
		String accountNum = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
//		@SuppressWarnings("unused")
		String dateTimeStampOutStr = emptyStr;
//		@SuppressWarnings("unused")
		String auditSeqOutStr = emptyStr;
		String status = emptyStr;

		String maskCardNum = emptyStr;
		logger.info("cardValidation(); Before try");

		log.info("cardValidation(); Before try");

		try {
			cnvr = new CardNoValidationReturn();
			mqc = new MQCommon();
			logger.info("cardValidation(); Before request creater");

			log.info("cardValidation(); Before request creater");
			rc = new RequestCreater();
			logger.info("cardValidation(); Before request response");

			log.info("cardValidation(); Before request response");
			rr = new RequestResponse();
			logger.info("cardValidation(); After request response");

			log.info("cardValidation(); After request response");

			cardnoparser = new ResponseParser();

			xmlMap = new HashMap<String, String>();

			/*
			 * sso = MQCommon.SSO; if(sso == null) {
			 * log.info("cardValidation(); sso is null");
			 * log.info("cardValidation(); Calling getSSO() function .. "); sso =
			 * mqc.getSSO(); } else { if(sso.equalsIgnoreCase(emptyStr)) {
			 * log.info("cardValidation(); sso is empty string");
			 * log.info("cardValidation(); Calling getSSO() function .. "); sso =
			 * mqc.getSSO(); } }
			 */
			if (CardNum.length() == 15) {

				maskCardNum = CardNum.substring(0, 4) + "******"
						+ CardNum.substring(CardNum.length() - 5, CardNum.length());
				logger.info("cardValidation(); Card Number is : " + maskCardNum);

				log.info("cardValidation(); Card Number is : " + maskCardNum);
			} else {
				log.info("cardValidation(); Card Number is less than 15 digits.");
			}
			logger.info("cardValidation(); Calling the getDateTime function ..");

			log.info("cardValidation(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("cardValidation(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("cardValidation(); DateTimeStamp is : " + dateTimeStampInStr);
			logger.info("cardValidation(); Calling the getAuditSequence function ..");

			log.info("cardValidation(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("cardValidation(); Audit Sequence is : " + auditSeqInStr);
			logger.info("cardValidation(); Created all the required parameters to prepare the xml ..");

			log.info("cardValidation(); Audit Sequence is : " + auditSeqInStr);
			log.info("cardValidation(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("CardNumber", CardNum);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			// xmlMap.put("SSO", sso);
			xmlMap.put("SysID", mqc.getproperties("CardNoValidation.SysID"));
			// xmlMap.put("MessageLength", mqc.getproperties("CardNoValidation.MsgLength"));
			xmlMap.put("MessageId", MsgId_CardNoVal);
			logger.info("cardValidation(); Sending values to form proper form of xml request .. ");

			log.info("cardValidation(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "CardNoValidation");
			logger.info("cardValidation(); Received xml in proper format ..");

			log.info("cardValidation(); Received xml in proper format ..");
			// log.info("cardValidation(); XML is : " + xmlReq);

			// Added to encrypt account number when display request in log file
			MQCommon.maskAccNumber("cardValidation(); XML is : ", xmlReq);
			logger.info("cardValidation(); Sending this xml as the request to MQ ..");

			log.info("cardValidation(); Sending this xml as the request to MQ ..");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("cardValidation(); Response received from MQ .. ");

			log.info("cardValidation(); Response received from MQ .. ");
			// log.info("cardValidation(); Received response from MQ is : " + replyMsg);

			// Added to encrypt account number when display response in log file
			MQCommon.maskAccNumber("cardValidation(); Received response from MQ is : ", replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("cardValidation(); Sending the received response from MQ to the parser ..");

				log.info("cardValidation(); Sending the received response from MQ to the parser ..");
				// log.info("cardValidation(); XML sent for parsing is :"+ replyMsg);
				map = cardnoparser.XmlParser(replyMsg);
				errorCode = (String) map.get("errCode");
				errorDescription = (String) map.get("errDesc");
				dateTimeStampOutStr = (String) map.get("dateTimeStampStr");
				auditSeqOutStr = (String) map.get("auditSeqStr");
				returnMsgIdActualStr = (String) map.get("msgIdActualStr");

				if (errorCode.equalsIgnoreCase("0") || errorCode.equalsIgnoreCase("00")
						|| errorCode.equalsIgnoreCase("000") || errorCode.equalsIgnoreCase("0000")) {

					if ((String) map.get("accountNum") != null)
						accountNum = (String) map.get("accountNum");
					logger.info("cardValidation(); Response from MQ is 'SUCCESS'.. ");

					log.info("cardValidation(); Response from MQ is 'SUCCESS'.. ");
					status = validStr;
				} else {
					logger.info("cardValidation(); Response from MQ is 'FAILURE'.. ");

					log.info("cardValidation(); Response from MQ is 'FAILURE'.. ");
					status = invalidStr;
				}

				if (MsgId_CardNoValResp.equalsIgnoreCase(returnMsgIdActualStr)) {
					logger.info("cardValidation(); MsgId from response is valid.");

					log.info("cardValidation(); MsgId from response is valid.");
				} else {
					logger.info("cardValidation(); Since the response from MQ is not proper .. ");
					logger.info("cardValidation(); Setting error values.");
					log.info("cardValidation(); Since the response from MQ is not proper .. ");
					log.info("cardValidation(); Setting error values.");
					errorCode = MQConstants.errorCode;
					logger.info("cardValidation(); Setting ErrorDescription as FAILURE ..");

					log.info("cardValidation(); Setting ErrorDescription as FAILURE ..");
					errorDescription = errorDesc;
				}
				// log.info("cardValidation(); Account Number before padding zero .."+accountNum
				// +"length of"+ accountNum.length());
				if (accountNum != emptyStr && accountNum.length() != 0) {
					if (accountNum.length() < 19) {
						int lengthOfAccountNumber = accountNum.length();
						for (int i = 0; i < 19 - lengthOfAccountNumber; i++) {
							accountNum = digitZero + accountNum;
						}
						logger.info("cardValidation(); Account Number after padding zero ..");

						log.info("cardValidation(); Account Number after padding zero ..");

					}
				}
				cnvr.errorCode = errorCode;
				cnvr.accountNum = accountNum;
				cnvr.status = status;
				cnvr.errorDesc = errorDescription;

				if ((String) map.get("branchCodeStr") != null)
					cnvr.branchCode = (String) map.get("branchCodeStr");
				if ((String) map.get("currencyName") != null)
					cnvr.currencyName = (String) map.get("currencyName");
				if ((String) map.get("prodCodeStr") != null)
					cnvr.productCode = (String) map.get("prodCodeStr");
				if ((String) map.get("primSuppFlag") != null)
					cnvr.primSupFlag = (String) map.get("primSuppFlag");
				if ((String) map.get("powcardID") != null)
					cnvr.powercardID = (String) map.get("powcardID");
			} else {
				logger.info("cardValidation(); Since the response from MQ is not proper .. ");
				logger.info("cardValidation(); Setting error values.");
				log.info("cardValidation(); Since the response from MQ is not proper .. ");
				log.info("cardValidation(); Setting error values.");
				cnvr.errorCode = MQConstants.errorCode;
				cnvr.status = invalidStr;
				cnvr.errorDesc = errorDesc;
			}
		} catch (Exception e) {
			logger.info("cardValidation(); Exception is raised." + e.getStackTrace());

			log.info("cardValidation(); Exception is raised." + e.getStackTrace());
			cnvr.errorCode = MQConstants.errorCode;
			cnvr.status = invalidStr;
			cnvr.errorDesc = errorDesc;
			logger.info("cardValidation(); Reason : " + e.getStackTrace());

			log.info("cardValidation(); Reason : " + e.getStackTrace());
		} finally {
			mqc = null;
			xmlMap = null;
			map = null;
			rc = null;
			rr = null;
			cardnoparser = null;

			xmlReq = emptyStr;
			replyMsg = emptyStr;
			returnMsgIdActualStr = emptyStr;
			errorCode = emptyStr;
			errorDescription = emptyStr;
			accountNum = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			dateTimeStampOutStr = emptyStr;
			auditSeqOutStr = emptyStr;
			status = emptyStr;

		}
		logger.info("cardValidation(); Response is returned to the IVR. Response : " + cnvr.toString());
		logger.info("cardValidation(); Exit");
		log.info("cardValidation(); Response is returned to the IVR. Response : " + cnvr.toString());
		log.info("cardValidation(); Exit");
		return cnvr;
	}
}

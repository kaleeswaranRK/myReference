/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;

import java.util.Map;

import javax.jms.TextMessage;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.PinSetupReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function PinSetUp
 * 
 * @author Purvi Lad / Real Soft (Intl) Pvt. Ltd.
 * @version $Revision: 1.7 $ $Date: 2010/07/12 10:40:55 $
 */

public class PinSetup {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(PinSetup.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public PinSetupReturn pinSetUp(String AccNum, String CardNum, String PinNum) {
		logger.info("pinSetUp(); Pin Set Up function is called by IVR .. ");
		logger.info("pinSetUp(); Enter ");
		log.info("pinSetUp(); Pin Set Up function is called by IVR .. ");
		log.info("pinSetUp(); Enter ");

		MQCommon mqc = null;
		PinSetupReturn pinRtn = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		// String sso = emptyStr;
		String xmlReq = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String replyMsg = emptyStr;
		String msgId = emptyStr;
		String errorDescription = emptyStr;
		String errCode = emptyStr;

		String maskAccNum = emptyStr;
		String maskCardNum = emptyStr;

		try {
			mqc = new MQCommon();
			rc = new RequestCreater();
			rr = new RequestResponse();
			respParser = new ResponseParser();
			pinRtn = new PinSetupReturn();
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();

			TextMessage mqReply = null;

			/*
			 * sso = MQCommon.SSO; if (sso == null) { log.info("pinSetUp(); sso is null");
			 * log.info("pinSetUp(); Calling getSSO() function .. "); sso = mqc.getSSO(); }
			 * else if (sso.equalsIgnoreCase(emptyStr)) {
			 * log.info("pinSetUp(); sso is empty string");
			 * log.info("pinSetUp(); Calling getSSO() function .. "); sso = mqc.getSSO(); }
			 */

			if (AccNum.length() == 12) {
				// maskAccNum = AccNum.replace(AccNum.subSequence(4,
				// AccNum.length()-5),maskString2);
				maskAccNum = AccNum.substring(0, 4) + "***" + AccNum.substring(AccNum.length() - 5, AccNum.length());
				logger.info("pinSetUp(); Account Number is : " + maskAccNum);

				log.info("pinSetUp(); Account Number is : " + maskAccNum);
			} else {
				logger.info("pinSetUp(); Account Number is less than 12 digits.");

				log.info("pinSetUp(); Account Number is less than 12 digits.");
			}

			if (CardNum.length() == 15) {
				// maskCardNum = CardNum.replace(CardNum.subSequence(4,
				// CardNum.length()-5),maskString1);
				maskCardNum = CardNum.substring(0, 4) + "******"
						+ CardNum.substring(CardNum.length() - 5, CardNum.length());
				logger.info("pinSetUp(); Card Number is : " + maskCardNum);

				log.info("pinSetUp(); Card Number is : " + maskCardNum);
			} else {
				logger.info("pinSetUp(); Card Number is less than 15 digits.");

				log.info("pinSetUp(); Card Number is less than 15 digits.");
			}
			logger.info("pinSetUp(); Calling the getDateTime function ..");

			log.info("pinSetUp(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("pinSetUp(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("pinSetUp(); Calling the getAuditSequence function ..");
			log.info("pinSetUp(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("pinSetUp(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("pinSetUp(); Audit Sequence is : " + auditSeqInStr);

			logger.info("pinSetUp(); Created all the required parameters to prepare the xml ..");
			log.info("pinSetUp(); Audit Sequence is : " + auditSeqInStr);

			log.info("pinSetUp(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("MessageLength", mqc.getproperties("PinSetup.MsgLength"));
			xmlMap.put("MessageId", MsgId_PinSetup);
			xmlMap.put("Description", PinSetup_Desc);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AccountNumber", AccNum);
			xmlMap.put("ActionCode", PinSetup_ActnCode);
			xmlMap.put("Action", PinSetup_Actn);
			xmlMap.put("ReviewDate", mqc.getDate());
			xmlMap.put("ReviewTime", mqc.getTime());
			xmlMap.put("cardSeqNo", PinSetup_CrdSeqNo);
			xmlMap.put("CardNumber", CardNum);
			xmlMap.put("PinNumber", PinNum);
			xmlMap.put("SSO", mqc.getproperties("PinSetup.SSO"));
			xmlMap.put("Note", PinSetup_Note);
			xmlMap.put("RepId", PinSetup_RepId);
			xmlMap.put("Hpr", PinSetup_Hpr);
			xmlMap.put("CaseNo", emptyStr);
			xmlMap.put("RackFlag", mqc.getproperties("PinSetup.RackFlag"));
			xmlMap.put("username", mqc.getproperties("PinSetup.UserName"));
			xmlMap.put("password", mqc.getproperties("PinSetup.Password"));
			logger.info("pinSetUp(); Sending values to form proper form of xml request .. ");

			log.info("pinSetUp(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "PinSetup");
			logger.info("pinSetUp(); Received xml in proper format ..");
			// printing xml request for debugging
			logger.info("pinSetUp(); XML is : " + xmlReq);
			logger.info("pinSetUp(); Sending the prepared xml to MQ .. ");
			log.info("pinSetUp(); Received xml in proper format ..");
			// printing xml request for debugging
			log.info("pinSetUp(); XML is : " + xmlReq);
			log.info("pinSetUp(); Sending the prepared xml to MQ .. ");
			mqReply = rr.MessageSenderAck(xmlReq);
			replyMsg = mqReply.getText();
			logger.info("pinSetUp(); Response received from MQ .. ");
			logger.info("pinSetUp(); Received response from MQ is : " + replyMsg);
			log.info("pinSetUp(); Response received from MQ .. ");
			log.info("pinSetUp(); Received response from MQ is : " + replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("pinSetUp(); Sending the received response from MQ to the parser ..");
				logger.info("pinSetUp(); XML sent for parsing is :" + replyMsg);
				log.info("pinSetUp(); Sending the received response from MQ to the parser ..");
				log.info("pinSetUp(); XML sent for parsing is :" + replyMsg);
				map = respParser.XmlParser(replyMsg);
				logger.info("pinSetUp(); Received Hash map after parsing of response.");

				log.info("pinSetUp(); Received Hash map after parsing of response.");

				errCode = (String) map.get("errCode");
				errorDescription = (String) map.get("errDes");
				pinRtn.errorCode = errCode;
				pinRtn.errorDesc = errorDescription;

				if (pinRtn.errorCode.equalsIgnoreCase("0") || pinRtn.errorCode.equalsIgnoreCase("00")
						|| pinRtn.errorCode.equalsIgnoreCase("000") || pinRtn.errorCode.equalsIgnoreCase("0000")) {
					logger.info("pinSetUp(); Response from MQ is 'SUCCESS'.. ");

					log.info("pinSetUp(); Response from MQ is 'SUCCESS'.. ");
					msgId = (String) map.get("msgId");
					pinRtn.status = validStr;
				} else {
					logger.info("pinSetUp(); Response from MQ is 'FAILURE'.. ");

					log.info("pinSetUp(); Response from MQ is 'FAILURE'.. ");
					pinRtn.status = invalidStr;
				}

				if (MsgId_PinSetupResp.equalsIgnoreCase(msgId)) {
					logger.info("pinSetUp(); Getting valid msg id from the response.");

					log.info("pinSetUp(); Getting valid msg id from the response.");
				} else {
					logger.info("accountBal(); Since the response from MQ is not proper .. ");
					logger.info("accountBal(); Setting error values.");
					log.info("accountBal(); Since the response from MQ is not proper .. ");
					log.info("accountBal(); Setting error values.");
					pinRtn.errorCode = errorCode;
					pinRtn.errorDesc = errorDesc;
				}
			}
			/*
			 * if(pinRtn.errorCode.equalsIgnoreCase("0") ||
			 * pinRtn.errorCode.equalsIgnoreCase("00") ||
			 * pinRtn.errorCode.equalsIgnoreCase("000") ||
			 * pinRtn.errorCode.equalsIgnoreCase("0000")){
			 * 
			 * log.info("pinSetUp(); Sending acknowledge string for xml formation.. :");
			 * respMap.put("MessageId", MsgId_PinSetupAck); respMap.put("Description",
			 * CardActv_DescAck); respMap.put("Description", PinSetup_DescAck);
			 * respMap.put("errorCode", pinRtn.errorCode); respMap.put("errorDescription",
			 * pinRtn.errorDesc);
			 * 
			 * xmlResp = rc.XmlRequest(respMap, "PinSetup_Ack");
			 * 
			 * Destination destQ = mqReply.getJMSReplyTo();
			 * log.info("pinSetUp(); Destination Queue is : " + destQ.toString());
			 * 
			 * log.info("pinSetUp(); Calling function for sending the acknowledgment .. ");
			 * rr.sendAck(xmlResp,destQ); log.info("pinSetUp(); Acknowledgment sent to MQ");
			 * } else{ log.
			 * info("pinSetUp(); Since it is a failure scenario , acknowledgment would not be send."
			 * ); } }
			 */
			else {
				logger.info("pinSetUp(); Since the response from MQ is not proper .. ");
				logger.info("pinSetUp(); Setting error values.");
				log.info("pinSetUp(); Since the response from MQ is not proper .. ");
				log.info("pinSetUp(); Setting error values.");
				pinRtn.errorCode = errorCode;
				pinRtn.errorDesc = errorDesc;
			}

		} catch (Exception e) {
			logger.info("pinSetUp(); Exception is raised." + e.toString());

			log.info("pinSetUp(); Exception is raised." + e.toString());
			pinRtn.errorCode = errorCode;
			pinRtn.errorDesc = errorDesc;
			logger.error("pinSetUp(); Reason : " + e.getStackTrace());

			log.severe("pinSetUp(); Reason : " + e.getStackTrace());
		} finally {
			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			xmlMap = null;
			map = null;

			// sso = emptyStr;
			xmlReq = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			replyMsg = emptyStr;
			msgId = emptyStr;
			errorDescription = emptyStr;
			errCode = emptyStr;

			maskAccNum = emptyStr;
			maskCardNum = emptyStr;

		}
		logger.info("pinSetUp();  Response is returned to the IVR. Response : " + pinRtn.toString());
		logger.info("pinSetUp(); Exit");
		log.info("pinSetUp();  Response is returned to the IVR. Response : " + pinRtn.toString());
		log.info("pinSetUp(); Exit");
		return pinRtn;

	}

}

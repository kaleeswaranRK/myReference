package com.realsoftinc.amex.mq.main;

import java.io.File;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.functions.AccountBalance;
import com.realsoftinc.amex.mq.functions.CardActivation;
import com.realsoftinc.amex.mq.functions.CardNoValidation;
import com.realsoftinc.amex.mq.functions.ChargeCardAccountBalance;
import com.realsoftinc.amex.mq.functions.ChargeCardDueDate;
import com.realsoftinc.amex.mq.functions.CheckCSIEnrolled;
import com.realsoftinc.amex.mq.functions.ConfirmCSIEnrollment;
import com.realsoftinc.amex.mq.functions.ContactDetails;
import com.realsoftinc.amex.mq.functions.CurrencyCode;
import com.realsoftinc.amex.mq.functions.DoBValidation;
import com.realsoftinc.amex.mq.functions.MRPointsReward;
import com.realsoftinc.amex.mq.functions.PaymentHistory;
import com.realsoftinc.amex.mq.functions.PinSetup;
import com.realsoftinc.amex.mq.functions.SendMREnrollment;
import com.realsoftinc.amex.mq.functions.SendMail;
import com.realsoftinc.amex.mq.functions.UnBlockPin;
import com.realsoftinc.amex.mq.functions.UniqueId;
import com.realsoftinc.amex.mq.functions.UpdateContDetails;
import com.realsoftinc.amex.mq.returnObjs.AccountBalanceReturn;
import com.realsoftinc.amex.mq.returnObjs.CardActivationReturn;
import com.realsoftinc.amex.mq.returnObjs.CardNoValidationReturn;
import com.realsoftinc.amex.mq.returnObjs.ChargeCardAccountBalanceReturn;
import com.realsoftinc.amex.mq.returnObjs.ChargeCardDueDateReturn;
import com.realsoftinc.amex.mq.returnObjs.CheckCSIEnrolledReturn;
import com.realsoftinc.amex.mq.returnObjs.ConfirmCSIEnrollmentReturn;
import com.realsoftinc.amex.mq.returnObjs.ContactDetailsReturn;
import com.realsoftinc.amex.mq.returnObjs.CurrencyReturn;
import com.realsoftinc.amex.mq.returnObjs.DoBValidationReturn;
import com.realsoftinc.amex.mq.returnObjs.MREnrollmentReturn;
import com.realsoftinc.amex.mq.returnObjs.MRPointsReturn;
import com.realsoftinc.amex.mq.returnObjs.PaymentHistoryReturn;
import com.realsoftinc.amex.mq.returnObjs.PinSetupReturn;
import com.realsoftinc.amex.mq.returnObjs.SendMailReturn;
import com.realsoftinc.amex.mq.returnObjs.UnBlockPinReturn;
import com.realsoftinc.amex.mq.returnObjs.UniqueIdReturn;
import com.realsoftinc.amex.mq.returnObjs.UpdateContDetailsReturn;

public class AmexIVRInput {
	final static Logger log = Logger.getLogger(AmexIVRInput.class.toString());
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(AmexIVRInput.class);

	static int n = 0;
	static boolean invalidInput = false;
	static Scanner reader = new Scanner(System.in);

//	public static void main (String args[]) {
//		AmexIVRInput amex = new AmexIVRInput();
//	}

	public AmexIVRInput() {

		System.out.println("*****Start***** ");
		log.info("*****Start***** ");
		logger.info("*****Start***** ");
		AmexIVRInput obj = new AmexIVRInput();
		String inputFilePath = "";
		String logg = "";
		inputFilePath = "D:/Projects/Amex_28.05.2019/AmexJMS/src/AmexJMSConfig.properties";
		logg = "D:/Projects/Amex_28.05.2019/AmexJMS/src/log4j.properties";
		/*
		 * Properties prop_ = new Properties(); try { prop_.load(new
		 * FileInputStream(logg)); } catch (IOException e1) { // TODO Auto-generated
		 * catch block e1.printStackTrace(); }
		 */

		// PropertyConfigurator.configure(logg);


		MQCommon.setConfigFilePath(inputFilePath);
		try {
			obj.getResponse();
			reader.close();

		} catch (InputMismatchException e) {
			System.out.println("InputMismatch Exception | Enter Only Numeric Value Between 1 and 2 ");
			logger.error("InputMismatch Exception | Enter Only Numeric Value Between 1 and 2 ");
			log.severe("InputMismatch Exception | Enter Only Numeric Value Between 1 and 2 ");

		} catch (Exception e) {
			logger.error("Exception: " + e.getMessage());

			log.severe("Exception: " + e.getMessage());
		}
		log.info("*****End***** ");
		logger.info("*****End***** ");

	}

	public void getResponse() {
		System.out.println("Enter 1 For AccountBalance");
		System.out.println("Enter 2 For CardNoValidation");
		System.out.println("Enter 3 For CardActivation");
		System.out.println("Enter 4 For ChargeCardAccountBalance");
		System.out.println("Enter 5 For ChargeCardDueDate");

		System.out.println("Enter 6 For CheckCSIEnrolled");
		System.out.println("Enter 7 For ConfirmeCSIEnrollment");
		System.out.println("Enter 8 For ContactDetails");
		System.out.println("Enter 9 For CurrencyCode");
		System.out.println("Enter 10 For DoBValidation");

		System.out.println("Enter 11 For PaymentHistory");
		System.out.println("Enter 12 For PinSetup");
		System.out.println("Enter 13 For SendMail");
		System.out.println("Enter 14 For MREnrollment");
		System.out.println("Enter 15 For PinUnblock");

		System.out.println("Enter 16 For UniqueId");
		System.out.println("Enter 17 For UpdateContDetails");
		System.out.println("Enter 18 For MRPointsReward");

		n = reader.nextInt();
		logger.info("Enter The Following: " + n);
		log.info("Enter The Following: " + n);

		if (n == 1) {
			AccountBalance ac = new AccountBalance();
			AccountBalanceReturn accBalRtn = new AccountBalanceReturn();
			String accNum = "";
			System.out.println("Enter Account Number:");
			accNum = reader.next();
			accBalRtn = ac.accountBal(accNum);
			System.out.println("***********Account Balance Response To IVR:***********" + accBalRtn);
			logger.info("Account Balance Response To IVR:" + accBalRtn);

			log.info("Account Balance Response To IVR:" + accBalRtn);

		} else if (n == 2) {
			CardNoValidation cnv = new CardNoValidation();
			CardNoValidationReturn cnvRtn = new CardNoValidationReturn();
			String CardNum = "";
			System.out.println("Enter Card Number:");
			CardNum = reader.next();
			cnvRtn = cnv.cardValidation(CardNum);
			System.out.println("Card Number Validation Response To IVR:" + cnvRtn);
			logger.info("**********Card Number Validation Response To IVR***********:" + cnvRtn);

			log.info("**********Card Number Validation Response To IVR***********:" + cnvRtn);

		} else if (n == 3) {
			CardActivation ca = new CardActivation();
			CardActivationReturn cardActivation = new CardActivationReturn();
			String cardNum = "";
			String accNum = "";
			System.out.println("Enter Card Number:");
			cardNum = reader.next();
			System.out.println("Enter Account Number:");
			accNum = reader.next();
			cardActivation = ca.cardActivate(cardNum, accNum);
			System.out.println("Card Activation Response To IVR:" + cardActivation);
			logger.info("**********Card Activation Response To IVR***********:" + cardActivation);

			log.info("**********Card Activation Response To IVR***********:" + cardActivation);

		} else if (n == 4) {
			ChargeCardAccountBalance ccab = new ChargeCardAccountBalance();
			ChargeCardAccountBalanceReturn ccAccBalRtn = new ChargeCardAccountBalanceReturn();
			String cardNum = "";
			System.out.println("Enter Card Number:");
			cardNum = reader.next();
			ccAccBalRtn = ccab.chargeCardAccountBal(cardNum);
			System.out.println("Charge Card Account Balance Response To IVR:" + ccAccBalRtn);
			logger.info("**********Charge Card Account Balance Response To IVR***********:" + ccAccBalRtn);

			log.info("**********Charge Card Account Balance Response To IVR***********:" + ccAccBalRtn);

		} else if (n == 5) {
			ChargeCardDueDate ccdd = new ChargeCardDueDate();
			ChargeCardDueDateReturn chrgCardDueRtn = new ChargeCardDueDateReturn();
			String cardNum = "";
			System.out.println("Enter Card Number:");
			cardNum = reader.next();
			chrgCardDueRtn = ccdd.chargeCardDueDate(cardNum);
			System.out.println("Charge Card Due Date Response To IVR:" + chrgCardDueRtn);
			logger.info("**********Charge Card Due Date Response To IVR***********:" + chrgCardDueRtn);

			log.info("**********Charge Card Due Date Response To IVR***********:" + chrgCardDueRtn);

		} else if (n == 6) {
			CheckCSIEnrolled cce = new CheckCSIEnrolled();
			CheckCSIEnrolledReturn checkEnrolledReturn = new CheckCSIEnrolledReturn();
			String accNum = "";
			System.out.println("Enter Account Number:");
			accNum = reader.next();
			checkEnrolledReturn = cce.CheckEnrolledStatus(accNum);
			System.out.println("Check CSI Enrolled Response To IVR:" + checkEnrolledReturn);
			logger.info("**********Check CSI Enrolled Response To IVR***********:" + checkEnrolledReturn);

			log.info("**********Check CSI Enrolled Response To IVR***********:" + checkEnrolledReturn);

		} else if (n == 7) {
			ConfirmCSIEnrollment ccem = new ConfirmCSIEnrollment();
			ConfirmCSIEnrollmentReturn confirmEnrollementReturn = new ConfirmCSIEnrollmentReturn();
			String accNum = "";
			System.out.println("Enter Account Number:");
			accNum = reader.next();
			confirmEnrollementReturn = ccem.ConfirmEnrollement(accNum);
			System.out.println("Confirm CSI Enrollment Response To IVR:" + confirmEnrollementReturn);
			logger.info("**********Confirm CSI Enrollment Response To IVR***********:" + confirmEnrollementReturn);

			log.info("**********Confirm CSI Enrollment Response To IVR***********:" + confirmEnrollementReturn);

		} else if (n == 8) {
			ContactDetails condls = new ContactDetails();
			ContactDetailsReturn contDtlRtn = new ContactDetailsReturn();
			String AccNum = "";
			System.out.println("Enter Account Number:");
			AccNum = reader.next();
			contDtlRtn = condls.getContactDetails(AccNum);
			System.out.println("Contact Details Response To IVR:" + contDtlRtn);
			logger.info("**********Contact Details Response To IVR***********:" + contDtlRtn);

			log.info("**********Contact Details Response To IVR***********:" + contDtlRtn);

		} else if (n == 9) {
			CurrencyCode curcode = new CurrencyCode();
			CurrencyReturn currRtn = new CurrencyReturn();
			String CardNum = "";
			System.out.println("Enter Card Number:");
			CardNum = reader.next();
			currRtn = curcode.getCurrenyCode(CardNum);
			System.out.println("Currency Code Response To IVR:" + currRtn);
			logger.info("**********Currency Code Response To IVR***********:" + currRtn);

			log.info("**********Currency Code Response To IVR***********:" + currRtn);

		} else if (n == 10) {
			DoBValidation dobv = new DoBValidation();
			DoBValidationReturn dobvalidate = new DoBValidationReturn();
			String AccNum = "";
			String dob = "";
			System.out.println("Enter Account Number:");
			AccNum = reader.next();
			System.out.println("Enter Date of Birth:");
			dob = reader.next();
			dobvalidate = dobv.dateOfBirthValidation(AccNum, dob);
			System.out.println("DoB Validation Response To IVR:" + dobvalidate);
			logger.info("**********DoB Validation Response To IVR***********:" + dobvalidate);

			log.info("**********DoB Validation Response To IVR***********:" + dobvalidate);

		} else if (n == 11) {
			PaymentHistory ph = new PaymentHistory();
			PaymentHistoryReturn payHistRtn = new PaymentHistoryReturn();
			String AccNum = "";
			System.out.println("Enter Account Number:");
			AccNum = reader.next();
			payHistRtn = ph.getPaymentHistory(AccNum);
			System.out.println("Payment History Response To IVR:" + payHistRtn);
			logger.info("**********Payment History Response To IVR***********:" + payHistRtn);

			log.info("**********Payment History Response To IVR***********:" + payHistRtn);

		} else if (n == 12) {
			PinSetup ps = new PinSetup();
			PinSetupReturn pinRtn = new PinSetupReturn();
			String AccNum = "";
			String CardNum = "";
			String PinNum = "";
			System.out.println("Enter Account Number:");
			AccNum = reader.next();
			System.out.println("Enter Card Number:");
			CardNum = reader.next();
			System.out.println("Enter Pin Number:");
			PinNum = reader.next();
			pinRtn = ps.pinSetUp(AccNum, CardNum, PinNum);
			System.out.println("Pin Setup Response To IVR:" + pinRtn);
			logger.info("**********Pin Setup Response To IVR***********:" + pinRtn);

			log.info("**********Pin Setup Response To IVR***********:" + pinRtn);

		} else if (n == 13) {
			SendMail sm = new SendMail();
			SendMailReturn sendMailRtn = new SendMailReturn();
			String language = "";
			String emailAddress = "";
			System.out.println("Enter Language:");
			language = reader.next();
			System.out.println("Enter Email Address:");
			emailAddress = reader.next();
			sendMailRtn = sm.sendMailAttachment(language, emailAddress);
			System.out.println("Send Mail Response To IVR:" + sendMailRtn);
			logger.info("**********Send Mail Response To IVR***********:" + sendMailRtn);

			log.info("**********Send Mail Response To IVR***********:" + sendMailRtn);

		} else if (n == 14) {
			SendMREnrollment smre = new SendMREnrollment();
			MREnrollmentReturn mrEnrolRtn = new MREnrollmentReturn();
			String CardNum = "";
			System.out.println("Enter Card Number:");
			CardNum = reader.next();
			mrEnrolRtn = smre.sendMREnrollment(CardNum);
			System.out.println("MREnrollment Response To IVR:" + mrEnrolRtn);
			logger.info("**********MREnrollment Response To IVR***********:" + mrEnrolRtn);

			log.info("**********MREnrollment Response To IVR***********:" + mrEnrolRtn);

		} else if (n == 15) {
			UnBlockPin ubp = new UnBlockPin();
			UnBlockPinReturn unblckPinRtn = new UnBlockPinReturn();
			String cardNum = "";
			System.out.println("Enter Card Number:");
			cardNum = reader.next();
			unblckPinRtn = ubp.unBlockPin(cardNum);
			System.out.println("Pin Unblock Response To IVR:" + unblckPinRtn);
			logger.info("**********Pin Unblock Response To IVR***********:" + unblckPinRtn);

			log.info("**********Pin Unblock Response To IVR***********:" + unblckPinRtn);

		} else if (n == 16) {
			UniqueId uid = new UniqueId();
			UniqueIdReturn valUniqueIdRet = new UniqueIdReturn();
			String uniqueId = "";
			System.out.println("Enter Unique Id:");
			uniqueId = reader.next();
			valUniqueIdRet = uid.validateUniqueId(uniqueId);
			System.out.println("Unique Id Response To IVR:" + valUniqueIdRet);
			logger.info("**********Unique Id Response To IVR***********:" + valUniqueIdRet);

			log.info("**********Unique Id Response To IVR***********:" + valUniqueIdRet);

		} else if (n == 17) {
			UpdateContDetails ucd = new UpdateContDetails();
			UpdateContDetailsReturn ucdRtn = new UpdateContDetailsReturn();
			String CardNum = "";
			String WorkNoCC = "";
			String WorkNo = "";
			String HomeNoCC = "";
			String HomeNo = "";
			String MobNoCC = "";
			String MobNo = "";

			System.out.println("Enter Card Number:");
			CardNum = reader.next();
			System.out.println("Enter Work Number CC:");
			WorkNoCC = reader.next();
			System.out.println("Enter Work No:");
			WorkNo = reader.next();
			System.out.println("Enter Home No CC:");
			HomeNoCC = reader.next();
			System.out.println("Enter Home No:");
			HomeNo = reader.next();
			System.out.println("Enter MobNo CC:");
			MobNoCC = reader.next();
			System.out.println("Enter MobNo:");
			MobNo = reader.next();
			ucdRtn = ucd.updateDetails(CardNum, WorkNoCC, WorkNo, HomeNoCC, HomeNo, MobNoCC, MobNo);
			System.out.println("Update Contact Details Response To IVR:" + ucdRtn);
			logger.info("**********Update Contact Details Response To IVR***********:" + ucdRtn);

			log.info("**********Update Contact Details Response To IVR***********:" + ucdRtn);

		} else if (n == 18) {
			MRPointsReward mrp = new MRPointsReward();
			MRPointsReturn mrpr = new MRPointsReturn();
			String accNum = "";
			System.out.println("Enter Account Number:");
			accNum = reader.next();
			mrpr = mrp.getMRPoints(accNum);
			System.out.println("MR Points Reward Response To IVR:" + mrpr);
			logger.info("**********MR Points Reward Response To IVR***********:" + mrpr);

			log.info("**********MR Points Reward Response To IVR***********:" + mrpr);

		} else {
			System.out.println("You Have Entered An Invalid Input | Please Enter Input Between 1 and 2 ");
			logger.info("You Have Entered An Invalid Input | Please Enter Input Between 1 and 2 ");

			log.info("You Have Entered An Invalid Input | Please Enter Input Between 1 and 2 ");
			invalidInput = true;
		}
	}
}
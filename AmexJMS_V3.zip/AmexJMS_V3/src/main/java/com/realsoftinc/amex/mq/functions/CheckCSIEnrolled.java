/*
 * (C) Copyright 2011 Geomant Kft. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;

import java.util.Map;

//import javax.jms.Destination;
import javax.jms.TextMessage;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
//import com.realsoftinc.amex.mq.returnObjs.EmbosserDetailReturn;
import com.realsoftinc.amex.mq.returnObjs.CheckCSIEnrolledReturn;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the main business logic of the function
 * CardActivation
 * 
 * @author Norbert Toth / Geomant Kft.
 * @version $Revision: 1.0 $ $Date: 2011/06/21 11:48:55 $
 */
public class CheckCSIEnrolled {

	Logger log = Utility.getLogger();
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(CheckCSIEnrolled.class);

	@SuppressWarnings({ "unchecked", "static-access" })
	public CheckCSIEnrolledReturn CheckEnrolledStatus(String accNum) {
		logger.info("CheckCSIEnrolled(); Check CSI Enrolled function is called by IVR .. ");
		logger.info("CheckCSIEnrolled(); Enter");
		log.info("CheckCSIEnrolled(); Check CSI Enrolled function is called by IVR .. ");
		log.info("CheckCSIEnrolled(); Enter");

		MQCommon mqc = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser CSIEnrolledParser = null;
		CheckCSIEnrolledReturn checkEnrolledReturn = null;
		TextMessage mqReply = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;
		// Map<String, String> respMap = null;

		String dateTimeStampInStr = emptyStr;
		String date = emptyStr;
		String time = emptyStr;
		String auditSeqInStr = emptyStr;
		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		String status = emptyStr;
		// String xmlResp = emptyStr;
		// String sso = emptyStr;
		String maskAccNum = emptyStr;
		// String MsgId_ChkEnrl = "6017";
		// String ProdID = "CSI000";
		// String MsgLength = "75";
		// String UserName = "FMULLA";

		checkEnrolledReturn = new CheckCSIEnrolledReturn();
//		EmbosserDetail embosserDtl = null;
//		EmbosserDetailReturn embosserDetailRtObj = null;
//		try{
//			log.info("CheckCSIEnrolled(); Calling Embosser Detail function .."); 
//			embosserDtl = new EmbosserDetail();
//			embosserDetailRtObj = embosserDtl.getEmbosserDetail(cardNum);
//			checkEnrolledReturn = new CheckCSIEnrolledReturn();
//		}
//		
//		catch (Exception e) {
//			log.severe("CheckCSIEnrolled(); Exception is raised. Reason : " + e.getStackTrace());
//		}

//		log.info("CheckCSIEnrolled(); " + resCurrentUsageFlag + embosserDetailRtObj.firstUsageFlag);
//		log.info("CheckCSIEnrolled(); " + resLastUsageFlag	+ embosserDetailRtObj.priorUsageFlag);
//		log.info("CheckCSIEnrolled(); " + resErrorCode	+ embosserDetailRtObj.ErrorCode);

//		if ((embosserDetailRtObj.ErrorCode.equalsIgnoreCase("0")
//				|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("00")
//				|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("000") || embosserDetailRtObj.ErrorCode
//				.equalsIgnoreCase("0000"))
//				&& (embosserDetailRtObj.firstUsageFlag.equalsIgnoreCase("Y"))
//				&& (embosserDetailRtObj.priorUsageFlag.equalsIgnoreCase("N"))) {

		try {
			/*
			 * sso = MQCommon.SSO; if(sso == null) { log.info("accountBal(); sso is null");
			 * log.info("CheckCSIEnrolled(); Calling getSSO() function ..."); sso =
			 * mqc.getSSO(); } else if(sso.equalsIgnoreCase(emptyStr)) {
			 * log.info("CheckCSIEnrolled(); sso is an empty string");
			 * log.info("CheckCSIEnrolled(); Calling getSSO() function ..."); sso =
			 * mqc.getSSO(); }
			 */

			xmlMap = new HashMap<String, String>();
			// respMap = new HashMap<String, String>();
			map = new HashMap<String, String>();

			mqc = new MQCommon();
			rc = new RequestCreater();
			rr = new RequestResponse();
			CSIEnrolledParser = new ResponseParser();

//				currentFlag = currentFlagN;
//				lastFlag = CardActv_Hpr;

			if (accNum.length() == 12) {
				// maskAccNum = accNum.replace(accNum.subSequence(4,
				// accNum.length()-5),maskString2);
				maskAccNum = accNum.substring(0, 4) + "***" + accNum.substring(accNum.length() - 5, accNum.length());
				logger.info("CheckCSIEnrolled(); Account Number is : " + maskAccNum);

				log.info("CheckCSIEnrolled(); Account Number is : " + maskAccNum);
			} else {
				logger.info("CheckCSIEnrolled(); Account Number is less than 12 digits.");

				log.info("CheckCSIEnrolled(); Account Number is less than 12 digits.");
			}

			/*
			 * if(cardNum.length() == 15){ maskCardNum =
			 * cardNum.replace(cardNum.subSequence(4, cardNum.length()-5),maskString1);
			 * log.info("CheckCSIEnrolled(); Card Number is : " + maskCardNum); } else{
			 * log.info("CheckCSIEnrolled(); Card Number is less than 15 digits."); }
			 */
			logger.info("CheckCSIEnrolled(); Calling the getDateTime function ..");

			log.info("CheckCSIEnrolled(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("CheckCSIEnrolled(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("CheckCSIEnrolled(); Calling the getAuditSequence function ..");
			log.info("CheckCSIEnrolled(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("CheckCSIEnrolled(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("CheckCSIEnrolled(); Audit Sequence is : " + auditSeqInStr);

			logger.info("CheckCSIEnrolled(); Calling the getDate function ..");
			log.info("CheckCSIEnrolled(); Audit Sequence is : " + auditSeqInStr);

			log.info("CheckCSIEnrolled(); Calling the getDate function ..");
			date = mqc.getDate();
			logger.info("CheckCSIEnrolled(); Date is : " + date);

			logger.info("CheckCSIEnrolled(); Calling the getTime function ..");
			log.info("CheckCSIEnrolled(); Date is : " + date);

			log.info("CheckCSIEnrolled(); Calling the getTime function ..");
			time = mqc.getTime();
			logger.info("CheckCSIEnrolled(); Time is : " + time);

			logger.info("CheckCSIEnrolled(); Created all the required parameters to prepare the xml ..");
			log.info("CheckCSIEnrolled(); Time is : " + time);

			log.info("CheckCSIEnrolled(); Created all the required parameters to prepare the xml ..");
			// xmlMap.put("MessageLength", MsgLength);
			xmlMap.put("MessageLength", mqc.getproperties("CheckCSIEnrolled.MsgLength"));
			xmlMap.put("MessageId", MsgId_ChkEnrl);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("SSO", mqc.getproperties("CheckCSIEnrolled.SSO"));
			xmlMap.put("AccountNumber", accNum);
			// xmlMap.put("ProductId", ProdID);
			// xmlMap.put("username",UserName);
			xmlMap.put("ProductId", mqc.getproperties("CheckCSIEnrolled.ProdID"));
			xmlMap.put("username", mqc.getproperties("CheckCSIEnrolled.UserName"));
			logger.info("CheckCSIEnrolled(); Sending values to form proper format of xml request .. ");

			log.info("CheckCSIEnrolled(); Sending values to form proper format of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "CheckCSIEnrolled");
			logger.info("CheckCSIEnrolled(); Received xml in proper format ..");
			logger.info("CheckCSIEnrolled(); XML is : " + xmlReq);

			logger.info("CheckCSIEnrolled(); Sending the prepared xml to MQ .. ");
			log.info("CheckCSIEnrolled(); Received xml in proper format ..");
			log.info("CheckCSIEnrolled(); XML is : " + xmlReq);

			log.info("CheckCSIEnrolled(); Sending the prepared xml to MQ .. ");
			mqReply = rr.MessageSenderAck(xmlReq);
			replyMsg = mqReply.getText();
			logger.info("CheckCSIEnrolled(); Response received from MQ .. ");
			logger.info("CheckCSIEnrolled(); Received response from MQ is : " + replyMsg);

			logger.info("CheckCSIEnrolled(); Received response from MQ : " + replyMsg);
			log.info("CheckCSIEnrolled(); Response received from MQ .. ");
			log.info("CheckCSIEnrolled(); Received response from MQ is : " + replyMsg);

			log.info("CheckCSIEnrolled(); Received response from MQ : " + replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("CheckCSIEnrolled(); Sending the received response from MQ to the parser ..");
				logger.info("CheckCSIEnrolled(); XML sent for parsing is :" + replyMsg);
				log.info("CheckCSIEnrolled(); Sending the received response from MQ to the parser ..");
				log.info("CheckCSIEnrolled(); XML sent for parsing is :" + replyMsg);
				map = CSIEnrolledParser.XmlParser(replyMsg);
				checkEnrolledReturn.Length = (String) map.get("Length");
				checkEnrolledReturn.ErrorCode = (String) map.get("errCode");
				checkEnrolledReturn.ErrorDescription = (String) map.get("errDesc");
				checkEnrolledReturn.EnrolledStatus = (String) map.get("EnrolledStatus");

				checkEnrolledReturn.MessageID = (String) map.get("msgIdActualStr");
				checkEnrolledReturn.AuditSeq = (String) map.get("auditSeqStr");
				checkEnrolledReturn.DateTimeStamp = (String) map.get("dateTimeStampStr");

				if (checkEnrolledReturn.ErrorCode.equalsIgnoreCase("0")
						|| checkEnrolledReturn.ErrorCode.equalsIgnoreCase("00")
						|| checkEnrolledReturn.ErrorCode.equalsIgnoreCase("000")
						|| checkEnrolledReturn.ErrorCode.equalsIgnoreCase("0000")) {
					logger.info("CheckCSIEnrolled(); Response from MQ is 'SUCCESS'.. ");

					log.info("CheckCSIEnrolled(); Response from MQ is 'SUCCESS'.. ");
					status = validStr;
				} else {
					logger.info("CheckCSIEnrolled(); Response from MQ is 'FAILURE'.. ");

					log.info("CheckCSIEnrolled(); Response from MQ is 'FAILURE'.. ");
					status = invalidStr;
				}

//				log.info("CheckCSIEnrolled(); Sending acknowledge string for xml formation.. :");
//				respMap.put("MessageId", MsgId_ChckCSIEnrolled);
//				respMap.put("Description", CardActv_DescAck);
//				respMap.put("errorCode", checkEnrolledReturn.ErrorCode);
//				respMap.put("errorDescription", checkEnrolledReturn.ErrorDescription);

				checkEnrolledReturn.Status = status;
				/* cardActivation.isNewCardRequest = errorCode; */

//				xmlResp = rc.XmlRequest(respMap, "CheckCSIEnrolled");
//				
//				Destination destQ = mqReply.getJMSReplyTo();
//				if(destQ == null){
//					log.info("destQ is null");
//				}
//				else{
//					log.info("CheckCSIEnrolled(); Destination Q is : " + destQ.toString());
//				}
////				log.info("CheckCSIEnrolled(); Destination Q is : " + destQ.toString());
//				
//				log.info("CheckCSIEnrolled(); Sending acknowledgment .. ");
//				rr.sendAck(xmlResp,destQ);
//				log.info("CheckCSIEnrolled(); Acknowledgment sent to MQ .");
			} else {
				logger.info("CheckCSIEnrolled(); Since the response from MQ is not proper .. ");
				logger.info("CheckCSIEnrolled(); Setting error values.");
				log.info("CheckCSIEnrolled(); Since the response from MQ is not proper .. ");
				log.info("CheckCSIEnrolled(); Setting error values.");
				checkEnrolledReturn.ErrorCode = errorCode;
				checkEnrolledReturn.ErrorDescription = errorDesc;
				checkEnrolledReturn.Status = invalidStr;
			}

		} catch (Exception e) {
			logger.error("CheckCSIEnrolled(); Exception is raised. Reason : " + e.getStackTrace());

			log.severe("CheckCSIEnrolled(); Exception is raised. Reason : " + e.getStackTrace());
		} finally {
			mqc = null;
			rc = null;
			rr = null;
			CSIEnrolledParser = null;
			mqReply = null;
			xmlMap = null;
			map = null;
			// respMap = null;

			dateTimeStampInStr = emptyStr;
			date = emptyStr;
			time = emptyStr;
			auditSeqInStr = emptyStr;
//				currentFlag = emptyStr;
//				lastFlag = emptyStr;
			xmlReq = emptyStr;
			replyMsg = emptyStr;
			status = emptyStr;
			// xmlResp = emptyStr;
			// sso = emptyStr;
			maskAccNum = emptyStr;
		}
//		} else {
//			if ((embosserDetailRtObj.ErrorCode.equalsIgnoreCase("0")
//					|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("00")
//					|| embosserDetailRtObj.ErrorCode.equalsIgnoreCase("000") || embosserDetailRtObj.ErrorCode
//					.equalsIgnoreCase("0000"))
//					&& (embosserDetailRtObj.firstUsageFlag
//							.equalsIgnoreCase("Y") && embosserDetailRtObj.priorUsageFlag
//							.equalsIgnoreCase("Y"))) {
//				checkEnrolledReturn.isNewCardRequest = true;
//			} else {
//				checkEnrolledReturn.isNewCardRequest = false;
//			}
//			log.info("CheckCSIEnrolled(); The Embosser Detail Message Failed.");
//			log.info("CheckCSIEnrolled(); Setting the ErrorCode and ErrorDescription inside checkEnrolledReturn Return Object.");
//			checkEnrolledReturn.ErrorCode = errorCode;
//			checkEnrolledReturn.ErrorDescription = errorDesc;
//			checkEnrolledReturn.Status = invalidStr;
//		}
		logger.info(
				"CheckCSIEnrolled(); Response is returned to the IVR. Response : " + checkEnrolledReturn.toString());
		logger.info("CheckCSIEnrolled(); Exit");
		log.info("CheckCSIEnrolled(); Response is returned to the IVR. Response : " + checkEnrolledReturn.toString());
		log.info("CheckCSIEnrolled(); Exit");
		return checkEnrolledReturn;
	}
}

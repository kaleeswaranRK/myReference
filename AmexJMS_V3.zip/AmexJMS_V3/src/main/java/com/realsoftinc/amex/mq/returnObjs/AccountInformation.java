package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class AccountInformation 
{
	
	//public String AccountNumber = emptyStr;	
	public String CurrentBalance = emptyStr;
	public String AmountDue = emptyStr;
	public String TotalCreditLimit = emptyStr;
	public String CashCreditLimit = emptyStr;
	public String CashBalance = emptyStr;
	public String CashAvailable = emptyStr;
	public String OTB = emptyStr;
	public String BeginBalance = emptyStr;	
	public String Status = emptyStr;
	public String PastDue = emptyStr;
	public String LastPurchase = emptyStr;
	public String BillingCycle = emptyStr;
	public String DateOpened = emptyStr;
	public String DueDate = emptyStr;
	public String DateLastPayment = emptyStr;
	public String DateLastStatement = emptyStr;
	public String LastStatBalance = emptyStr; 
	public String AmountPurchCTD = emptyStr;
	public String AmountPurchYTD = emptyStr;
	public String AmountPurchLTD = emptyStr;
	public String AmountCashCTD = emptyStr;
	public String AmountCashYTD = emptyStr;
	public String AmountCashLTD = emptyStr;
	public String MemberSince = emptyStr;
	public String BlockCode = emptyStr;
	public String BlockCode2 = emptyStr;
	public String OverdueFlag = emptyStr;
	public String MemoBalance = emptyStr;
	public String DateCardFee = emptyStr;
	public String CTAReason = emptyStr;
	//public String maskAccNum = emptyStr;
	
	
	public String toString()
	{
	    //maskAccNum = AccountNumber.replace(AccountNumber.subSequence(4, AccountNumber.length()-5),maskString1);
		String returnStr = emptyStr;		
			returnStr = newLine +
			//resAccNum + maskAccNum + newLine +			
			resCurrentBalance + CurrentBalance    + newLine +
			resAmountDue + AmountDue         + newLine +
			resTotalCreditLimit + TotalCreditLimit  + newLine +
			resCashCreditLimit + CashCreditLimit   + newLine +
			resCashBalance + CashBalance       + newLine +
			resCashAvailable + CashAvailable     + newLine +
			resOTB + OTB               + newLine +
			resBeginBalance + BeginBalance      + newLine +			
			resStatus + Status            + newLine +
			resPastDue + PastDue           + newLine +
			resLastPurchase + LastPurchase      + newLine +
			resBillingCycle + BillingCycle      + newLine +
			resDateOpened + DateOpened        + newLine +
			resDueDate + DueDate           + newLine +
			resDateLastPayment + DateLastPayment + newLine +
			resDateLastStatement + DateLastStatement + newLine +
			resLastStatBal + LastStatBalance + newLine +
			resAmountPurchCTD + AmountPurchCTD + newLine +
			resAmountPurchYTD + AmountPurchYTD + newLine +
			resAmountPurchLTD + AmountPurchLTD + newLine +
			resAmountCashCTD + AmountCashCTD + newLine +
			resAmountCashYTD + AmountCashYTD + newLine +
			resAmountCashLTD + AmountCashLTD + newLine +
			resBlockCode + BlockCode + newLine +
			resBlockCode2+ BlockCode2 + newLine +
			resOverdueFlag + OverdueFlag + newLine +
			resMemoBalance + MemoBalance + newLine +
			resDateCardFee + DateCardFee + newLine +
			resCTAReason + CTAReason + newLine +
			resMemberSince + MemberSince + newLine ;
		return returnStr;
	}
}

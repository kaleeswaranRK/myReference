package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class SendMailReturn 
{
	public String errorCode = emptyStr;
	public String errorDesc = emptyStr;
	
	
	public String toString()
	{
		
		String returnStr = newLine +
				resErrorCode + errorCode  + newLine +
				resErrorDesc + errorDesc  + newLine;
				
		return returnStr;
	}
}

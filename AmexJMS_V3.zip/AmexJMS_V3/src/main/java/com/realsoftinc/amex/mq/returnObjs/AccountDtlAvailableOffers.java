package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class AccountDtlAvailableOffers {
	
	public String CampaignName = emptyStr;
	public String StartDate = emptyStr;
	public String EndDate = emptyStr;
	public String CampaignDetail = emptyStr;
	public String OrigineFlag = emptyStr;
	
}
/*
* (C) Copyright 2019 Tele Apps India Pvt Ltd.. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.CardLst;
import com.realsoftinc.amex.mq.returnObjs.CardListReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
import com.realsoftinc.amex.mq.util.ResponseParserCardList;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function Card List
 * 
 * @author Prasanth.
 */

public class CardList {
	Logger log = Utility.getLogger();
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(CardList.class);


	@SuppressWarnings({ "static-access", "unchecked" })
	public CardListReturn cardList(String MobNo, String CardNum, String FirstName, String FamilyName, String ClientCode, String LegalId) {
		log.info("cardList(); Card List function is called by IVR .. ");
		log.info("cardList(); Enter ");
		log.info("cardList(); Input From IVR | MOBILENUMBER: "+MobNo);
		log.info("cardList(); Input From IVR | FIRSTNAME: "+FirstName);
		log.info("cardList(); Input From IVR | FAMILYNAME: "+FamilyName);
		log.info("cardList(); Input From IVR | CLIENTCODE: "+ClientCode);
		log.info("cardList(); Input From IVR | LEGALID: "+LegalId);
		logger.info("cardList(); Card List function is called by IVR .. ");
		logger.info("cardList(); Enter ");
		logger.info("cardList(); Input From IVR | MOBILENUMBER: "+MobNo);
		logger.info("cardList(); Input From IVR | FIRSTNAME: "+FirstName);
		logger.info("cardList(); Input From IVR | FAMILYNAME: "+FamilyName);
		logger.info("cardList(); Input From IVR | CLIENTCODE: "+ClientCode);
		logger.info("cardList(); Input From IVR | LEGALID: "+LegalId);

		MQCommon mqc = new MQCommon();

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
	//	String dateTimeStampOutStr = emptyStr;
	//	String auditSeqOutStr = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String maskCardNum = emptyStr;

		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;
		ResponseParserCardList resParseCardList = null;
		//CardLst cardList = null;
		CardLst[] cardDetailList = null;
		CardListReturn cardListRtn = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		try {
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			//cardList = new CardLst();
			cardListRtn = new CardListReturn();
			respParser = new ResponseParser();
			resParseCardList = new ResponseParserCardList();

			log.info("cardList(); Calling the getDateTime function ..");
			logger.info("cardList(); Calling the getDateTime function ..");

			dateTimeStampInStr = mqc.getDateTime();
			logger.info("cardList(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("cardList(); Calling the getAuditSequence function ..");
			log.info("cardList(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("cardList(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("cardList(); Audit Sequence is : " + auditSeqInStr);

			log.info("cardList(); Audit Sequence is : " + auditSeqInStr);

			if (CardNum.length() == 15) {
				maskCardNum = CardNum.substring(0,4)+"******"+CardNum.substring(CardNum.length()-5,CardNum.length());
				logger.info("cardList(); Card Number is : " + maskCardNum);

				log.info("cardList(); Card Number is : " + maskCardNum);
			
			} else {
				logger.info("cardList(); Card Number is less than 15 digits.");

				log.info("cardList(); Card Number is less than 15 digits.");
			}
			logger.info("cardList(); Created all the required parameters to prepare the xml ..");

			log.info("cardList(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("MessageId", MsgId_CardList);
			xmlMap.put("SysID", mqc.getproperties("CardList.SysID"));
			xmlMap.put("MobileNO", MobNo);
			xmlMap.put("CardNumber", CardNum);
			xmlMap.put("FirstName", FirstName);
			xmlMap.put("FamilyName", FamilyName);
			xmlMap.put("ClientCode", ClientCode);
			xmlMap.put("LegalId", LegalId);			
			logger.info("cardList(); Sending values to form proper format of xml request .. ");

			log.info("cardList(); Sending values to form proper format of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "CardList");
			logger.info("cardList(); Received xml in proper format ..");

			log.info("cardList(); Received xml in proper format ..");
			MQCommon.maskAccNumber("cardList(); XML is : ", xmlReq);
			logger.info("cardList(); Sending the prepared xml to MQ .. ");

			log.info("cardList(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("cardList(); Response received from MQ .. ");

			log.info("cardList(); Response received from MQ .. ");
			//MQCommon.maskAccNumber("cardList(); Received response from MQ is : ", replyMsg);
			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("cardList(); Sending the received response from MQ to the parser ..");

				log.info("cardList(); Sending the received response from MQ to the parser ..");
				// log.info("cardList(); XML sent for parsing is :"+ replyMsg);
				map = respParser.XmlParser(replyMsg);
				cardDetailList = resParseCardList.responseParserCardList(replyMsg);
				logger.info("cardList(); Received Hash map after parsing of response.");

				log.info("cardList(); Received Hash map after parsing of response.");

				cardListRtn.errorCode = (String) map.get("errCode");
				cardListRtn.errorDescription = (String) map.get("errDesc");

				if (cardListRtn.errorCode.equalsIgnoreCase("0") 
						|| cardListRtn.errorCode.equalsIgnoreCase("00")
						|| cardListRtn.errorCode.equalsIgnoreCase("000")
						|| cardListRtn.errorCode.equalsIgnoreCase("0000")) {
					logger.info("cardList(); Response from MQ is 'SUCCESS'.. ");

					log.info("cardList(); Response from MQ is 'SUCCESS'.. ");
					
					if ((String) map.get("msgId")!= null) {
						cardListRtn.msgId = (String) map.get("msgId");
					}
					if ((String) map.get("dateTimeStampOutStr")!= null) {
						cardListRtn.dateTimeStampOutStr = (String) map.get("dateTimeStampOutStr");
					}
					if ((String) map.get("auditSeqOutStr")!= null) {
						cardListRtn.auditSeqOutStr = (String) map.get("auditSeqOutStr");
					}
					if ((String) map.get("description")!= null) {
						cardListRtn.cardListDesc = (String) map.get("description");
					}
					/*if ((String) map.get("cardNum")!= null) {
						cardList.CardNumber = (String) map.get("cardNum");
					}
					if ((String) map.get("cardSeq")!= null) {
						cardList.CardSeq = (String) map.get("cardSeq");
					}
					if ((String) map.get("uci")!= null) {
						cardList.UCI = (String) map.get("uci");
					}
					if ((String) map.get("title")!= null) {
						cardList.CMTitle = (String) map.get("title");
					}
					if ((String) map.get("name")!= null) {
						cardList.CMFirstName = (String) map.get("name");
					}
					if ((String) map.get("cmFamilyName")!= null) {
						cardList.CMFamilyName = (String) map.get("cmFamilyName");
					}
					if ((String) map.get("emailID")!= null) {
						cardList.CMEmailID = (String) map.get("emailID");
					}
					if ((String) map.get("legalId")!= null) {
						cardList.LegalId = (String) map.get("legalId");
					}
					if ((String) map.get("mobNO")!= null) {
						cardList.MobileNO = (String) map.get("mobNO");
					}
					if ((String) map.get("clientCode")!= null) {
						cardList.ClientCode = (String) map.get("clientCode");
					}
					if ((String) map.get("accountNum")!= null) {
						cardList.AccountNum = (String) map.get("accountNum");
					}
					if ((String) map.get("prodCodeStr")!= null) {
						cardList.ProductCode = (String) map.get("prodCodeStr");
					}*/
					
					if (cardDetailList != null) {
						cardListRtn.cardLists= cardDetailList;
					}
					cardListRtn.status = validStr;

				} else {
					logger.info("cardList(); Response from MQ is 'FAILURE'.. ");

					log.info("cardList(); Response from MQ is 'FAILURE'.. ");
					cardListRtn.status = invalidStr;
				}
				//cardListRtn.cardLists = cardDetailList;
			
			} else {
				logger.info("cardList(); Since the response from MQ is not proper .. ");
				logger.info("cardList(); Setting error values.");
				log.info("cardList(); Since the response from MQ is not proper .. ");
				log.info("cardList(); Setting error values.");
				cardListRtn.errorCode = errorCode;
				cardListRtn.errorDescription = errorDesc;
				cardListRtn.status = invalidStr;
				//cardListRtn.cardLists = cardDetailList;
			}
		
		} catch (Exception e) {
			log.info("cardList(); Exception is raised." + e.toString());
			logger.info("cardList(); Exception is raised." + e.toString());

			//cardListRtn.cardLists = cardDetailList;
			cardListRtn.errorCode = errorCode;
			cardListRtn.errorDescription = errorDesc;
			cardListRtn.status = invalidStr;
			logger.error("cardList(); Reason : "+ e.getStackTrace());

			log.severe("cardList(); Reason : "+ e.getStackTrace());
		
		} finally {
			xmlReq = emptyStr;
			replyMsg = emptyStr;
		//	dateTimeStampOutStr = emptyStr;
		//	auditSeqOutStr = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
		//	maskAccNum = emptyStr;

			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			xmlMap = null;
			map = null;
		}
		logger.info("cardList(); Response is returned to the IVR. Response : " + cardListRtn.toString());
		logger.info("cardList(); Exit ");
		log.info("cardList(); Response is returned to the IVR. Response : " + cardListRtn.toString());
		log.info("cardList(); Exit ");
		return cardListRtn;
	}
}
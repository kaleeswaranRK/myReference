package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class CardDetailsReturn {
	/*public String errorCode = emptyStr;
	public String errorDescription = emptyStr;
	public String status = emptyStr;
	//public String maskAccNum = emptyStr;
	public CardInformation cardInfo = null;
	
	public String toString() {
		String returnStr = emptyStr;
		if (cardInfo != null) {
			//maskAccNum = accInfo.AccountNumber.replace(accInfo.AccountNumber.subSequence(4, accInfo.AccountNumber.length()-5),maskString1);
			returnStr = newLine +
			resErrorCode + errorCode  + newLine +
			resErrorDesc + errorDescription + newLine +
			resStatus + status + newLine +			
			//resAccNum + maskAccNum + newLine +			
			resCurrentBalance + cardInfo.CurrentBalance + newLine +
			resAmountDue + cardInfo.AmountDue + newLine +
			resTotalCreditLimit + cardInfo.TotalCreditLimit + newLine +
			resCashCreditLimit + cardInfo.CashCreditLimit + newLine +
			resCashBalance + cardInfo.CashBalance + newLine +
			resCashAvailable + cardInfo.CashAvailable + newLine +
			resOTB + cardInfo.OTB + newLine +
			resBeginBalance + cardInfo.BeginBalance + newLine +			
			resStatus + cardInfo.Status + newLine;
			
		} else {
			returnStr = newLine +
			resErrorCode + errorCode                 + newLine +
			resErrorDesc + errorDescription          + newLine +
			resStatus + status                    + newLine ;
		}		
		return returnStr;
	}*/
	public String errorCode = emptyStr;
	public String errorDesc = emptyStr;
	public String status = emptyStr;
	public String msgId = emptyStr;
	public String dateTimeStampOutStr = emptyStr;
	public String auditSeqOutStr = emptyStr;
	public String description = emptyStr;
	public String cardNumber = emptyStr;
	public String maskcardNumber = emptyStr;
	public String uci = emptyStr;
	public String cmTitle = emptyStr;
	public String cmFirstName = emptyStr;
	public String cmDateOfBirth = emptyStr;
	public String cmFamilyName = emptyStr;
	public String legalId = emptyStr;
	public String customerEmail = emptyStr;
	public String customerMobile = emptyStr;
	public String cmBranchCode = emptyStr;
	public String cmBillingAddress = emptyStr;
	public String flasherMemo1 = emptyStr;
	public String flasherMemo2 = emptyStr;
	public String clientUnderride = emptyStr;
	public String clientOverride = emptyStr;
	public String cardActivationFlag = emptyStr;
	public String cardActivationDate = emptyStr;
	public String cardExpiryDate = emptyStr;
	public String productType = emptyStr;
	public String pinStatus = emptyStr;
	public String cardStatus = emptyStr;
	public String productCode = emptyStr;
	public String productName = emptyStr;
	public String employeeID = emptyStr;
	public String rmName = emptyStr;
	public String vipLevel = emptyStr;
	public String stopList = emptyStr;
	public String[] transaction = null;
	public String accountNum = emptyStr;
	public String maskAccNum = emptyStr;
	public String primSupplFlag = emptyStr;

	
	public String toString()
	{
		if (!(accountNum.equalsIgnoreCase(emptyStr)))
		 maskAccNum=accountNum.substring(0,4)+"******"+accountNum.substring(accountNum.length()-5,accountNum.length());
		
		if (!(cardNumber.equalsIgnoreCase(emptyStr)))
			maskcardNumber=cardNumber.substring(0,4)+"******"+cardNumber.substring(cardNumber.length()-4,cardNumber.length());
		
		String returnStr = newLine +
				resErrorCode + errorCode  + newLine +
				resErrorDesc + errorDesc  + newLine +
				resStatus + status + newLine +
				resMsgId + msgId + newLine +
				resDateTimeStampLog + dateTimeStampOutStr + newLine +
				resAuditSeq + auditSeqOutStr + newLine +
				resDesc + description + newLine +
				resCardNumber + maskcardNumber + newLine +
				resUCI + uci + newLine +
				resTitle + cmTitle + newLine +
				resName + cmFirstName + newLine +
				resCMFamilyName + cmFamilyName + newLine +
				resDOB + cmDateOfBirth + newLine +
				resLegalID + legalId + newLine +
				resEmail + customerEmail + newLine +
				resMobilePhone + customerMobile    + newLine +
				resBranchCode + cmBranchCode + newLine +
				resMemo1 + flasherMemo1 + newLine +
				resMemo2 + flasherMemo2 + newLine +
				resClientUnderride + clientUnderride + newLine +
				resClientOverride + clientOverride + newLine +
				resCardActivationFlag + cardActivationFlag + newLine +	
				resCardActivationDate + cardActivationDate + newLine +
				resProductType + productType + newLine +
				resPINStatus + pinStatus + newLine +
				resCardStatus + cardStatus + newLine +
				resProductCode + productCode + newLine +
				resProductName + productName + newLine +
				resEmployeeID + employeeID + newLine +
				resRMName + rmName + newLine +
				resVIPLevel + vipLevel + newLine +
				resStopList + stopList + newLine +				
				resAccNum + maskAccNum + newLine +
				resPrimSupplFlag + primSupplFlag + newLine;
		
		if(transaction !=null) {
			for (int j = 0; j < transaction.length; j++) {
				
				returnStr = returnStr +			
						resTransaction + transaction[j] + newLine;
				
			}
		}
		return returnStr;
	}
}
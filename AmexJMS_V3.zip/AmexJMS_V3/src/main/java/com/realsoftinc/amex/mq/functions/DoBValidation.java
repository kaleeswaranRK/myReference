/*
* (C) Copyright 2013 Geomant Kft. 
* All rights reserved. 
* 
*/

package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
import com.realsoftinc.amex.mq.returnObjs.AdditionalCardInfo;
import com.realsoftinc.amex.mq.returnObjs.DoBValidationReturn;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function Date Of Birth Validation
 * 
 * @author Marijana Dujovic / Geomant Kft.
 */
public class DoBValidation {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(DoBValidation.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public DoBValidationReturn dateOfBirthValidation(String AccNum, String dob) {
		logger.info("dateOfBirthValidation(); Date Of Birth Validation function is called by IVR .. ");
		logger.info("dateOfBirthValidation(); Enter ");
		log.info("dateOfBirthValidation(); Date Of Birth Validation function is called by IVR .. ");
		log.info("dateOfBirthValidation(); Enter ");

		Map<String, String> map = null;
		Map<String, String> xmlMap = null;

		MQCommon mqc = null;
		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser cardnoparser = null;
		DoBValidationReturn dobvalidate = null;
		AdditionalCardInfo addInfo = null;

		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String xmlReq = emptyStr;
		String replyMsg = emptyStr;

		// String errorCode = emptyStr;
		// String errorDescription = emptyStr;
		// String dateofbirth = emptyStr;
		String status = emptyStr;
		// String sso = emptyStr;
		String maskAccNum = emptyStr;
		Boolean flag = false;

		try {
			mqc = new MQCommon();
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			cardnoparser = new ResponseParser();
			addInfo = new AdditionalCardInfo();
			dobvalidate = new DoBValidationReturn();

			/*
			 * sso = MQCommon.SSO; if(sso == null) {
			 * log.info("dateOfBirthValidation(); sso is null");
			 * log.info("dateOfBirthValidation(); Calling getSSO() function .. "); sso =
			 * mqc.getSSO(); } else { if(sso.equalsIgnoreCase(emptyStr)) {
			 * log.info("dateOfBirthValidation(); sso is empty string");
			 * log.info("dateOfBirthValidation(); Calling getSSO() function .. "); sso =
			 * mqc.getSSO(); } }
			 */
			if (AccNum.length() == 12) {

				maskAccNum = AccNum.substring(0, 4) + "******" + AccNum.substring(AccNum.length() - 5, AccNum.length());
				logger.info("dateOfBirthValidation(); Account Number is : " + maskAccNum);

				log.info("dateOfBirthValidation(); Account Number is : " + maskAccNum);
			} else {
				logger.info("dateOfBirthValidation(); Account Number is less than 12 digits.");

				log.info("dateOfBirthValidation(); Account Number is less than 12 digits.");
			}
			logger.info("dateOfBirthValidation(); Date Of Birth is : " + dob);

			logger.info("dateOfBirthValidation(); Calling the getDateTime function ..");
			log.info("dateOfBirthValidation(); Date Of Birth is : " + dob);

			log.info("dateOfBirthValidation(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("dateOfBirthValidation(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("dateOfBirthValidation(); Calling the getAuditSequence function ..");
			log.info("dateOfBirthValidation(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("dateOfBirthValidation(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("dateOfBirthValidation(); Audit Sequence is : " + auditSeqInStr);

			logger.info("dateOfBirthValidation(); Created all the required parameters to prepare the xml ..");
			log.info("dateOfBirthValidation(); Audit Sequence is : " + auditSeqInStr);

			log.info("dateOfBirthValidation(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("AccountNumber", AccNum);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("SSO", mqc.getproperties("DobValidation.SSO"));
			xmlMap.put("MessageLength", mqc.getproperties("DobValidation.MsgLength"));
			xmlMap.put("MessageId", MsgId_DobValid);
			xmlMap.put("Description", DobValidation_Desc);
			logger.info("dateOfBirthValidation(); Sending values to form proper form of xml request .. ");

			log.info("dateOfBirthValidation(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "DateOfBirthValidation");
			logger.info("dateOfBirthValidation(); Received xml in proper format ..");
	
			log.info("dateOfBirthValidation(); Received xml in proper format ..");
			// log.info("dateOfBirthValidation(); XML is : " + xmlReq);
			// Added to encrypt account number when display request in log file
			MQCommon.maskAccNumber("dateOfBirthValidation(); XML is : ", xmlReq);
			logger.info("dateOfBirthValidation(); Sending this xml as the request to MQ ..");

			log.info("dateOfBirthValidation(); Sending this xml as the request to MQ ..");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("dateOfBirthValidation(); Response received from MQ .. ");

			log.info("dateOfBirthValidation(); Response received from MQ .. ");
			MQCommon.maskAccNumber("dateOfBirthValidation(); Received response from MQ is : ", replyMsg);
			// log.info("dateOfBirthValidation(); Received response from MQ is : " +
			// replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("dateOfBirthValidation(); Sending the received response from MQ to the parser ..");

				log.info("dateOfBirthValidation(); Sending the received response from MQ to the parser ..");
				// log.info("dateOfBirthValidation(); XML sent for parsing is :"+ replyMsg);
				map = cardnoparser.XmlParser(replyMsg);
				logger.info("dateOfBirthValidation(); Received Hash map after parsing of response.");

				log.info("dateOfBirthValidation(); Received Hash map after parsing of response.");

				dobvalidate.errorCode = (String) map.get("errCode");
				dobvalidate.errorDescription = (String) map.get("errDes");
				logger.info("dateOfBirthValidation(); Error code is: " + dobvalidate.errorCode.toString());

				log.info("dateOfBirthValidation(); Error code is: " + dobvalidate.errorCode.toString());
				if (dobvalidate.errorCode.toString().equalsIgnoreCase("0")
						|| dobvalidate.errorCode.toString().equalsIgnoreCase("00")
						|| dobvalidate.errorCode.toString().equalsIgnoreCase("000")
						|| dobvalidate.errorCode.toString().equalsIgnoreCase("0000")) {
					// Add information to AdditionalCardInfo
					logger.info("dateOfBirthValidation(); Adding information to AdditionalCardInfo...");

					log.info("dateOfBirthValidation(); Adding information to AdditionalCardInfo...");

					if ((String) map.get("dateOfBirth") != null)
						addInfo.DateOfBirth = (String) map.get("dateOfBirth");
					if ((String) map.get("passportNum") != null)
						addInfo.PassportNumber = (String) map.get("passportNum");
					if ((String) map.get("cprid") != null)
						addInfo.CPRID = (String) map.get("cprid");
					if ((String) map.get("bankName") != null)
						addInfo.BankName = (String) map.get("bankName");
					if ((String) map.get("bankBranch") != null)
						addInfo.BankBranch = (String) map.get("bankBranch");
					if ((String) map.get("bankAccNumber") != null)
						addInfo.BankAccountNumber = (String) map.get("bankAccNumber");
					if ((String) map.get("nationality") != null)
						addInfo.Nationality = (String) map.get("nationality");
					if ((String) map.get("income") != null)
						addInfo.Income = (String) map.get("income");
					if ((String) map.get("xRef1") != null)
						addInfo.XRef1 = (String) map.get("xRef1");
					if ((String) map.get("xRef2") != null)
						addInfo.XRef2 = (String) map.get("xRef2");
					if ((String) map.get("memberSince") != null)
						addInfo.MemberSince = (String) map.get("memberSince");
					if ((String) map.get("homeAddr1") != null)
						addInfo.HomeAddress1 = (String) map.get("homeAddr1");
					if ((String) map.get("homeAddr2") != null)
						addInfo.HomeAddress2 = (String) map.get("homeAddr2");
					if ((String) map.get("homeAddr3") != null)
						addInfo.HomeAddress3 = (String) map.get("homeAddr3");
					if ((String) map.get("homePhArea") != null)
						addInfo.HomePhoneArea = (String) map.get("homePhArea");
					if ((String) map.get("homePh") != null)
						addInfo.HomePhone = (String) map.get("homePh");
					if ((String) map.get("mobPh") != null)
						addInfo.MobilePhone = (String) map.get("mobPh");
					if ((String) map.get("homeMail") != null)
						addInfo.HomeEmail = (String) map.get("homeMail");
					if ((String) map.get("prevAddr1") != null)
						addInfo.PreviousAddress1 = (String) map.get("prevAddr1");
					if ((String) map.get("prevAddr2") != null)
						addInfo.PreviousAddress2 = (String) map.get("prevAddr2");
					if ((String) map.get("prevAddr3") != null)
						addInfo.PreviousAddress3 = (String) map.get("prevAddr3");
					if ((String) map.get("statAddress1") != null)
						addInfo.StatementAddress1 = (String) map.get("statAddress1");
					if ((String) map.get("statAddress2") != null)
						addInfo.StatementAddress2 = (String) map.get("statAddress2");
					if ((String) map.get("statAddress3") != null)
						addInfo.StatementAddress3 = (String) map.get("statAddress3");
					if ((String) map.get("empName") != null)
						addInfo.EmployerName = (String) map.get("empName");
					if ((String) map.get("empAddr1") != null)
						addInfo.EmployerAddress1 = (String) map.get("empAddr1");
					if ((String) map.get("empAddr2") != null)
						addInfo.EmployerAddress2 = (String) map.get("empAddr2");
					if ((String) map.get("empAddr3") != null)
						addInfo.EmployerAddress3 = (String) map.get("empAddr3");
					if ((String) map.get("empPhArea") != null)
						addInfo.EmployerPhoneArea = (String) map.get("empPhArea");
					if ((String) map.get("empPhone") != null)
						addInfo.EmployerPhone = (String) map.get("empPhone");
					if ((String) map.get("empFax") != null)
						addInfo.EmployerFax = (String) map.get("empFax");
					if ((String) map.get("empMail") != null)
						addInfo.EmployerMail = (String) map.get("empMail");

				} else {
					addInfo.DateOfBirth = emptyStr;
				}

				if (addInfo.DateOfBirth.equalsIgnoreCase(emptyStr)) {
					logger.info("dateOfBirthValidation(); DateOfBirth returned from MQ is empty.");

					log.info("dateOfBirthValidation(); DateOfBirth returned from MQ is empty.");
				}
				if (addInfo.DateOfBirth.length() == 7) {
					addInfo.DateOfBirth = "0" + addInfo.DateOfBirth;
				}
				logger.info("dateOfBirthValidation(); Date Of Birth is : " + addInfo.DateOfBirth);

				log.info("dateOfBirthValidation(); Date Of Birth is : " + addInfo.DateOfBirth);

				flag = dob.equalsIgnoreCase(addInfo.DateOfBirth);
				if (dob.equalsIgnoreCase(emptyStr)) {
					flag = false;
				}

				if (flag) {
					logger.info("dateOfBirthValidation(); Response from MQ is 'SUCCESS'.. ");

					log.info("dateOfBirthValidation(); Response from MQ is 'SUCCESS'.. ");
					status = validStr;
				} else {
					logger.info("dateOfBirthValidation(); Response from MQ is 'FAILURE'.. ");

					log.info("dateOfBirthValidation(); Response from MQ is 'FAILURE'.. ");
					status = invalidStr;
				}

				dobvalidate.status = status;

			} // Replay message is null or empty
			else {
				logger.info("dateOfBirthValidation(); Since the response from MQ is not proper .. ");
				logger.info("dateOfBirthValidation(); Setting error values.");
				log.info("dateOfBirthValidation(); Since the response from MQ is not proper .. ");
				log.info("dateOfBirthValidation(); Setting error values.");
				dobvalidate.errorCode = MQConstants.errorCode;
				dobvalidate.errorDescription = errorDesc;
				dobvalidate.status = invalidStr;
				dobvalidate.addInfo = addInfo;
			}
		} catch (Exception e) {
			logger.info("dateOfBirthValidation(); Exception is raised." + e.toString());

			log.info("dateOfBirthValidation(); Exception is raised." + e.toString());
			dobvalidate.errorCode = MQConstants.errorCode;
			dobvalidate.errorDescription = errorDesc;
			dobvalidate.status = invalidStr;
			dobvalidate.addInfo = addInfo;
			logger.error("dateOfBirthValidation(); Reason : " + e.getStackTrace());

			log.severe("dateOfBirthValidation(); Reason : " + e.getStackTrace());
		} finally {
			map = null;
			xmlMap = null;
			mqc = null;
			rc = null;
			rr = null;
			cardnoparser = null;

			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			xmlReq = emptyStr;
			replyMsg = emptyStr;
			// errorCode = emptyStr;
			// errorDescription = emptyStr;
			// dateofbirth = emptyStr;
			status = emptyStr;
			// sso = emptyStr;
			flag = false;
			maskAccNum = emptyStr;
		}
		logger.info("dateOfBirthValidation(); Response is returned to the IVR. Response : " + dobvalidate.toString());
		logger.info("dateOfBirthValidation(); Exit");
		log.info("dateOfBirthValidation(); Response is returned to the IVR. Response : " + dobvalidate.toString());
		log.info("dateOfBirthValidation(); Exit");
		return dobvalidate;
	}
}

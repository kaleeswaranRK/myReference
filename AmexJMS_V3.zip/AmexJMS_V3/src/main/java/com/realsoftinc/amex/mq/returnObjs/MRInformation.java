package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class MRInformation 
{
	
	public String adjustedPoints = emptyStr;
	public String availablePoints = emptyStr;
	public String bonusPoints = emptyStr;
	public String closingBalance = emptyStr;
	public String earnedPoints = emptyStr;
	public String memberId = emptyStr;
	public String pointsOpeningBalance = emptyStr;
	public String previousBalance = emptyStr;
	public String redeemedPoints = emptyStr;
	
	
	public String toString()
	{
	    //maskAccNum = AccountNumber.replace(AccountNumber.subSequence(4, AccountNumber.length()-5),maskString1);
		String returnStr = emptyStr;		
			returnStr = newLine +
			//resAccNum + maskAccNum + newLine +			
			resAdjPoints + adjustedPoints    + newLine +
			resAvailPoints + availablePoints        + newLine +
			resBonusPoints + bonusPoints  + newLine +
			resClosingBalance + closingBalance   + newLine +
			resEarnedPoints + earnedPoints       + newLine +
			resMembId + memberId     + newLine +
			resOpenBalance + pointsOpeningBalance               + newLine +
			resPrevBalance + previousBalance      + newLine +			
			resReedemedPoints + redeemedPoints           + newLine ;
			
		return returnStr;
	}
}

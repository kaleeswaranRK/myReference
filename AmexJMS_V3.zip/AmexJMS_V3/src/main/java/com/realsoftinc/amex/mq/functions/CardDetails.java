/*
* (C) Copyright 2019 Tele Apps India Pvt Ltd.. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.CardDetailsReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
import com.realsoftinc.amex.mq.util.ResponseParserRecentTransaction;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function Card Details
 * 
 * @author Prasanth.
 */

public class CardDetails {
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(CardDetails.class);

	Logger log = Utility.getLogger();

	@SuppressWarnings({ "static-access", "unchecked" })
	public CardDetailsReturn cardDetail(String CardNum) {
		logger.info("cardDetails(); Card Details function is called by IVR .. ");
		logger.info("cardDetails(); Enter ");
		log.info("cardDetails(); Card Details function is called by IVR .. ");
		log.info("cardDetails(); Enter ");

		MQCommon mqc = new MQCommon();

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		String auditSeqInStr = emptyStr;
		String maskCardNum = emptyStr;
		String dateTimeStampInStr = emptyStr;

		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;
		ResponseParserRecentTransaction resptrans = null;
		// CardInformation cardInfo = null;
		CardDetailsReturn cardDetailsRtn = null;
		String[] transAct = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;
		try {

			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			// cardInfo = new CardInformation();
			cardDetailsRtn = new CardDetailsReturn();
			respParser = new ResponseParser();
			resptrans = new ResponseParserRecentTransaction();

			if (CardNum.length() == 15) {
				maskCardNum = CardNum.substring(0, 4) + "******"
						+ CardNum.substring(CardNum.length() - 5, CardNum.length());
				logger.info("cardDetails(); Card Number is : " + maskCardNum);

				log.info("cardDetails(); Card Number is : " + maskCardNum);

			} else {
				logger.info("cardDetails(); Card Number is less than 15 digits.");

				log.info("cardDetails(); Card Number is less than 15 digits.");
			}
			logger.info("cardDetails(); Calling the getDateTime function ..");

			log.info("cardDetails(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("cardDetails(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("cardDetails(); Calling the getAuditSequence function ..");
			log.info("cardDetails(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("cardDetails(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("cardDetails(); Audit Sequence is : " + auditSeqInStr);

			logger.info("cardDetails(); Created all the required parameters to prepare the xml ..");
			log.info("cardDetails(); Audit Sequence is : " + auditSeqInStr);

			log.info("cardDetails(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("CardNumber", CardNum);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("MessageId", MsgId_CardDetails);
			xmlMap.put("SysID", mqc.getproperties("CardDetails.SysID"));
			xmlMap.put("UCI", MQConstants.emptyStr);
			logger.info("cardDetails(); Sending values to form proper format of xml request .. ");

			log.info("cardDetails(); Sending values to form proper format of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "CardDetails");
			logger.info("cardDetails(); Received xml in proper format ..");

			log.info("cardDetails(); Received xml in proper format ..");
			MQCommon.maskAccNumber("cardDetails(); XML is : ", xmlReq);
			logger.info("cardDetails(); Sending the prepared xml to MQ .. ");

			log.info("cardDetails(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("cardDetails(); Response received from MQ .. ");

			log.info("cardDetails(); Response received from MQ .. ");
			MQCommon.maskAccNumber("cardDetails(); Received response from MQ is : ", replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("cardDetails(); Sending the received response from MQ to the parser ..");

				log.info("cardDetails(); Sending the received response from MQ to the parser ..");
				map = respParser.XmlParser(replyMsg);
				transAct = resptrans.responseParserRecentTransaction(replyMsg);
				logger.info("cardDetails(); Received Hash map after parsing of response.");

				log.info("cardDetails(); Received Hash map after parsing of response.");

				cardDetailsRtn.errorCode = (String) map.get("errCode");
				cardDetailsRtn.errorDesc = (String) map.get("errDesc");

				if (cardDetailsRtn.errorCode.equalsIgnoreCase("0") || cardDetailsRtn.errorCode.equalsIgnoreCase("00")
						|| cardDetailsRtn.errorCode.equalsIgnoreCase("000")
						|| cardDetailsRtn.errorCode.equalsIgnoreCase("0000")) {
					logger.info("cardDetails(); Response from MQ is 'SUCCESS'.. ");

					log.info("cardDetails(); Response from MQ is 'SUCCESS'.. ");

					if ((String) map.get("returnMsgIdActualStr") != null) {
						cardDetailsRtn.msgId = (String) map.get("returnMsgIdActualStr");
					}
					if ((String) map.get("auditSeqOutStr") != null) {
						cardDetailsRtn.auditSeqOutStr = (String) map.get("auditSeqOutStr");
					}
					if ((String) map.get("dateTimeStampOutStr") != null) {
						cardDetailsRtn.dateTimeStampOutStr = (String) map.get("dateTimeStampOutStr");
					}
					if ((String) map.get("description") != null) {
						cardDetailsRtn.description = (String) map.get("description");
					}
					if ((String) map.get("cardNum") != null) {
						cardDetailsRtn.cardNumber = (String) map.get("cardNum");
					}
					if ((String) map.get("uci") != null) {
						cardDetailsRtn.uci = (String) map.get("uci");
					}
					if ((String) map.get("CMTitle") != null) {
						cardDetailsRtn.cmTitle = (String) map.get("CMTitle");
					}
					if ((String) map.get("CMFirstName") != null) {
						cardDetailsRtn.cmFirstName = (String) map.get("CMFirstName");
					}
					if ((String) map.get("cmFamilyName") != null) {
						cardDetailsRtn.cmFamilyName = (String) map.get("cmFamilyName");
					}
					if ((String) map.get("CMDateOfBirth") != null) {
						cardDetailsRtn.cmDateOfBirth = (String) map.get("CMDateOfBirth");
					}
					if ((String) map.get("LegalID") != null) {
						cardDetailsRtn.legalId = (String) map.get("LegalID");
					}
					if ((String) map.get("CustomerEmail") != null) {
						cardDetailsRtn.customerEmail = (String) map.get("CustomerEmail");
					}
					if ((String) map.get("CustomerMobile") != null) {
						cardDetailsRtn.customerMobile = (String) map.get("CustomerMobile");
					}
					if ((String) map.get("CMBranchCode") != null) {
						cardDetailsRtn.cmBranchCode = (String) map.get("CMBranchCode");
					}
					if ((String) map.get("cmBillingAddress") != null) {
						cardDetailsRtn.cmBillingAddress = (String) map.get("cmBillingAddress");
					}
					if ((String) map.get("FlasherMemo1") != null) {
						cardDetailsRtn.flasherMemo1 = (String) map.get("FlasherMemo1");
					}
					if ((String) map.get("FlasherMemo2") != null) {
						cardDetailsRtn.flasherMemo2 = (String) map.get("FlasherMemo2");
					}
					if ((String) map.get("clientUnderride") != null) {
						cardDetailsRtn.clientUnderride = (String) map.get("clientUnderride");
					}
					if ((String) map.get("clientUnderride") != null) {
						cardDetailsRtn.clientUnderride = (String) map.get("clientUnderride");
					}
					if ((String) map.get("clientOverride") != null) {
						cardDetailsRtn.clientOverride = (String) map.get("clientOverride");
					}
					if ((String) map.get("cardActivationFlag") != null) {
						cardDetailsRtn.cardActivationFlag = (String) map.get("cardActivationFlag");
					}
					if ((String) map.get("cardActivationDate") != null) {
						cardDetailsRtn.cardActivationDate = (String) map.get("cardActivationDate");
					}
					if ((String) map.get("cardExpiryDate") != null) {
						cardDetailsRtn.cardExpiryDate = (String) map.get("cardExpiryDate");
					}
					if ((String) map.get("productType") != null) {
						cardDetailsRtn.productType = (String) map.get("productType");
					}
					if ((String) map.get("pinStatus") != null) {
						cardDetailsRtn.pinStatus = (String) map.get("pinStatus");
					}
					if ((String) map.get("cardStatus") != null) {
						cardDetailsRtn.cardStatus = (String) map.get("cardStatus");
					}
					if ((String) map.get("ProductCode") != null) {
						cardDetailsRtn.productCode = (String) map.get("ProductCode");
					}
					if ((String) map.get("productName") != null) {
						cardDetailsRtn.productName = (String) map.get("productName");
					}
					if ((String) map.get("employeeID") != null) {
						cardDetailsRtn.employeeID = (String) map.get("employeeID");
					}
					if ((String) map.get("rmName") != null) {
						cardDetailsRtn.rmName = (String) map.get("rmName");
					}
					if ((String) map.get("vipLevel") != null) {
						cardDetailsRtn.vipLevel = (String) map.get("vipLevel");
					}
					if ((String) map.get("stopList") != null) {
						cardDetailsRtn.stopList = (String) map.get("stopList");
					}
					if ((String) map.get("accountNum") != null) {
						cardDetailsRtn.accountNum = (String) map.get("accountNum");
					}
					if ((String) map.get("PrimSuppFlag") != null) {
						cardDetailsRtn.primSupplFlag = (String) map.get("PrimSuppFlag");
					}

					if (transAct != null) {
						cardDetailsRtn.transaction = transAct;
					}

					/*
					 * if((String) map.get("status")!= null) { cardDetailsRtn.status = (String)
					 * map.get("status"); }
					 */
					cardDetailsRtn.status = validStr;

				} else {
					logger.info("cardDetails(); Response from MQ is 'FAILURE'.. ");

					log.info("cardDetails(); Response from MQ is 'FAILURE'.. ");
					cardDetailsRtn.status = invalidStr;
				}
				// cardDetailsRtn.cardInfo = cardInfo;

			} else {
				logger.info("cardDetails(); Since the response from MQ is not proper .. ");
				logger.info("cardDetails(); Setting error values.");
				log.info("cardDetails(); Since the response from MQ is not proper .. ");
				log.info("cardDetails(); Setting error values.");
				cardDetailsRtn.errorCode = errorCode;
				cardDetailsRtn.errorDesc = errorDesc;
				cardDetailsRtn.status = invalidStr;
				// cardDetailsRtn.cardInfo = cardInfo;
			}

		} catch (Exception e) {
			log.info("cardDetails(); Exception is raised." + e.toString());
			logger.info("cardDetails(); Exception is raised." + e.toString());

			// cardDetailsRtn.cardInfo = cardInfo;
			cardDetailsRtn.errorCode = errorCode;
			cardDetailsRtn.errorDesc = errorDesc;
			cardDetailsRtn.status = invalidStr;
			logger.error("cardDetails(); Reason : " + e.getStackTrace());

			log.severe("cardDetails(); Reason : " + e.getStackTrace());

		} finally {
			xmlReq = emptyStr;
			replyMsg = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			maskCardNum = emptyStr;

			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			// cardInfo = null;
			xmlMap = null;
			map = null;
		}
		logger.info("cardDetails(); Response is returned to the IVR. Response : " + cardDetailsRtn.toString());
		logger.info("cardDetails(); Exit ");
		log.info("cardDetails(); Response is returned to the IVR. Response : " + cardDetailsRtn.toString());
		log.info("cardDetails(); Exit ");
		return cardDetailsRtn;
	}
}

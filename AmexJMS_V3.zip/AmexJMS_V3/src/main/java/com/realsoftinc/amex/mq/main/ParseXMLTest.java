package com.realsoftinc.amex.mq.main;

import java.util.Iterator;
import java.util.List;

import org.dom4j.*;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.returnObjs.CardLst;

public class ParseXMLTest {
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(ParseXMLTest.class);

	public ParseXMLTest() {

		try {
			/*
			 * FileInputStream file = new FileInputStream(new
			 * File("C:/Users/Akash/Desktop/response.xml"));
			 * 
			 * int ch; String replyText = ""; while((ch = file.read()) !=-1) {
			 * System.out.print((char)ch); } replyText = String.valueOf((char)ch);
			 */

			String replyText = "<Message_Res>" + "<MessageID>8266</MessageID>" + "<CardList>" + "<CardDetails>"
					+ "<CardNumber>12345</CardNumber>" + "<CardSeq>card</CardSeq>" + "<UCI>987</UCI>"
					+ "<CMTitle>Title</CMTitle>" + "<CMFirstName>name</CMFirstName>"
					+ "<CMFamilyName>family</CMFamilyName>" + "<CMDateOfBirth>DOB</CMDateOfBirth>"
					+ "<CMEmail>Email</CMEmail>" + "<LegalID>LegalId</LegalID>"
					+ "<MobileNumber>9876543210</MobileNumber>" + "<ClientCode>1</ClientCode>"
					+ "<AccountNumber>963524712</AccountNumber>" + "<ProductCode>337</ProductCode>" + "</CardDetails>"
					+ "<CardDetails>" + "<CardNumber>6789</CardNumber>" + "<CardSeq>card2</CardSeq>" + "<UCI>007</UCI>"
					+ "<CMTitle>Title</CMTitle>" + "<CMFirstName>name</CMFirstName>"
					+ "<CMFamilyName>family</CMFamilyName>" + "<CMDateOfBirth>DOB</CMDateOfBirth>"
					+ "<CMEmail>Email</CMEmail>" + "<LegalID>LegalId</LegalID>"
					+ "<MobileNumber>678567897</MobileNumber>" + "<ClientCode>1</ClientCode>"
					+ "<AccountNumber>8907653467456</AccountNumber>" + "<ProductCode>009</ProductCode>"
					+ "</CardDetails>" + "</CardList>" + "<ErrorCode>0</ErrorCode>" + "<ErrorDesc>SUCCESS</ErrorDesc>"
					+ "</Message_Res>";

			System.out.print(replyText);
			Document document = DocumentHelper.parseText(replyText);

			/*
			 * List list1 = document.selectNodes("//Message_Res"); Iterator iter1 =
			 * list1.iterator(); System.out.println("XmlParser(); Node is : //Message_Res");
			 * List list2 = document.selectNodes("//CardList"); List<Node> nodes =
			 * document.selectNodes("//Message_Res/CardList/CardDetails"); for (Node node :
			 * nodes) { System.out.println("\nCurrent Element :" + node.getName());
			 * System.out.println("Card Number : " +
			 * node.selectSingleNode("CardNumber").getText());
			 * System.out.println("Card Seq : " +
			 * node.selectSingleNode("CardSeq").getText()); System.out.println("UCI : " +
			 * node.selectSingleNode("UCI").getText()); System.out.println("CM Title : " +
			 * node.selectSingleNode("CMTitle").getText());
			 * System.out.println("CM First Name : " +
			 * node.selectSingleNode("CMFirstName").getText());
			 * System.out.println("CM Family Name : " +
			 * node.selectSingleNode("CMFamilyName").getText());
			 * System.out.println("CM Date Of Birth : " +
			 * node.selectSingleNode("CMDateOfBirth").getText());
			 * System.out.println("CM Email : " +
			 * node.selectSingleNode("CMEmail").getText()); System.out.println("Legal ID : "
			 * + node.selectSingleNode("LegalID").getText());
			 * System.out.println("Mobile Number : " +
			 * node.selectSingleNode("MobileNumber").getText()); }
			 */

			/*
			 * while(iter1.hasNext()) { Element element = (Element)iter1.next();
			 * for(Iterator iterator = element.elementIterator("CardList");
			 * iterator.hasNext();) { Element titleElement = (Element)iterator.next();
			 * String transaction = titleElement.getText().trim();
			 * System.out.println("XmlParser(); Statement Option is : " + transaction); } }
			 */

			// xmlmap = new HashMap<String , String>();
			// Document document = DocumentHelper.parseText(replyText);

			List list6 = document.selectNodes("//Message_Res/CardList/CardDetails");
			logger.info("\n Number Of CardDetails: " + list6.size());
			System.out.println("\n Number Of CardDetails: " + list6.size());

			/** GetCard List **/
			Iterator iter6 = list6.iterator();
			System.out.println("XmlParser(); Node is : //Message_Res/CardList/CardDetails");
			logger.info("XmlParser(); Node is : //Message_Res/CardList/CardDetails");

			CardLst[] list_ = new CardLst[list6.size()];
			int i = 0;
			while (iter6.hasNext()) {
				Element element = (Element) iter6.next();
				CardLst list = new CardLst();

				for (Iterator iterator = element.elementIterator("CardNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String cardnumber = titleElement.getText().trim();
					System.out.println("XmlParser(); Card Number : " + cardnumber);
					logger.info("XmlParser(); Card Number : " + cardnumber);
					list.CardNumber = cardnumber;
				}
				for (Iterator iterator = element.elementIterator("CardSeq"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String cardseq = titleElement.getText().trim();
					logger.info("XmlParser(); Card Seq is : " + cardseq);

					System.out.println("XmlParser(); Card Seq is : " + cardseq);
					list.CardSeq = cardseq;
				}
				for (Iterator iterator = element.elementIterator("UCI"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String uci = titleElement.getText().trim();
					logger.info("XmlParser(); UCI is : " + uci);

					System.out.println("XmlParser(); UCI is : " + uci);
					list.UCI = uci;
				}
				for (Iterator iterator = element.elementIterator("CMTitle"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String cmtitle = titleElement.getText().trim();
					logger.info("XmlParser(); CM Title is : " + cmtitle);
					System.out.println("XmlParser(); CM Title is : " + cmtitle);
					list.CMTitle = cmtitle;
				}
				for (Iterator iterator = element.elementIterator("CMFirstName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String cmfirstname = titleElement.getText().trim();
					logger.info("XmlParser(); CM First Name is : " + cmfirstname);
					System.out.println("XmlParser(); CM First Name is : " + cmfirstname);
					list.CMFirstName = cmfirstname;
				}
				for (Iterator iterator = element.elementIterator("CMFamilyName"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String cmfamilyname = titleElement.getText().trim();
					logger.info("XmlParser(); CM Family Name is : " + cmfamilyname);

					System.out.println("XmlParser(); CM Family Name is : " + cmfamilyname);
					list.CMFamilyName = cmfamilyname;
				}
				for (Iterator iterator = element.elementIterator("CMDateOfBirth"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String cmdateofbirth = titleElement.getText().trim();
					logger.info("XmlParser(); CM Date Of Birth is : " + cmdateofbirth);
					System.out.println("XmlParser(); CM Date Of Birth is : " + cmdateofbirth);
					list.CMDateOfBirth = cmdateofbirth;
				}
				for (Iterator iterator = element.elementIterator("CMEmail"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String cmemail = titleElement.getText().trim();
					logger.info("XmlParser(); CM Email is : " + cmemail);
					System.out.println("XmlParser(); CM Email is : " + cmemail);
					list.CMEmailID = cmemail;
				}
				for (Iterator iterator = element.elementIterator("LegalID"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String legalid = titleElement.getText().trim();
					logger.info("XmlParser(); Legal ID is : " + legalid);
					System.out.println("XmlParser(); Legal ID is : " + legalid);
					list.LegalId = legalid;
				}
				for (Iterator iterator = element.elementIterator("MobileNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String mobilenumber = titleElement.getText().trim();
					logger.info("XmlParser(); Mobile Number is : " + mobilenumber);
					System.out.println("XmlParser(); Mobile Number is : " + mobilenumber);
					list.MobileNO = mobilenumber;
				}
				for (Iterator iterator = element.elementIterator("ClientCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String clientcode = titleElement.getText().trim();
					logger.info("XmlParser(); Client Code is : " + clientcode);
					System.out.println("XmlParser(); Client Code is : " + clientcode);
					list.ClientCode = clientcode;
				}
				for (Iterator iterator = element.elementIterator("AccountNumber"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String accountnumber = titleElement.getText().trim();
					logger.info("XmlParser(); Account Number is : " + accountnumber);
					System.out.println("XmlParser(); Account Number is : " + accountnumber);
					list.AccountNum = accountnumber;
				}
				for (Iterator iterator = element.elementIterator("ProductCode"); iterator.hasNext();) {
					Element titleElement = (Element) iterator.next();
					String productcode = titleElement.getText().trim();
					logger.info("XmlParser(); Product Code is : " + productcode);
					System.out.println("XmlParser(); Product Code is : " + productcode);
					list.ProductCode = productcode;
				}

				list_[i] = list;
				i++;
			}
			logger.info("Array Size: " + list_.length);
			System.out.println("Array Size: " + list_.length);

			CardLst[] list_1 = list_;

			for (int j = 0; j < list_1.length; j++) {

				logger.info("AccountNum:" + list_1[j].AccountNum);
				logger.info("CardNumber:" + list_1[j].CardNumber);
				logger.info("CardSeq:" + list_[j].CardSeq);
				logger.info("CMFirstName:" + list_[j].CMFirstName);
				logger.info("DateTimeStamp:" + list_[j].DateTimeStamp);
				logger.info("MobileNO:" + list_[j].MobileNO);

				System.out.println("AccountNum:" + list_1[j].AccountNum);
				System.out.println("CardNumber:" + list_1[j].CardNumber);
				System.out.println("CardSeq:" + list_[j].CardSeq);
				System.out.println("CMFirstName:" + list_[j].CMFirstName);
				System.out.println("CMFamilyName:" + list_[j].CMFamilyName);
				System.out.println("DateTimeStamp:" + list_[j].DateTimeStamp);
				System.out.println("MobileNO:" + list_[j].MobileNO);

			}

			// file.close();
		} catch (Exception e) {

			logger.error("Exception acquired" + e);

		}
	}

	/*
	 * public static void main(String args[]) { ParseXMLTest pas = new
	 * ParseXMLTest(); }
	 */

}

/*
* (C) Copyright 2019 Tele Apps India Pvt Ltd.. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.GetClientCodeReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
import com.realsoftinc.amex.mq.util.ResponseParserRecentTransaction;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function Card Details
 * 
 * @author Prasanth.
 */

public class GetClientCode {
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(GetClientCode.class);

	Logger log = Utility.getLogger();

	@SuppressWarnings({ "static-access", "unchecked" })
	public GetClientCodeReturn getClientCode(String mobNum) {
		logger.info("getClientCode(); Get Client Code function is called by IVR .. ");
		logger.info("getClientCode(); Enter ");
		log.info("getClientCode(); Get Client Code function is called by IVR .. ");
		log.info("getClientCode(); Enter ");

		MQCommon mqc = new MQCommon();

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;
		String auditSeqInStr = emptyStr;
		String dateTimeStampInStr = emptyStr;

		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser respParser = null;
		GetClientCodeReturn getClientCodeRtn = null;

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;
		try {

			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			// cardInfo = new CardInformation();
			getClientCodeRtn = new GetClientCodeReturn();
			respParser = new ResponseParser();
			logger.info("getClientCode(); Mobile Number Passed is : " + mobNum);

			logger.info("getClientCode(); Calling the getDateTime function ..");
			log.info("getClientCode(); Mobile Number Passed is : " + mobNum);

			log.info("getClientCode(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("getClientCode(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("getClientCode(); Calling the getAuditSequence function ..");
			log.info("getClientCode(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("getClientCode(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("getClientCode(); Audit Sequence is : " + auditSeqInStr);

			logger.info("getClientCode(); Created all the required parameters to prepare the xml ..");
			log.info("getClientCode(); Audit Sequence is : " + auditSeqInStr);

			log.info("getClientCode(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("MobileNO", mobNum);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("MessageId", MsgId_GetClientCode);
			logger.info("getClientCode(); Sending values to form proper format of xml request .. ");

			log.info("getClientCode(); Sending values to form proper format of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "GetClientCode");
			logger.info("getClientCode(); Received xml in proper format ..");

			logger.info("getClientCode(); Sending the prepared xml to MQ .. ");
			log.info("getClientCode(); Received xml in proper format ..");

			log.info("getClientCode(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("getClientCode(); Response received from MQ .. ");

			log.info("getClientCode(); Response received from MQ .. ");
			MQCommon.maskAccNumber("cardDetails(); Received response from MQ is : ", replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("getClientCode(); Sending the received response from MQ to the parser ..");

				log.info("getClientCode(); Sending the received response from MQ to the parser ..");
				map = respParser.XmlParser(replyMsg);
				logger.info("getClientCode(); Received Hash map after parsing of response.");

				log.info("getClientCode(); Received Hash map after parsing of response.");

				getClientCodeRtn.errorCode = (String) map.get("errCode");
				getClientCodeRtn.errorDesc = (String) map.get("errDesc");

				if (getClientCodeRtn.errorCode.equalsIgnoreCase("0")
						|| getClientCodeRtn.errorCode.equalsIgnoreCase("00")
						|| getClientCodeRtn.errorCode.equalsIgnoreCase("000")
						|| getClientCodeRtn.errorCode.equalsIgnoreCase("0000")) {
					logger.info("getClientCode(); Response from MQ is 'SUCCESS'.. ");

					log.info("getClientCode(); Response from MQ is 'SUCCESS'.. ");

					if ((String) map.get("returnMsgIdActualStr") != null) {
						getClientCodeRtn.msgId = (String) map.get("returnMsgIdActualStr");
					}
					if ((String) map.get("auditSeqOutStr") != null) {
						getClientCodeRtn.auditSeqOutStr = (String) map.get("auditSeqOutStr");
					}
					if ((String) map.get("dateTimeStampOutStr") != null) {
						getClientCodeRtn.dateTimeStampOutStr = (String) map.get("dateTimeStampOutStr");
					}
					if ((String) map.get("description") != null) {
						getClientCodeRtn.description = (String) map.get("description");
					}
					if ((String) map.get("clientCode") != null) {
						getClientCodeRtn.clientCode = (String) map.get("clientCode");
					}

					getClientCodeRtn.status = validStr;

				} else {
					logger.info("getClientCode(); Response from MQ is 'FAILURE'.. ");

					log.info("getClientCode(); Response from MQ is 'FAILURE'.. ");
					getClientCodeRtn.status = invalidStr;
				}

			} else {
				logger.info("getClientCode(); Since the response from MQ is not proper .. ");
				logger.info("getClientCode(); Setting error values.");
				log.info("getClientCode(); Since the response from MQ is not proper .. ");
				log.info("getClientCode(); Setting error values.");
				getClientCodeRtn.errorCode = errorCode;
				getClientCodeRtn.errorDesc = errorDesc;
				getClientCodeRtn.status = invalidStr;

			}

		} catch (Exception e) {
			log.info("getClientCode(); Exception is raised." + e.toString());
			logger.info("getClientCode(); Exception is raised." + e.toString());

			getClientCodeRtn.errorCode = errorCode;
			getClientCodeRtn.errorDesc = errorDesc;
			getClientCodeRtn.status = invalidStr;
			logger.error("cardDetails(); Reason : " + e.getStackTrace());

			log.severe("cardDetails(); Reason : " + e.getStackTrace());

		} finally {
			xmlReq = emptyStr;
			replyMsg = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;

			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			xmlMap = null;
			map = null;
		}
		logger.info("getClientCode(); Response is returned to the IVR. Response : " + getClientCodeRtn.toString());
		logger.info("getClientCode(); Exit ");
		log.info("getClientCode(); Response is returned to the IVR. Response : " + getClientCodeRtn.toString());
		log.info("getClientCode(); Exit ");
		return getClientCodeRtn;
	}
}

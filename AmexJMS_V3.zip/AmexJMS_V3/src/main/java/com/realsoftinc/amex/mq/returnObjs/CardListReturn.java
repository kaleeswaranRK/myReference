package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class CardListReturn {
	public String errorCode = emptyStr;
	public String errorDescription = emptyStr;
	public String status = emptyStr;
	public String dateTimeStampOutStr = emptyStr;
	public String auditSeqOutStr = emptyStr;
	public String msgId = emptyStr;
	public String cardListDesc = emptyStr;
	public String maskAccNum = emptyStr;
	public String AccountNum = emptyStr;
	public String maskCardNum = emptyStr;
	//public String cardListDesc = emptyStr;
	
	/*public String AccountNum = emptyStr;
	public String CMTitle = emptyStr;
	public String FirstName = emptyStr;
	public String CMDateOfBirth = emptyStr;
	public String MobileNO = emptyStr;
	public String CMEmailID = emptyStr;
	public String productCode = emptyStr;
	public String maskAccNum = emptyStr;
	public String errorCode = emptyStr;
	public String errorDescription = emptyStr;
	public String status = emptyStr;
	public String DateTimeStamp = emptyStr;
	public String AuditSeq = emptyStr;
	
	public String toString () {
		
		if (!(AccountNum.equalsIgnoreCase(emptyStr)))
		 maskAccNum=AccountNum.substring(0,4)+"******"+AccountNum.substring(AccountNum.length()-5,AccountNum.length());
		String returnStr = emptyStr;
			returnStr = newLine +
			resErrorCode + errorCode  + newLine +
			resErrorDesc + errorDescription + newLine +
			resStatus + status + newLine +		
			resAccNum + maskAccNum + newLine +
			resTitle + CMTitle + newLine +
			resName + FirstName + newLine +
			resDOB + CMDateOfBirth + newLine +
			resMobilePhone + MobileNO    + newLine +
			resEmail + CMEmailID + newLine +
			resProductCode + productCode + newLine +
			resDateTimeStampLog + DateTimeStamp + newLine +
			resAuditSeq + AuditSeq + newLine;
		return returnStr;
	}*/
	
	public CardLst[] cardLists = null;
	
	public String toString() {
		String returnStr = emptyStr;
		if (cardLists != null) {
			returnStr = newLine +
					resErrorCode + errorCode                      + newLine +
					resErrorDesc + errorDescription               + newLine +
					resStatus + status                         + newLine;
			
			for (int j = 0; j < cardLists.length; j++) {
				if (!(AccountNum.equalsIgnoreCase(emptyStr)))
					maskAccNum=AccountNum.substring(0,4)+"******"+AccountNum.substring(AccountNum.length()-5,AccountNum.length());
				
				if (!(cardLists[j].CardNumber.equalsIgnoreCase(emptyStr)))
					maskCardNum=cardLists[j].CardNumber.substring(0,4)+"******"+cardLists[j].CardNumber.substring(cardLists[j].CardNumber.length()-4,cardLists[j].CardNumber.length());
				
				
				returnStr = returnStr + 
						resAccNum + cardLists[j].maskAccNum + newLine +
						resTitle + cardLists[j].CMTitle + newLine +
						resName + cardLists[j].CMFirstName + newLine +
						resDOB + cardLists[j].CMDateOfBirth + newLine +
						resMobilePhone + cardLists[j].MobileNO    + newLine +
						resEmail + cardLists[j].CMEmailID + newLine +
						resProductCode + cardLists[j].ProductCode + newLine +
						resDateTimeStampLog + cardLists[j].DateTimeStamp + newLine +
						resAuditSeq + cardLists[j].AuditSeq + newLine +
						resCardNumber + maskCardNum + newLine +
						resUCI + cardLists[j].UCI + newLine +
						resCMFamilyName + cardLists[j].CMFamilyName + newLine +
						resLegalID + cardLists[j].LegalId + newLine +
						resCardSeq + cardLists[j].CardSeq + newLine +
						resClientCode + cardLists[j].ClientCode + newLine;	
			}
			/*returnStr = newLine +
			resErrorCode + errorCode                      + newLine +
			resErrorDesc + errorDescription               + newLine +
			resStatus + status                         + newLine +			
			resAccNum + cardLists.maskAccNum + newLine +
			resTitle + cardLists.CMTitle + newLine +
			resName + cardLists.CMFirstName + newLine +
			resDOB + cardLists.CMDateOfBirth + newLine +
			resMobilePhone + cardLists.MobileNO    + newLine +
			resEmail + cardLists.CMEmailID + newLine +
			resProductCode + cardLists.ProductCode + newLine +
			resDateTimeStampLog + cardLists.DateTimeStamp + newLine +
			resAuditSeq + cardLists.AuditSeq + newLine +
			resCardNumber + cardLists.CardNumber + newLine +
			resUCI + cardLists.UCI + newLine +
			resCMFamilyName + cardLists.CMFamilyName + newLine +
			resLegalID + cardLists.LegalId + newLine +
			resClientCode + cardLists.ClientCode + newLine;	*/
		
		} else {
			returnStr = newLine +
			resErrorCode + errorCode                      + newLine +
			resErrorDesc + errorDescription               + newLine +
			resStatus + status                         + newLine ;
		}
		return returnStr;
	}
}
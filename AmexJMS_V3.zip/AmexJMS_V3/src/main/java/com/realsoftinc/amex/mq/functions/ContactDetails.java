/*
* (C) Copyright 2013 Geomant Kft. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
import com.realsoftinc.amex.mq.returnObjs.ContDetails;
import com.realsoftinc.amex.mq.returnObjs.ContactDetailsReturn;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function ContactDetails
 * 
 * @author Marijana Dujovic / Geomant Kft.
 */

public class ContactDetails {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(ContactDetails.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public ContactDetailsReturn getContactDetails(String AccNum) {
		logger.info("getContactDetails(); Contact Details function is called by IVR .. ");
		logger.info("getContactDetails(); Enter ");
		log.info("getContactDetails(); Contact Details function is called by IVR .. ");
		log.info("getContactDetails(); Enter ");

		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		MQCommon mqc = null;
		RequestResponse rr = null;
		RequestCreater rc = null;
		ResponseParser respParser = null;
		ContDetails conDtls = null;
		ContactDetailsReturn contDtlRtn = null;
		String dateTimeStampInStr = null;
		String auditSeqInStr = null;

		String xmlReq = emptyStr;
		String replyMsg = emptyStr;

		String maskAccNum = emptyStr;

		try {

			mqc = new MQCommon();
			xmlMap = new HashMap<String, String>();

			rc = new RequestCreater();
			rr = new RequestResponse();
			respParser = new ResponseParser();
			conDtls = new ContDetails();
			contDtlRtn = new ContactDetailsReturn();

			/*
			 * sso = MQCommon.SSO; if(sso == null) {
			 * log.info("getContactDetails(); sso is null");
			 * log.info("getContactDetails(); Calling getSSO() function .. "); sso =
			 * mqc.getSSO(); } else { if(sso.equalsIgnoreCase(emptyStr)) {
			 * log.info("getContactDetails(); sso is empty string");
			 * log.info("getContactDetails(); Calling getSSO() function .. "); sso =
			 * mqc.getSSO(); } }
			 */
			if (AccNum.length() == 12) {

				maskAccNum = AccNum.substring(0, 4) + "******" + AccNum.substring(AccNum.length() - 5, AccNum.length());
				logger.info("getContactDetails(); Account Number is : " + maskAccNum);

				log.info("getContactDetails(); Account Number is : " + maskAccNum);
			} else {
				logger.info("getContactDetails(); Account Number is less than 12 digits.");

				log.info("getContactDetails(); Account Number is less than 12 digits.");
			}
			logger.info("getContactDetails(); Calling the getDateTime function ..");

			log.info("getContactDetails(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("getContactDetails(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("getContactDetails(); Calling the getAuditSequence function ..");
			log.info("getContactDetails(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("getContactDetails(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("getContactDetails(); Audit Sequence is : " + auditSeqInStr);

			logger.info("getContactDetails(); Created all the required parameters to prepare the xml ..");
			log.info("getContactDetails(); Audit Sequence is : " + auditSeqInStr);

			log.info("getContactDetails(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("AccountNumber", AccNum);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			// xmlMap.put("SSO", sso);
			// xmlMap.put("MessageLength", mqc.getproperties("ContactDetails.MsgLength"));
			xmlMap.put("SysID", mqc.getproperties("CardNoValidation.SysID"));
			xmlMap.put("MessageId", MsgId_CardNoVal);
			// xmlMap.put("MessageId", MsgId_CntctDtls);
			logger.info("getContactDetails(); Sending values to form proper form of xml request .. ");

			log.info("getContactDetails(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "ContactDetails");
			logger.info("getContactDetails(); Received xml in proper format ..");

			log.info("getContactDetails(); Received xml in proper format ..");
			// log.info("getContactDetails(); XML is : " + xmlReq);
			// Added to encrypt account number when display request in log file
			MQCommon.maskAccNumber("getContactDetails(); XML is : ", xmlReq);
			logger.info("getContactDetails(); Sending this xml as the request to MQ ..");

			log.info("getContactDetails(); Sending this xml as the request to MQ ..");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("getContactDetails(); Response received from MQ .. ");

			log.info("getContactDetails(); Response received from MQ .. ");
			// log.info("getContactDetails(); Received response from MQ is : " + replyMsg);
			// Added to encrypt account number when display response in log file
			MQCommon.maskAccNumber("getContactDetails(); Received response from MQ is : ", replyMsg);

			if (replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))) {
				logger.info("getContactDetails(); Sending the received response from MQ to the parser ..");

				log.info("getContactDetails(); Sending the received response from MQ to the parser ..");
				// log.info("getContactDetails(); XML sent for parsing is :"+ replyMsg);
				map = respParser.XmlParser(replyMsg);
				logger.info("getContactDetails(); Received Hash map after parsing of response.");

				log.info("getContactDetails(); Received Hash map after parsing of response.");

				contDtlRtn.ErrorCode = (String) map.get("errCode");
				contDtlRtn.ErrorDescription = (String) map.get("errDesc");

				if (contDtlRtn.ErrorCode.equalsIgnoreCase("0") || contDtlRtn.ErrorCode.equalsIgnoreCase("00")
						|| contDtlRtn.ErrorCode.equalsIgnoreCase("000")
						|| contDtlRtn.ErrorCode.equalsIgnoreCase("0000")) {
					logger.info("getContactDetails(); Response from MQ is 'SUCCESS'.. ");

					log.info("getContactDetails(); Response from MQ is 'SUCCESS'.. ");
					if ((String) map.get("accountNum") != null)
						conDtls.AccountNum = (String) map.get("accountNum");
					if ((String) map.get("title") != null)
						conDtls.Title = (String) map.get("title");
					if ((String) map.get("homeNO") != null)
						conDtls.HomeNO = (String) map.get("homeNO");
					if ((String) map.get("homeCountry") != null)
						conDtls.HomeCountrySel = (String) map.get("homeCountry");
					if ((String) map.get("mobNO") != null)
						conDtls.MobileNO = (String) map.get("mobNO");
					if ((String) map.get("mobNOCountry") != null)
						conDtls.MobileNOCountySel = (String) map.get("mobNOCountry");
					if ((String) map.get("workNO") != null)
						conDtls.WorkNO = (String) map.get("workNO");
					if ((String) map.get("workCountry") != null)
						conDtls.WorkNoCountrySel = (String) map.get("workCountry");
					if ((String) map.get("orgStr") != null)
						conDtls.Org = (String) map.get("orgStr");
					if ((String) map.get("logoStr") != null)
						conDtls.Logo = (String) map.get("logoStr");
					if ((String) map.get("currencyName") != null)
						conDtls.CurrencyName = (String) map.get("currencyName");
					if ((String) map.get("primSuppFlag") != null)
						conDtls.PrimSupplFlag = (String) map.get("primSuppFlag");
					if ((String) map.get("name1") != null)
						conDtls.Name1 = (String) map.get("name1");
					if ((String) map.get("statAddress1") != null)
						conDtls.StatementAddress1 = (String) map.get("statAddress1");
					if ((String) map.get("dateOfBirth") != null)
						conDtls.DateOfBirth = (String) map.get("dateOfBirth");
					if ((String) map.get("emailID") != null)
						conDtls.EmailID = (String) map.get("emailID");
					if ((String) map.get("memo1") != null)
						conDtls.Memo1 = (String) map.get("memo1");
					if ((String) map.get("memo2") != null)
						conDtls.Memo2 = (String) map.get("memo2");
					if ((String) map.get("smsFlag") != null)
						conDtls.SMSFlag = (String) map.get("smsFlag");
					if ((String) map.get("eStatFlag") != null)
						conDtls.eStatementFlag = (String) map.get("eStatFlag");
					if ((String) map.get("prodCodeStr") != null)
						conDtls.productCode = (String) map.get("prodCodeStr");
					if ((String) map.get("branchCodeStr") != null)
						conDtls.BranchCode = (String) map.get("branchCodeStr");
					if ((String) map.get("otb") != null)
						conDtls.OTB = (String) map.get("otb");
					// CR July 2016. - Geomant
					if ((String) map.get("powcardID") != null)
						conDtls.powercardID = (String) map.get("powcardID");

					contDtlRtn.Status = validStr;
				} else {
					logger.info("getContactDetails(); Response from MQ is 'FAILURE'.. ");

					log.info("getContactDetails(); Response from MQ is 'FAILURE'.. ");
					contDtlRtn.Status = invalidStr;
				}
				contDtlRtn.cntDetails = conDtls;

			} else {// reply message is empty
				logger.info("getContactDetails(); Since the response from MQ is not proper .. ");
				logger.info("getContactDetails(); Setting error values.");
				log.info("getContactDetails(); Since the response from MQ is not proper .. ");
				log.info("getContactDetails(); Setting error values.");
				contDtlRtn.ErrorCode = errorCode;
				contDtlRtn.ErrorDescription = errorDesc;
				contDtlRtn.Status = invalidStr;
				contDtlRtn.cntDetails = conDtls;
			}
		} catch (Exception e) {
			logger.info("getContactDetails(); Exception is raised." + e.toString());

			log.info("getContactDetails(); Exception is raised." + e.toString());
			contDtlRtn.cntDetails = conDtls;
			contDtlRtn.ErrorCode = errorCode;
			contDtlRtn.ErrorDescription = errorDesc;
			contDtlRtn.Status = invalidStr;
			logger.error("getContactDetails(); Reason :" + e);
			log.severe("getContactDetails(); Reason :" + e);
		} finally {
			xmlMap = null;
			map = null;
			mqc = null;
			rr = null;
			rc = null;
			respParser = null;
			conDtls = null;
			dateTimeStampInStr = null;
			auditSeqInStr = null;

			xmlReq = emptyStr;
			replyMsg = emptyStr;

			maskAccNum = emptyStr;
		}
		logger.info("getContactDetails(); Response is returned to the IVR. Response : " + contDtlRtn.toString());
		logger.info("getContactDetails(); Exit");
		log.info("getContactDetails(); Response is returned to the IVR. Response : " + contDtlRtn.toString());
		log.info("getContactDetails(); Exit");
		return contDtlRtn;
	}
}
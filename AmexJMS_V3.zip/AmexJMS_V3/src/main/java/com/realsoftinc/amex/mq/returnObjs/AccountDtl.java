package com.realsoftinc.amex.mq.returnObjs;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

public class AccountDtl {

	public String MessageID = emptyStr;
	public String AuditSeqOutStr = emptyStr;
	public String DateTimeStampOutStr = emptyStr;
	public String Description = emptyStr;
	public String StatementOption = emptyStr;	
	public String AccountStatus = emptyStr;
	public String TotalCreditLimit = emptyStr;
	public String TotalCashLimit = emptyStr;
	public String BillingCycle = emptyStr;
	public String TotalMinimumDue = emptyStr;
	public String LastPaymentAmount = emptyStr;
	public String TotalSpendExposure = emptyStr;
	public String AccountParOverride = emptyStr;	
	public String MasterLimit = emptyStr;
	public String BasicControlNumber = emptyStr;
	public String BasicControlName = emptyStr;
	public String AvailableCredit = emptyStr;
	public String AvailableCash = emptyStr;
	public String AmountDue = emptyStr;
	public String DaysDelinquent = emptyStr;
	public String TotalBilledBalance = emptyStr;
	public String PARAccountUnderride = emptyStr;
	public String MasterExposure = emptyStr;
	public String Currency = emptyStr;
	public String ExpressCashFlag = emptyStr;
	public String ProductName = emptyStr;
	public String PastDue = emptyStr;
	public String DirectDebitFlag = emptyStr;
	public AccountDtlAvailableOffers[] AvailableOffers = null;
	public String ErrorCode = emptyStr;
	public String ErrorDesc = emptyStr;
	
	public String toString()
	{
		String returnStr = emptyStr;

		returnStr = newLine +
				resMsgId + MessageID + newLine +
				resAuditSeq + AuditSeqOutStr + newLine +
				resDateTimeStampLog + DateTimeStampOutStr + newLine +
				resDesc + Description + newLine +
				resStatementOption + StatementOption + newLine +			
				resAccountStatus + AccountStatus    + newLine +
				resTotalCreditLimit + TotalCreditLimit         + newLine +
				resTotalCashLimit + TotalCashLimit  + newLine +
				resBillingCycle  + BillingCycle   + newLine +
				resTotalMinimumDue + TotalMinimumDue       + newLine +
				resLastPaymentAmount + LastPaymentAmount    + newLine +
				resTotalSpendExposure + TotalSpendExposure     + newLine +
				resAccountParOverride + AccountParOverride     + newLine +			
				resMasterLimit + MasterLimit            + newLine +
				resBasicControlNumber + BasicControlNumber          + newLine +
				resBasicControlName + BasicControlName     + newLine +
				resAvailableCredit + AvailableCredit      + newLine +
				resAvailableCash + AvailableCash        + newLine +
				resAmountDue  + AmountDue          + newLine +
				resDaysDelinquent + DaysDelinquent + newLine +
				resTotalBilledBalance + TotalBilledBalance + newLine +
				resPARAccountUnderride + PARAccountUnderride + newLine +
				resMasterExposure + MasterExposure + newLine +
				resCurrency + Currency + newLine +
				resExpressCashFlag + ExpressCashFlag + newLine +
				resProductName + ProductName + newLine +
				resPastDue + PastDue + newLine +
				resDirectDebitFlag + DirectDebitFlag + newLine  ;

		if(AvailableOffers !=null) {

			String CampaignName ="";
			String CampaignDetail ="";
			String StartDate ="";
			String EndDate ="";

			for (int i = 0; i < AvailableOffers.length; i++) {
				CampaignName = AvailableOffers[i].CampaignName;
				CampaignDetail = AvailableOffers[i].CampaignDetail;
				StartDate = AvailableOffers[i].StartDate;
				EndDate = AvailableOffers[i].EndDate;

				returnStr = returnStr +					
						resCampaignName + CampaignName + newLine +
						resStartDate + StartDate + newLine +
						resEndDate + EndDate + newLine +
						resCampaignDetail + CampaignDetail + newLine ;
			}

		} 

		/*returnStr = returnStr +	
				resErrorCode + ErrorCode + newLine  +
				resErrorDesc + ErrorDesc + newLine ;*/


		return returnStr;
	}

}

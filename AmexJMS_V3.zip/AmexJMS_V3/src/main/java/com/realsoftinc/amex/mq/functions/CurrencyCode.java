/*
 * (C) Copyright 2010 Real Soft (Intl) Pvt. Ltd. 
 * All rights reserved. 
 * 
 */
package com.realsoftinc.amex.mq.functions;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.returnObjs.CurrencyReturn;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function Currency Code
 * 
 * @author Purvi Lad / Real Soft (Intl) Pvt. Ltd.
 * @version $Revision: 1.7 $ $Date: 2010/07/12 10:40:55 $
 */

public class CurrencyCode {

	Logger log = Utility.getLogger();
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(CurrencyCode.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public CurrencyReturn getCurrenyCode(String CardNum) {
		log.info("getCurrenyCode(); Account Balance function is called by IVR .. ");
		log.info("getCurrenyCode(); Enter ");		
		logger.info("getCurrenyCode(); Account Balance function is called by IVR .. ");
		logger.info("getCurrenyCode(); Enter ");		

		MQCommon mqc = null;
		Map<String, String> xmlMap = null;
		Map<String, String> map = null;

		RequestCreater rc = null;
		RequestResponse rr = null;
		ResponseParser cardnoparser = null;
		CurrencyReturn currRtn = null;

		String replyMsg = emptyStr;
		String xmlReq = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
		String cnumber = emptyStr;
		String maskCardNum = emptyStr;

		try {
			mqc = new MQCommon();
			xmlMap = new HashMap<String, String>();
			map = new HashMap<String, String>();
			rc = new RequestCreater();
			rr = new RequestResponse();
			cardnoparser = new ResponseParser();
			currRtn = new CurrencyReturn();

			if(CardNum.length() == 15){
				maskCardNum = CardNum.replace(CardNum.subSequence(4, CardNum.length()-5),maskString1);
				logger.info("getCurrenyCode(); Card Number is : " + maskCardNum);

				log.info("getCurrenyCode(); Card Number is : " + maskCardNum);
				}
				else{
					logger.info("getCurrenyCode(); Card Number is less than 15 digits.");

					log.info("getCurrenyCode(); Card Number is less than 15 digits.");
				}
			logger.info("getCurrenyCode(); Calling the getDateTime function ..");

			log.info("getCurrenyCode(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("getCurrenyCode(); DateTimeStamp is : " + dateTimeStampInStr);

			logger.info("getCurrenyCode(); Calling the getAuditSequence function ..");
			log.info("getCurrenyCode(); DateTimeStamp is : " + dateTimeStampInStr);

			log.info("getCurrenyCode(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("getCurrenyCode(); Audit Sequence is : " + auditSeqInStr);

			logger.info("getCurrenyCode(); Created all the required parameters to prepare the xml ..");
			log.info("getCurrenyCode(); Audit Sequence is : " + auditSeqInStr);

			log.info("getCurrenyCode(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("CardNumber", CardNum);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			xmlMap.put("MessageLength", mqc.getproperties("CurrencyCode.MsgLength"));
			xmlMap.put("MessageId", MsgId_CurrCode);
			xmlMap.put("RackFlag", mqc.getproperties("CurrencyCode.RackFlag"));
			xmlMap.put("username", mqc.getproperties("CurrencyCode.UserName"));
			xmlMap.put("password", mqc.getproperties("CurrencyCode.Password"));
			xmlMap.put("Description", CurrencyCode_Desc);
			logger.info("getCurrenyCode(); Sending values to form proper form of xml request .. ");

			log.info("getCurrenyCode(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "CurrencyCode");
			logger.info("getCurrenyCode(); Received xml in proper format ..");
			logger.info("getCurrenyCode(); XML is : "	+ xmlReq);
			logger.info("getCurrenyCode(); Sending this xml as the request to MQ ..");

			log.info("getCurrenyCode(); Received xml in proper format ..");
			log.info("getCurrenyCode(); XML is : "	+ xmlReq);

			log.info("getCurrenyCode(); Sending this xml as the request to MQ ..");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("getCurrenyCode(); Response received from MQ .. ");
			logger.info("getCurrenyCode(); Received response from MQ is : " + replyMsg);

			log.info("getCurrenyCode(); Response received from MQ .. ");
			log.info("getCurrenyCode(); Received response from MQ is : " + replyMsg);

			  if(replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))){
				  replyMsg = replyMsg + "|" + CardNum;
				  logger.info("getCurrenyCode(); Sending the received response from MQ to the parser ..");
				  logger.info("getCurrenyCode(); XML sent for parsing is :"+ replyMsg);
				  log.info("getCurrenyCode(); Sending the received response from MQ to the parser ..");
				  log.info("getCurrenyCode(); XML sent for parsing is :"+ replyMsg);
				  map = cardnoparser.XmlParser(replyMsg);
				  logger.info("getCurrenyCode(); Received Hash map after parsing of response.");

				  log.info("getCurrenyCode(); Received Hash map after parsing of response.");

			currRtn.status = invalidStr;
			currRtn.errorCode = (String) map.get("errCode");
			currRtn.errorDescription = (String) map.get("errDesc");
			if (currRtn.errorCode.equalsIgnoreCase("0")
					||currRtn.errorCode.equalsIgnoreCase("00")
					|| currRtn.errorCode.equalsIgnoreCase("000")
					|| currRtn.errorCode.equalsIgnoreCase("0000")) {
				logger.info("getCurrenyCode(); Response from MQ is 'SUCCESS'.. ");

				log.info("getCurrenyCode(); Response from MQ is 'SUCCESS'.. ");
				currRtn.status = validStr;
				cnumber = (String) map.get("cnumber");
				logger.info("getCurrenyCode(); Cnumber is : " + cnumber);

				log.info("getCurrenyCode(); Cnumber is : " + cnumber);
			
				if (cnumber.equalsIgnoreCase(CardNum)) {
					currRtn.currencyName = (String) map.get("currencyName");
					currRtn.currencySymbol = (String) map.get("currencySymbol");
					currRtn.primarySuppFlag = (String) map.get("primSuppFlag");
				}
				else {
					logger.info("getCurrenyCode(); Ignoring this card Number for fetching the details.");

					log.info("getCurrenyCode(); Ignoring this card Number for fetching the details.");
				}
				
			} else {
				logger.info("getCurrenyCode(); Response from MQ is 'FAILURE'.. ");

				log.info("getCurrenyCode(); Response from MQ is 'FAILURE'.. ");
				currRtn.status = invalidStr;
				currRtn.errorCode = errorCode;
				currRtn.errorDescription = errorDesc;
			}
			  }
			  else{
				  logger.info("getCurrenyCode(); Since the response from MQ is not proper .. ");
				  logger.info("getCurrenyCode(); Setting error values.");
				  log.info("getCurrenyCode(); Since the response from MQ is not proper .. ");
				  log.info("getCurrenyCode(); Setting error values.");
				  currRtn.status = invalidStr;
				  currRtn.errorCode = errorCode;
				  currRtn.errorDescription = errorDesc; 
			  }
		} catch (Exception e) {
			logger.error("getCurrenyCode(); Exception is raised. Reason. "	+ e.getStackTrace());

			log.severe("getCurrenyCode(); Exception is raised. Reason. "	+ e.getStackTrace());
			  currRtn.status = invalidStr;
			  currRtn.errorCode = errorCode;
			  currRtn.errorDescription = errorDesc;
			  logger.error("getCurrenyCode(); Reason : " + e.getStackTrace());

			  log.severe("getCurrenyCode(); Reason : " + e.getStackTrace());
		}
		finally{
			mqc = null;
			xmlMap = null;
			map = null;
			rc = null;
			rr = null;
			cardnoparser = null;
			
			replyMsg = emptyStr;
			xmlReq = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			cnumber = emptyStr;
			maskCardNum = emptyStr;
		}
		logger.info("getCurrenyCode(); Response is returned to the IVR. Response : "+ currRtn.toString());
		logger.info("getCurrenyCode(); Exit");
		log.info("getCurrenyCode(); Response is returned to the IVR. Response : "+ currRtn.toString());
		log.info("getCurrenyCode(); Exit");
		return currRtn;
	}
}

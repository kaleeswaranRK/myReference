/*
* (C) Copyright 2013 Geomant Kft. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import java.util.HashMap;
import java.util.Map;

import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;
import com.realsoftinc.amex.mq.util.RequestCreater;
import com.realsoftinc.amex.mq.util.ResponseParser;
import com.realsoftinc.amex.mq.returnObjs.PaymentHist;
import com.realsoftinc.amex.mq.returnObjs.PaymentHistoryReturn;

import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function Payment History
 * 
 * @author Marijana Dujovic / Geomant Kft. 
 */
public class PaymentHistory {

	Logger log = Utility.getLogger();
	static org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(PaymentHistory.class);

	@SuppressWarnings({ "static-access", "unchecked" })
	public PaymentHistoryReturn getPaymentHistory(String AccNum) {
		logger.info("getPaymentHistory(); Payment History function is called by IVR .. ");
		logger.info("getPaymentHistory(); Enter ");
		log.info("getPaymentHistory(); Payment History function is called by IVR .. ");
		log.info("getPaymentHistory(); Enter ");

		Map<String, String> xmlMap = null;
		MQCommon mqc = null;
		RequestCreater rc = null;
		RequestResponse rr = null;

		ResponseParser respParser = null;
		PaymentHist payHist = null;
		PaymentHistoryReturn payHistRtn = null;
		Map<String, String> map = null;

		String replyMsg = emptyStr;
		String xmlReq = emptyStr;
		String dateTimeStampInStr = emptyStr;
		String auditSeqInStr = emptyStr;
//		@SuppressWarnings("unused")
		String errorDescription = emptyStr;
		
		String maskAccNum = emptyStr;

		try {
			xmlMap = new HashMap<String, String>();

			mqc = new MQCommon();
			rc = new RequestCreater();
			rr = new RequestResponse();
			respParser = new ResponseParser();
			payHist = new PaymentHist();
			payHistRtn = new PaymentHistoryReturn();
			
			

			/*sso = MQCommon.SSO;
			if(sso == null)
			{	log.info("getPaymentHistory(); sso is null");
				log.info("getPaymentHistory(); Calling getSSO() function .. ");
				sso = mqc.getSSO();
			}
			else
			{	if(sso.equalsIgnoreCase(emptyStr))
				{	log.info("getPaymentHistory(); sso is empty string");
					log.info("getPaymentHistory(); Calling getSSO() function .. ");
					sso = mqc.getSSO();
				}
			}*/
			
			if(AccNum.length() == 12){
				//maskAccNum = AccNum.replace(AccNum.subSequence(4, AccNum.length()-5),maskString2);
				maskAccNum=AccNum.substring(0,4)+"***"+AccNum.substring(AccNum.length()-5,AccNum.length());
				logger.info("getPaymentHistory(); Account Number is : " + maskAccNum);

				log.info("getPaymentHistory(); Account Number is : " + maskAccNum);
				}
				else{
					log.info("getPaymentHistory(); Account Number is less than 12 digits.");
				}
			logger.info("getPaymentHistory(); Calling the getDateTime function ..");

			log.info("getPaymentHistory(); Calling the getDateTime function ..");
			dateTimeStampInStr = mqc.getDateTime();
			logger.info("getPaymentHistory(); DateTimeStamp is : " +  dateTimeStampInStr);

			log.info("getPaymentHistory(); DateTimeStamp is : " +  dateTimeStampInStr);
			logger.info("getPaymentHistory(); Calling the getAuditSequence function ..");

			log.info("getPaymentHistory(); Calling the getAuditSequence function ..");
			auditSeqInStr = mqc.getAuditSequence();
			logger.info("getPaymentHistory(); Audit Sequence is : " + auditSeqInStr);

			logger.info("getPaymentHistory(); Created all the required parameters to prepare the xml ..");
			log.info("getPaymentHistory(); Audit Sequence is : " + auditSeqInStr);

			log.info("getPaymentHistory(); Created all the required parameters to prepare the xml ..");
			xmlMap.put("AccountNumber", AccNum);
			xmlMap.put("DateTimeStamp", dateTimeStampInStr);
			xmlMap.put("AuditSeq", auditSeqInStr);
			//xmlMap.put("SSO", sso);
			//xmlMap.put("MessageLength", mqc.getproperties("PaymentHistory.MsgLength"));
			xmlMap.put("MessageId", MsgId_PaymntHist);
			xmlMap.put("SysID", mqc.getproperties("PaymentHistory.SysID"));
			//xmlMap.put("username", mqc.getproperties("PaymentHistory.UserName"));
			//xmlMap.put("password", mqc.getproperties("PaymentHistory.Password"));
			logger.info("getPaymentHistory(); Sending values to form proper form of xml request .. ");

			log.info("getPaymentHistory(); Sending values to form proper form of xml request .. ");
			xmlReq = rc.XmlRequest(xmlMap, "PaymentHistory");
			logger.info("getPaymentHistory(); Received xml in proper format ..");

			log.info("getPaymentHistory(); Received xml in proper format ..");
			//log.info("getPaymentHistory(); XML is : "	+ xmlReq);
			//Added to encrypt account number when display request in log file
			MQCommon.maskAccNumber( "getPaymentHistory(); XML is : ",xmlReq);
			logger.info("getPaymentHistory(); Sending the prepared xml to MQ .. ");

			log.info("getPaymentHistory(); Sending the prepared xml to MQ .. ");
			replyMsg = rr.MessageSender(xmlReq);
			logger.info("getPaymentHistory(); Response received from MQ .. ");
			logger.info("getPaymentHistory(); Received response from MQ is : " + replyMsg);
			log.info("getPaymentHistory(); Response received from MQ .. ");
			log.info("getPaymentHistory(); Received response from MQ is : " + replyMsg);


			if(replyMsg != null && !(emptyStr.equalsIgnoreCase(replyMsg))){
				logger.info("getPaymentHistory(); Sending the received response from MQ to the parser ..");

			log.info("getPaymentHistory(); Sending the received response from MQ to the parser ..");
			//log.info("getPaymentHistory(); XML sent for parsing is :"+ replyMsg);
			map = respParser.XmlParser(replyMsg);
			
			payHistRtn.errorCode = (String) map.get("errCode");
			payHistRtn.errorDescription = (String) map.get("errDesc");
			
			if (payHistRtn.errorCode.equalsIgnoreCase("0")
					|| payHistRtn.errorCode.equalsIgnoreCase("00")
					|| payHistRtn.errorCode.equalsIgnoreCase("000")
					|| payHistRtn.errorCode.equalsIgnoreCase("0000")) {
				logger.info("getPaymentHistory(); Response from MQ is 'SUCCESS'.. ");

				log.info("getPaymentHistory(); Response from MQ is 'SUCCESS'.. ");
				
				if((String) map.get("amtLastPay")!=null)
					 payHist.AmountLastPayment = (String) map.get("amtLastPay"); 				
				if((String) map.get("dateLastPay")!=null)
				 payHist.DateLastPayment = (String) map.get("dateLastPay"); //check if 3006 returns date last payment
				if((String) map.get("delqTpd")!=null)
					 payHist.DelqTPD = (String) map.get("delqTpd");
				if((String) map.get("delqXdayNo")!=null)
					 payHist.DelqXdayNumber = (String) map.get("delqXdayNo");
				if((String) map.get("delqXdayAmt")!=null)
					 payHist.DelqXdayAmount = (String) map.get("delqXdayAmt");
				

				payHistRtn.status = validStr;
			} else {
				logger.info("getPaymentHistory(); Response from MQ is 'FAILURE'.. ");

				log.info("getPaymentHistory(); Response from MQ is 'FAILURE'.. ");
				payHistRtn.status = invalidStr;
			}
			payHistRtn.pmtHistory = payHist;

		}else{
			logger.info("getPaymentHistory(); Since the response from MQ is not proper .. ");
			logger.info("getPaymentHistory(); Setting error values.");
			log.info("getPaymentHistory(); Since the response from MQ is not proper .. ");
			log.info("getPaymentHistory(); Setting error values.");
			payHistRtn.errorCode = MQConstants.errorCode;
			payHistRtn.errorDescription = errorDesc;
			payHistRtn.status = invalidStr;
			payHistRtn.pmtHistory = payHist;
		}
		}catch (Exception e) {
			logger.info("getPaymentHistory(); Exception is raised." + e.toString());

			log.info("getPaymentHistory(); Exception is raised." + e.toString());
			payHistRtn.pmtHistory = payHist;
			payHistRtn.errorCode = MQConstants.errorCode;
			payHistRtn.errorDescription = errorDesc;
			payHistRtn.status = invalidStr;
			logger.error("getPaymentHistory(); Reason : "	+ e.getStackTrace());

			log.severe("getPaymentHistory(); Reason : "	+ e.getStackTrace());
		}
		finally{
			xmlMap = null;
			mqc = null;
			rc = null;
			rr = null;
			respParser = null;
			payHist = null;
			map = null;

			replyMsg = emptyStr;
			xmlReq = emptyStr;
			dateTimeStampInStr = emptyStr;
			auditSeqInStr = emptyStr;
			errorDescription = emptyStr;
			
			maskAccNum = emptyStr;
		}
		logger.info("getPaymentHistory(); Response is returned to the IVR. Response : "+ payHistRtn.toString());
		logger.info("getPaymentHistory(); Exit");
		log.info("getPaymentHistory(); Response is returned to the IVR. Response : "+ payHistRtn.toString());
		log.info("getPaymentHistory(); Exit");
		return payHistRtn;
	}
}
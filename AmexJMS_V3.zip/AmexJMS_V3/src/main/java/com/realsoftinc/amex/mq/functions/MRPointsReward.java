/*
* (C) Copyright 2013 Geomant Kft. 
* All rights reserved. 
* 
*/
package com.realsoftinc.amex.mq.functions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;



import java.util.logging.Logger;

import com.realsoftinc.amex.mq.common.MQCommon;
import com.realsoftinc.amex.mq.common.MQConstants;
import com.realsoftinc.amex.mq.common.Utility;


import com.realsoftinc.amex.mq.returnObjs.MRPointsReturn;
import com.realsoftinc.amex.mq.returnObjs.MRInformation;



import static com.realsoftinc.amex.mq.common.MQConstants.*;

/**
 * This class is responsible for the implementation of the main business logic
 * for the function MRPointRewards
 * 
 * @author Marijana Dujovic / Geomant Kft. 
 */

public class MRPointsReward {

	Logger log = Utility.getLogger();
	 org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger(MRPointsReward.class);

	@SuppressWarnings( { "unchecked" })
	public MRPointsReturn getMRPoints(String accNum) {
		logger.info("getMRPoints(); Get MR Points function is called by IVR .. ");
		logger.info("getMRPoints(); Enter");
		log.info("getMRPoints(); Get MR Points function is called by IVR .. ");
		log.info("getMRPoints(); Enter");
		
		String urlStr = "";
		String errorCode = "";
		
		MRInformation mrInfo = null;
		MRPointsReturn mrpr = null;	
		
		
		
		try {
		    // Construct data
			
			mrInfo = new MRInformation();
			mrpr = new MRPointsReturn();

			StringBuilder data = new StringBuilder("");
			String dataStr = "";
				
									
			data = data.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">");			
			data = data.append("<soapenv:Body>");
			data = data.append("<sa:MROnlineRequest xmlns:sa=\"http://AMEX-BAHRAIN/MROnline/getMRStmtSummary\">");
			data = data.append("<sa:AccountNumber>"+accNum+"</sa:AccountNumber>");			
			data = data.append("</sa:MROnlineRequest>");			
			data = data.append("<ws:getMRClaim xmlns:ws=\"http://ws.security.loyalty.as.americanexpress.com/\"/>");			
			data = data.append("</soapenv:Body>");
			data = data.append("</soapenv:Envelope>");
			
		
			dataStr = data.toString();
			
			MQCommon.maskAccNumber("This is data string for MR point balance request: " ,dataStr);
			logger.info("getMRPoints(); Sending request to web service .. ");

			log.info("getMRPoints(); Sending request to web service .. ");
						
			//urlStr 
			//urlStr = "http://bah-brokersrv01:7080/MRONLINE/getMRStmtSummary";
			urlStr = "http://bah-iibsrv01:7080/MRONLINE/getMRStmtSummary";
		    // Send data
		    URL url = new URL(urlStr);
		    URLConnection conn = url.openConnection();
		    conn.setConnectTimeout(30000);
			conn.setReadTimeout(30000);	
		    conn.setDoOutput(true);
		    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
		    wr.write(dataStr);
		    wr.flush();

		    // Get the response
		    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		    String line;
		    StringBuilder sb = new StringBuilder ();
		    while ((line = rd.readLine()) != null) {
		        // Process line...
		    	sb.append(line);
		    	
		    }
		    wr.close();
		    rd.close();
		    logger.info("getMRPoints(); WS response: " + sb);

		    log.info("getMRPoints(); WS response: " + sb);
		    
		    errorCode = readResponseCode(sb, "<tns:returnCode>", "</tns:returnCode>");
		    
		    if (errorCode.equalsIgnoreCase("0")
					|| errorCode.equalsIgnoreCase("00")
					|| errorCode.equalsIgnoreCase("000")
					|| errorCode.equalsIgnoreCase("0000")) {
		    	logger.info("getMRPoints(); Response from WS is 'SUCCESS'.. ");	

		    	log.info("getMRPoints(); Response from WS is 'SUCCESS'.. ");	
		    	
		    	mrpr.errorCode = readResponseCode(sb, "<tns:returnCode>", "</tns:returnCode>");
		    	mrpr.errorDesc = readResponseCode(sb, "<tns:returnMessage>", "</tns:returnMessage>");
		    	mrInfo.adjustedPoints = readResponseCode(sb, "<tns:adjustedPoints>", "</tns:adjustedPoints>");
		    	mrInfo.availablePoints = readResponseCode(sb, "<tns:availablePoints>", "</tns:availablePoints>");
		    	mrInfo.bonusPoints = readResponseCode(sb, "<tns:bonusPoints>", "</tns:bonusPoints>");
		    	mrInfo.closingBalance = readResponseCode(sb, "<tns:closingBalance>", "</tns:closingBalance>");
		    	mrInfo.earnedPoints = readResponseCode(sb, "<tns:earnedPoints>", "</tns:earnedPoints>");
		    	mrInfo.memberId = readResponseCode(sb, "<tns:memberId>", "</tns:memberId>");
		    	mrInfo.pointsOpeningBalance = readResponseCode(sb, "<tns:pointsOpeningBalance>", "</tns:pointsOpeningBalance>");
		    	mrInfo.previousBalance = readResponseCode(sb, "<tns:previousBalance>", "</tns:previousBalance>");
		    	mrInfo.redeemedPoints  = readResponseCode(sb, "<tns:redeemedPoints>", "</tns:redeemedPoints>");
		    	
		    	mrpr.mrInfo = mrInfo;
		    	
		    	 
		    }	
		    else {
		    	logger.info("getMRPoints(); Response from WS is 'FAILURE'.. ");

		    	log.info("getMRPoints(); Response from WS is 'FAILURE'.. ");
		        mrpr.errorCode = readResponseCode(sb, "<tns:returnCode>", "</tns:returnCode>");
	    	    mrpr.errorDesc = readResponseCode(sb, "<tns:returnMessage>", "</tns:returnMessage>");
	    	    mrpr.mrInfo = mrInfo;
		    }	    
		  
		} 	 catch (IOException e) {
		    // Print out the exception that occurred
			logger.info("WS Exception: " + urlStr+ ": " + e.getMessage());

			log.info("WS Exception: " + urlStr+ ": " + e.getMessage());
			mrpr.errorCode = MQConstants.errorCode;			
			mrpr.errorDesc = MQConstants.errorDesc;
			mrpr.mrInfo = mrInfo;
		    
		} catch (Exception e){
			logger.info("Exception happened: " + e.getMessage());

			log.info("Exception happened: " + e.getMessage());
			mrpr.errorCode = MQConstants.errorCode;			
			mrpr.errorDesc = MQConstants.errorDesc;
			mrpr.mrInfo = mrInfo;
		}
		
		finally{
			
			errorCode = emptyStr;				
		
		}
		logger.info("getMRPoints(); Response is returned to the IVR. Response : "+ mrpr.toString());
		logger.info("getMRPoints(); Exit");
		log.info("getMRPoints(); Response is returned to the IVR. Response : "+ mrpr.toString());
		log.info("getMRPoints(); Exit");
		return mrpr;
	}
	private String readResponseCode(StringBuilder sb, String field, String endField) {
		String result = "";
		
		if (sb.indexOf(field) != -1)	
			result = sb.substring(sb.indexOf(field)+field.length(), sb.indexOf(endField));
		else
			result = "F";
		
		return result;
	}
}
